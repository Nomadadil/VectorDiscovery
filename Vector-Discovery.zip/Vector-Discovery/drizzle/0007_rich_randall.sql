CREATE TABLE `lens_research_flights` (
	`key` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`expires` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_research_flights_expiry` ON `lens_research_flights` (`expires`);--> statement-breakpoint
CREATE TABLE `lens_usage` (
	`day` integer NOT NULL,
	`feature` text NOT NULL,
	`metric` text NOT NULL,
	`count` integer NOT NULL,
	PRIMARY KEY(`day`, `feature`, `metric`)
);
