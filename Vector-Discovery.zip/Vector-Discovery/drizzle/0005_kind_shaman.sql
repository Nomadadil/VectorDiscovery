CREATE TABLE `lens_recent_reports` (
	`user_id` text NOT NULL,
	`network` text NOT NULL,
	`address` text NOT NULL,
	`report_id` text NOT NULL,
	`viewed_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_recent_owner_subject` ON `lens_recent_reports` (`user_id`,`network`,`address`);--> statement-breakpoint
CREATE INDEX `idx_recent_owner_time` ON `lens_recent_reports` (`user_id`,`viewed_at`);