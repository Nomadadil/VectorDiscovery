CREATE TABLE `lens_wallets` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`network` text NOT NULL,
	`address` text NOT NULL,
	`label` text DEFAULT '' NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_wallets_owner_address` ON `lens_wallets` (`user_id`,`network`,`address`);