CREATE TABLE `lens_wallet_alerts` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`wallet_id` text NOT NULL,
	`at` text NOT NULL,
	`payload` text NOT NULL,
	`seen` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_wallet_alerts_owner_time` ON `lens_wallet_alerts` (`user_id`,`at`);--> statement-breakpoint
CREATE TABLE `lens_wallet_monitors` (
	`wallet_id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`enabled` integer DEFAULT 1 NOT NULL,
	`min_usd` integer DEFAULT 0 NOT NULL,
	`cursor` integer NOT NULL,
	`window_end` integer,
	`page_offset` integer DEFAULT 0 NOT NULL,
	`last_checked` text,
	`error` text,
	`gap` integer DEFAULT 0 NOT NULL,
	`started_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_wallet_monitors_owner` ON `lens_wallet_monitors` (`user_id`,`enabled`);