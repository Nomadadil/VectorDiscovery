CREATE TABLE `lens_background_state` (
	`key` text PRIMARY KEY NOT NULL,
	`enabled` integer DEFAULT 0 NOT NULL,
	`last_run` text,
	`last_success` text,
	`checked` integer DEFAULT 0 NOT NULL,
	`error` text
);
--> statement-breakpoint
CREATE TABLE `lens_wallet_balances` (
	`wallet_id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`started_at` text NOT NULL,
	`at` text NOT NULL,
	`payload` text NOT NULL
);
