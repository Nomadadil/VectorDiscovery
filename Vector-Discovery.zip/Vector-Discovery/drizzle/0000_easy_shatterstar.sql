CREATE TABLE `lens_events` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`watch_id` text NOT NULL,
	`symbol` text NOT NULL,
	`title` text NOT NULL,
	`detail` text NOT NULL,
	`at` text NOT NULL,
	`report_id` text NOT NULL,
	`tone` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_events_owner_time` ON `lens_events` (`user_id`,`at`);--> statement-breakpoint
CREATE TABLE `lens_rate_limits` (
	`key` text PRIMARY KEY NOT NULL,
	`window` integer NOT NULL,
	`count` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `lens_reports` (
	`id` text PRIMARY KEY NOT NULL,
	`network` text NOT NULL,
	`address` text NOT NULL,
	`created_at` text NOT NULL,
	`payload` text NOT NULL,
	`digest` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_reports_subject_time` ON `lens_reports` (`network`,`address`,`created_at`);--> statement-breakpoint
CREATE TABLE `lens_watches` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`network` text NOT NULL,
	`address` text NOT NULL,
	`symbol` text NOT NULL,
	`report_id` text NOT NULL,
	`created_at` text NOT NULL,
	`checked_at` text NOT NULL,
	`paused` integer DEFAULT 0 NOT NULL,
	`threshold` integer DEFAULT 15 NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_watches_owner_subject` ON `lens_watches` (`user_id`,`network`,`address`);--> statement-breakpoint
CREATE INDEX `idx_watches_owner` ON `lens_watches` (`user_id`);