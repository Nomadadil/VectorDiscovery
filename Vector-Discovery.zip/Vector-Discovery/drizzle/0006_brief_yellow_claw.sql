CREATE TABLE `lens_rh_saved` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`kind` text NOT NULL,
	`subject` text NOT NULL,
	`payload` text NOT NULL,
	`at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_rh_saved_owner_subject` ON `lens_rh_saved` (`user_id`,`kind`,`subject`);--> statement-breakpoint
CREATE INDEX `idx_rh_saved_owner_time` ON `lens_rh_saved` (`user_id`,`at`);