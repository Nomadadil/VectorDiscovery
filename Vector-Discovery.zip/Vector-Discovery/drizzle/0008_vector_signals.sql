CREATE TABLE `vector_signals` (
 `id` text PRIMARY KEY NOT NULL,
 `network` text NOT NULL,
 `address` text NOT NULL,
 `first_seen` text NOT NULL,
 `last_checked` text NOT NULL,
 `expires_at` text NOT NULL,
 `payload` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_vector_signals_network_time` ON `vector_signals` (`network`,`first_seen`);
--> statement-breakpoint
CREATE TABLE `vector_signal_subscriptions` (
 `user_id` text PRIMARY KEY NOT NULL,
 `enabled` integer NOT NULL DEFAULT 0,
 `networks` text NOT NULL DEFAULT '["solana"]',
 `started_at` text NOT NULL,
 `last_read` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `vector_signal_runs` (
 `network` text PRIMARY KEY NOT NULL,
 `last_attempt` text NOT NULL,
 `last_success` text,
 `status` text NOT NULL,
 `detail` text NOT NULL DEFAULT ''
);
