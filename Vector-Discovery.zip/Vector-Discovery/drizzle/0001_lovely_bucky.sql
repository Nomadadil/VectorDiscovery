CREATE TABLE `lens_provider_cache` (
	`key` text PRIMARY KEY NOT NULL,
	`payload` text NOT NULL,
	`fetched_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_provider_cache_time` ON `lens_provider_cache` (`fetched_at`);