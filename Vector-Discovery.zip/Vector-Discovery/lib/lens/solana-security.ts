import {fetchJson} from './http';
import {readCache,writeCache} from './cache';
import {throttle} from './storage';
import {clean,tri,type LensReport} from './types';
export function normalizeSolanaSecurity(raw:any,address:string){
 const g=raw?.result?.[address];if(raw?.code!==1||!g||typeof g!=='object'||!Object.keys(g).length)throw new Error('No Solana permission data returned.');
 const rows=[['mintable','Additional minting'],['freezable','Accounts can be frozen'],['closable','Mint can be closed'],['balance_mutable_authority','Balance control authority'],['default_account_state_upgradable','Default account state can change'],['transfer_fee_upgradable','Transfer fee can change'],['transfer_hook_upgradable','Transfer hook can change'],['metadata_mutable','Metadata can change']];
 const facts=rows.map(([key,label])=>{const v=tri(g[key]?.status);return {id:'sol-'+key,label,value:v===null?'Not established':v?'Detected':'Not detected',signal:v,tone:v?'warn' as const:'neutral' as const,source:'GoPlus Solana',detail:'Reported token permission. An authority is a capability, not evidence of misuse.'}});
 const nonTransferable=tri(g.non_transferable);facts.push({id:'sol-non_transferable',label:'Non-transferable token',value:nonTransferable===null?'Not established':nonTransferable?'Detected':'Not detected',signal:nonTransferable,tone:nonTransferable?'warn':'neutral',source:'GoPlus Solana',detail:'A non-transferable token flag can prevent ordinary transfers. Unknown is not a passed check.'});
 return {facts,name:clean(g.metadata?.name,70),symbol:clean(g.metadata?.symbol,20)};
}
export async function solanaSecurity(r:LensReport){if(r.network!=='solana')return;const url='https://docs.gopluslabs.io/reference/response-detail-1';try{
 const key=`solana-permissions-v1:${r.address}`;let cached=await readCache<ReturnType<typeof normalizeSolanaSecurity>>(key,180000);
 if(!cached){await throttle('goplus-upstream',25);const result=normalizeSolanaSecurity(await fetchJson(`https://api.gopluslabs.io/api/v1/solana/token_security?contract_addresses=${r.address}`,{},9000),r.address);await writeCache(key,result);cached={data:result,at:Date.now()};}
 r.facts.push(...cached.data.facts);if(r.token.name==='Token'&&cached.data.name)r.token.name=cached.data.name;if(r.token.symbol==='TOKEN'&&cached.data.symbol)r.token.symbol=cached.data.symbol;
 r.sources.push({id:'solana-permissions',name:'GoPlus Solana',state:'ok',detail:'Mint, freeze, transfer and Token-2022 permission checks. Coverage varies by mint.',url,fetchedAt:new Date().toISOString(),observedAt:new Date(cached.at).toISOString()});
 }catch(e){r.sources.push({id:'solana-permissions',name:'GoPlus Solana',state:'unavailable',detail:e instanceof Error?e.message:'Permission checks unavailable.',url,fetchedAt:new Date().toISOString()})}}
