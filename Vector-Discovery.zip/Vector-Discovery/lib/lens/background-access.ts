import {env} from 'cloudflare:workers';

// Public visitors and ordinary signed-in users must never run the shared writer.
// It stays disabled until an operator configures both a dedicated secret and
// the explicit switch, and supplies the secret in the scheduler request.
export function backgroundEnabled(){
 return env.LENS_BACKGROUND_ENABLED==='true'&&typeof env.LENS_MONITOR_SECRET==='string'&&env.LENS_MONITOR_SECRET.length>=32;
}
export async function backgroundAuthorized(request:Request){
 if(!backgroundEnabled())return false;
 const supplied=request.headers.get('x-vector-monitor-secret')||'';
 if(!supplied||supplied.length>512)return false;
 const encoder=new TextEncoder();
 const [a,b]=await Promise.all([supplied,env.LENS_MONITOR_SECRET!].map(value=>crypto.subtle.digest('SHA-256',encoder.encode(value))));
 const left=new Uint8Array(a),right=new Uint8Array(b);let difference=0;
 for(let i=0;i<left.length;i++)difference|=left[i]^right[i];
 return difference===0;
}
