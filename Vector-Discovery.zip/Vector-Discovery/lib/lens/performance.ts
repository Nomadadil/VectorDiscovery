import {env} from 'cloudflare:workers';
import {num,validAddress,NETWORKS,type Network} from './types';
import {readCache,writeCache} from './cache';
import {birdeyeRequest} from './birdeye-client';
import type {WalletPerformance} from './wallet-types';
export function normalizePerformance(raw:any){const s=raw?.data?.summary;if(raw?.success!==true||!s||typeof s.pnl!=='object'||typeof s.counts!=='object')throw new Error('The performance response is incomplete.');const count=(v:any)=>{const n=num(v);return n!==null&&Number.isInteger(n)&&n>=0?n:null};const wins=count(s.counts.total_win),losses=count(s.counts.total_loss);return {realized:num(s.pnl.realized_profit_usd),unrealized:num(s.pnl.unrealized_usd),total:num(s.pnl.total_usd),trades:count(s.counts.total_trade),wins,losses,winRate:wins!==null&&losses!==null&&wins+losses>0?100*wins/(wins+losses):null};}
export async function performance(network:Network,wallet:string):Promise<WalletPerformance>{
 if(!Object.hasOwn(NETWORKS,network)||!validAddress(wallet,network))throw new Error('Enter a valid wallet address on the selected network.');
 const base:WalletPerformance={state:'unavailable',detail:'',network,wallet,window:'30d',method:'wac',scope:'duration_only',fetchedAt:new Date().toISOString(),source:'Birdeye',realized:null,unrealized:null,total:null,trades:null,wins:null,losses:null,winRate:null};
 if(!env.BIRDEYE_API_KEY)return {...base,state:'not_configured',detail:'Connect Birdeye to read wallet results. Recent pool swaps alone cannot establish profit or win rate.'};
 // Solana is the intersection of the provider endpoint and current package coverage docs.
 if(network!=='solana')return {...base,state:'unsupported',detail:'Wallet performance is currently enabled for Solana only. EVM coverage requires provider confirmation.'};
 const key=`birdeye:pnl:${network}:${wallet}:30d:wac:duration_only`;const cached=await readCache<WalletPerformance>(key,300000);if(cached)return cached.data;
 try{const raw=await birdeyeRequest(`/wallet/v2/pnl/summary?wallet=${wallet}&duration=30d&position_scope=duration_only&pnl_method=wac`,{cost:20,chain:network});const result={...base,...normalizePerformance(raw),state:'ok' as const,fetchedAt:new Date().toISOString(),detail:'Provider results for 30 days, weighted average cost. Protocol history may be incomplete. Closed-token win rate is not a forecast.'};await writeCache(key,result);return result}catch(e){return {...base,detail:e instanceof Error?e.message:'Wallet performance is unavailable.'}}
}
