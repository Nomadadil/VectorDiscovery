import {sameAddress,type LensReport} from './types';

type Copy = {en:string;ru:string};
const copy = (en:string,ru:string):Copy => ({en,ru});
export type RiskReason = {id:string;severity:number;title:Copy;detail:Copy;source:string;tab:string};
export type RiskDomain = {id:string;name:Copy;known:boolean;complete:boolean;severity:number;reasons:RiskReason[];gap:Copy|null};
export type RiskAssessment = {version:'1.0';score:number|null;level:'unknown'|'lower'|'medium'|'high'|'critical';provisional:boolean;covered:number;domains:RiskDomain[];reasons:RiskReason[];gaps:Copy[];multiplier:boolean};
const finite = (n:unknown):n is number => typeof n === 'number' && Number.isFinite(n);

/** Vector Discovery heuristic, not a calibrated probability or an investment rating.
 * Independent domains use their strongest rule. Missing data never earns credit.
 * Calculated from the immutable report so opening an old snapshot cannot refresh it.
 */
export function assessRisk(r:LensReport):RiskAssessment {
 const facts=(ids:string[])=>r.facts.filter(f=>ids.includes(f.id)&&f.signal!==null);
 const reason=(id:string,severity:number,title:Copy,detail:Copy,source:string,tab:string):RiskReason=>({id,severity,title,detail,source,tab});
 const domain=(id:string,name:Copy,known:boolean,complete:boolean,reasons:RiskReason[],gap:Copy):RiskDomain=>({id,name,known,complete,severity:Math.max(1,...reasons.map(x=>x.severity)),reasons,gap:complete?null:gap});
 const exit:RiskReason[]=[];
 const hp=facts(['go-is_honeypot','honey-honeypot']);
 const hpValues=[...hp.map(f=>f.signal),r.simulation.honeypot].filter(v=>v!==null);
 const hpSources=[...new Set([...hp.map(f=>f.source),...(r.simulation.honeypot!==null?[r.simulation.source]:[])])].join(' · ');
 if(hpValues.includes(true))exit.push(reason('honeypot',9,copy('Sale restriction signal','Сигнал ограничения продажи'),hpValues.includes(false)?copy('Providers disagree. A positive honeypot signal takes priority; inspect both scopes.','Источники расходятся. Положительный сигнал honeypot имеет приоритет; проверьте область обеих проверок.'):copy('A provider reported a honeypot signal for its checked route or contract.','Источник сообщил о сигнале honeypot для проверенного маршрута или контракта.'),hpSources,'Exit Check'));
 if(facts(['go-cannot_sell_all']).some(f=>f.signal))exit.push(reason('sell-all',8,copy('Full-position sale may be restricted','Возможное ограничение продажи всей позиции'),copy('GoPlus reports a full-position sale restriction. This is a provider finding, not a test of your amount.','GoPlus отметил ограничение продажи всей позиции. Это вывод источника, не тест вашей суммы.'),'GoPlus','Exit Check'));
 if(facts(['go-cannot_buy']).some(f=>f.signal))exit.push(reason('buy-restriction',6,copy('Buy restriction reported','Отмечено ограничение покупки'),copy('Provider detection may include anti-bot or simulation constraints. Inspect its scope.','Сигнал источника может зависеть от антибот-механизма или ограничений симуляции. Проверьте его область.'),'GoPlus','Exit Check'));
 if(facts(['sol-non_transferable']).some(f=>f.signal))exit.push(reason('non-transferable',9,copy('Token is non-transferable','Переводы токена запрещены'),copy('A non-transferable token flag was reported. This can prevent ordinary transfers and trading.','Отмечен запрет переводов токена. Он может препятствовать обычным переводам и торговле.'),'GoPlus Solana','Exit Check'));
 const tax=r.simulation.sellTax;
 if(finite(tax)&&tax>=5)exit.push(reason('sell-tax',tax>=50?9:tax>=20?8:tax>=10?6:4,copy(`Reported sell tax: ${tax.toFixed(1)}%`,`Налог на продажу: ${tax.toFixed(1)}%`),copy('The returned tax is for the provider’s observation. Settings and routes can change.','Ставка относится к проверке источника. Настройки и маршруты могут измениться.'),r.simulation.source,'Exit Check'));
 const exitComplete=r.simulation.success===true&&hpValues.includes(false)&&!hpValues.includes(true)&&finite(tax)&&tax>=0;
 const exitDomain=domain('exit',copy('Sale checks','Продажа'),hpValues.length>0||finite(tax)||exit.length>0,exitComplete,exit,copy('Sale testing is incomplete, failed, or conflicting. A failed simulation is not proof of a honeypot.','Проверка продажи неполна, не завершилась или есть расхождения. Сбой симуляции сам по себе не доказывает honeypot.'));

 const control:RiskReason[]=[];
 const groups:{id:string;ids:string[];severity:number;title:Copy}[]=r.network==='solana'?[
  {id:'mint',ids:['rug-mintAuthority','rpc-mintAuthority','sol-mintable'],severity:6,title:copy('Mint authority is present','Сохранено право выпуска токенов')},
  {id:'freeze',ids:['rug-freezeAuthority','rpc-freezeAuthority','sol-freezable'],severity:6,title:copy('Freeze authority is present','Сохранено право заморозки')},
  {id:'permanent-delegate',ids:['sol-balance_mutable_authority'],severity:8,title:copy('Balance control authority is present','Сохранено право изменения балансов')},
  {id:'sol-fees',ids:['sol-transfer_fee_upgradable'],severity:5,title:copy('Transfer fees can change','Комиссии переводов могут изменяться')},
  {id:'sol-hook',ids:['sol-transfer_hook_upgradable'],severity:6,title:copy('Transfer hook can change','Логика переводов может изменяться')},
  {id:'sol-state',ids:['sol-default_account_state_upgradable'],severity:6,title:copy('Default account state can change','Состояние новых счетов может изменяться')},
  {id:'sol-close',ids:['sol-closable'],severity:5,title:copy('Mint close authority is present','Сохранено право закрытия mint')}
 ]:[
  {id:'balance',ids:['go-owner_change_balance'],severity:8,title:copy('Administrator can change balances','Администратор может менять балансы')},
  {id:'hidden',ids:['go-hidden_owner'],severity:6,title:copy('Hidden owner capability reported','Отмечены скрытые права владельца')},
  {id:'mint',ids:['go-is_mintable'],severity:6,title:copy('Additional minting is possible','Возможен дополнительный выпуск')},
  {id:'pause',ids:['go-transfer_pausable'],severity:6,title:copy('Transfers can be paused','Переводы можно приостановить')},
  {id:'block',ids:['go-is_blacklisted'],severity:6,title:copy('Address blocking is possible','Возможна блокировка адресов')},
  {id:'fees',ids:['go-slippage_modifiable'],severity:5,title:copy('Trading fees can change','Комиссии могут изменяться')},
  {id:'personal-fees',ids:['go-personal_slippage_modifiable'],severity:6,title:copy('Address-specific fees are possible','Возможны индивидуальные комиссии для адресов')},
  {id:'reclaim',ids:['go-can_take_back_ownership'],severity:6,title:copy('Ownership can be reclaimed','Владелец может вернуть права')},
  {id:'limits',ids:['go-anti_whale_modifiable'],severity:5,title:copy('Transaction limits can change','Лимиты транзакций могут измениться')},
  {id:'whitelist',ids:['go-is_whitelisted'],severity:4,title:copy('Whitelist mechanism reported','Обнаружен механизм белого списка')}
 ];
 let observed=0,conflict=false;
 for(const g of groups){const rows=facts(g.ids);if(rows.length)observed++;const values=rows.map(f=>f.signal);if(values.includes(true)&&values.includes(false))conflict=true;if(values.includes(true))control.push(reason(g.id,g.severity,g.title,copy('An administrative capability, not evidence of misuse. Review who controls it and its scope.','Административная возможность, не доказательство злоупотребления. Проверьте, кто ей управляет и на что она распространяется.'),[...new Set(rows.map(f=>f.source))].join(' · '),'Creator'));}
 if(facts(['go-is_proxy','honey-proxy','rpc-implementation']).some(f=>f.signal===true))control.push(reason('proxy',4,copy('Proxy or implementation detected','Обнаружен прокси или implementation'),copy('Upgrade permissions are not established by the proxy classification alone.','Классификация прокси сама по себе не устанавливает права на обновление.'),'Contract checks','Creator'));
 const generic=r.facts.filter(f=>f.source==='RugCheck'&&f.signal===null&&(f.tone==='bad'||f.tone==='warn'));
 // Provider findings may repeat our authority, holder, or liquidity rules.
 // Keep one floor, never count these as another independent domain.
 const providerReason=generic.length?reason('provider-alerts',generic.some(f=>f.tone==='bad')?7:4,copy('Additional provider warnings','Дополнительные предупреждения источника'),copy('RugCheck returned warnings. Inspect the original findings; overlapping signals are not added together.','RugCheck вернул предупреждения. Откройте исходные выводы; совпадающие сигналы не суммируются.'),'RugCheck','Creator'):null;
 const controlDomain=domain('control',copy('Contract permissions','Права контракта'),observed>0,observed===groups.length&&!conflict,control,copy('Some administrative permissions are unknown or sources disagree.','Часть административных прав неизвестна или источники расходятся.'));

 const holderRows=r.holders.items.filter(h=>finite(h.share)&&h.share>=0&&h.share<=100&&!['pool','exchange','burn','bridge'].includes(h.kind)&&!r.market.pools.some(p=>sameAddress(p.address,h.address,r.network)));
 const largest=holderRows.length?Math.max(...holderRows.map(h=>h.share!)):null;
 const holders:RiskReason[]=[];
 if(largest!==null&&largest>=10)holders.push(reason('large-holder',largest>=50?8:largest>=20?6:4,copy(`One returned address holds ${largest.toFixed(1)}%`,`Один из найденных адресов держит ${largest.toFixed(1)}%`),copy('Identified infrastructure is excluded. An unlabelled address may still be a contract or custodian; this does not establish common ownership.','Известная инфраструктура исключена. Неразмеченный адрес может быть контрактом или кастодианом; общий владелец не установлен.'),holderRows.find(h=>h.share===largest)?.shareSource||r.holders.source,'Holders'));
 const distribution=!!r.context?.holders.buckets.length;
 const holdersDomain=domain('holders',copy('Supply concentration','Концентрация'),holderRows.length>0||distribution,false,holders,copy('Holder samples and address groups do not establish all owners, linked wallets, or infrastructure.','Выборка держателей и группы адресов не устанавливают всех владельцев, связанные кошельки и инфраструктуру.'));

 const poolValues=r.market.pools.map(p=>p.liquidityUsd).filter((n):n is number=>finite(n)&&n>=0);
 const deepest=poolValues.length?Math.max(...poolValues):null;
 const liquidity:RiskReason[]=[];
 if(deepest!==null&&deepest<50000)liquidity.push(reason('liquidity',deepest<10000?7:5,copy('Limited observed pool liquidity','Небольшая ликвидность найденных пулов'),copy(`The largest returned pool holds $${deepest.toLocaleString('en-US',{maximumFractionDigits:0})}. This is pool value, not executable depth.`,`В крупнейшем найденном пуле $${deepest.toLocaleString('ru-RU',{maximumFractionDigits:0})}. Это стоимость пула, не доступная сумма выхода.`),'Market pools','Liquidity'));
 const liquidityDomain=domain('liquidity',copy('Liquidity','Ликвидность'),deepest!==null,deepest!==null&&poolValues.length===r.market.pools.length,liquidity,copy('Liquidity is unavailable for some or all returned pools.','Для части или всех найденных пулов нет данных о ликвидности.'));

 const market:RiskReason[]=[];const moves=[r.market.change24h,r.advanced?.periods?.h1?.change];
 const h24=finite(moves[0])?Math.abs(moves[0]):null,h1=finite(moves[1])?Math.abs(moves[1]):null;
 if(h24!==null&&h24>=20||h1!==null&&h1>=10)market.push(reason('volatility',(h24??0)>=50||(h1??0)>=25?5:4,copy('Large price swings','Резкие колебания цены'),copy('Absolute move exceeds 20% in 24h or 10% in 1h. Upward moves also add volatility risk.','Движение по модулю превышает 20% за сутки или 10% за час. Рост тоже увеличивает риск волатильности.'),'Market snapshot','Activity'));
 const at=Date.parse(r.generatedAt);const dates=r.market.pools.map(p=>p.createdAt?Date.parse(p.createdAt):NaN).filter(d=>Number.isFinite(d)&&d<=at);
 const age=dates.length?(at-Math.min(...dates))/3600000:null;
 if(age!==null&&age<168)market.push(reason('young-market',age<24?5:3,copy('Short observed market history','Короткая история найденных рынков'),copy('The oldest returned pool is less than a week old. This does not establish the token’s launch date.','Самому старому найденному пулу меньше недели. Это не устанавливает дату запуска токена.'),'Pool creation times','Liquidity'));
 const marketDomain=domain('market',copy('Market history','История рынка'),moves.some(finite)||age!==null,finite(moves[0])&&age!==null,market,copy('Price history or pool age is incomplete.','История цены или возраст пулов известны не полностью.'));

 const domains=[exitDomain,controlDomain,holdersDomain,liquidityDomain,marketDomain];
 const covered=domains.filter(d=>d.known).length;
 const reasons=[...domains.flatMap(d=>d.reasons),...(providerReason?[providerReason]:[])].sort((a,b)=>b.severity-a.severity);
 const strongest=Math.max(1,...reasons.map(x=>x.severity));
 const multiplier=domains.filter(d=>d.severity>=5).length>=3;
 // Weak, incomplete evidence cannot produce an unqualified low-risk number.
 const identityConflict=r.network!=='solana'&&r.chain.codePresent===false;
 const lowEvidence=covered===5&&exitComplete&&controlDomain.complete&&liquidityDomain.complete&&distribution&&!r.holderWindow;
 const enough=!identityConflict&&(strongest>=7||(covered>=3&&(strongest>=4||lowEvidence)));
 const score=enough?Math.min(10,strongest+(multiplier?1:0)):null;
 const gaps=domains.flatMap(d=>d.gap?[d.gap]:[]);
 if(identityConflict)gaps.unshift(copy('RPC found no contract code. Resolve the token identity before assigning a score.','RPC не обнаружил код контракта. Перед оценкой нужно установить, что это адрес токена.'));
 gaps.push(copy('Future liquidity withdrawals, all token extensions, and linked ownership are not fully established.','Будущие изъятия ликвидности, все расширения токена и связанные владельцы полностью не установлены.'));
 return {version:'1.0',score,level:score===null?'unknown':score<=3?'lower':score<=6?'medium':score<=8?'high':'critical',provisional:domains.some(d=>!d.complete),covered,domains,reasons,gaps,multiplier};
}
