import {env} from 'cloudflare:workers';
import {birdeyeCached} from './birdeye-client';
import {clean,num,validAddress,formatUnits,type LensReport,type Holder,type Link} from './types';
export type IntelState={state:'ok'|'unavailable'|'not_loaded';at:string|null;detail:string};
export type TransferEvidence={from:string;to:string;amount:string;usd:number|null;hash:string;at:string;block:string|null};
export type ActiveTrader={address:string;buys:number|null;sells:number|null;volume:number|null;buyVolume:number|null;sellVolume:number|null};
export type TokenIntelligence={
 version:1;
 holders?:{state:IntelState;count:number|null;top10:number|null;items:Holder[]};
 distribution?:{state:IntelState;topN:number;count:number|null;share:number|null;items:{address:string;share:number|null}[]};
 transfers?:{state:IntelState;from:string;to:string;items:TransferEvidence[];limit:number};
 traders?:{state:IntelState;window:'24h';items:ActiveTrader[]};
 launch?:{state:IntelState;platform:string;creator:string|null;createdAt:string|null;tx:string|null;graduated:boolean|null;graduatedAt:string|null;progress:number|null};
};
const nonnegative=(v:unknown)=>{const n=num(v);return n!==null&&n>=0?n:null};
const count=(v:unknown)=>{const n=nonnegative(v);return n!==null&&Number.isSafeInteger(n)?n:null};
const share=(v:unknown)=>{const n=nonnegative(v);return n!==null&&n<=100?n:null};
const sol=(v:unknown)=>typeof v==='string'&&validAddress(v,'solana')?v:null;
const sig=(v:unknown)=>typeof v==='string'&&/^[1-9A-HJ-NP-Za-km-z]{64,88}$/.test(v)?v:null;
const when=(v:unknown)=>{const n=num(v);return n!==null&&n>0&&n<=Date.now()/1000+60?new Date(n*1000).toISOString():null};
const data=(j:any)=>{if(j?.success!==true||!j.data||typeof j.data!=='object')throw new Error('No usable research data was returned.');return j.data};
const state=(at:string):IntelState=>({state:'ok',at,detail:''});
export function normalizeIntelHolders(raw:any,address:string){
 const d=data(raw);if(!Array.isArray(d.items))throw new Error('Holder data is incomplete.');
 const seen=new Set<string>();const items:Holder[]=[];
 for(const row of d.items.slice(0,100)){
  if(row.mint!==address)throw new Error('Holder token identity mismatch.');
  const owner=sol(row.owner),dec=count(row.decimals);if(!owner||seen.has(owner)||dec===null||dec>36)continue;
  if(row.is_scaled_ui_token===true&&num(row.multiplier)!==1)continue;
  // Wallet-mode live responses use decimal token units in numeric `amount`.
  // The documented account-mode raw integer must never be treated as wallet units.
  const units=nonnegative(row.ui_amount??(typeof row.amount==='number'&&Object.hasOwn(row,'amount_usd')?row.amount:null));
  if(units===null||units===0)continue;seen.add(owner);
  items.push({address:owner,balance:String(units),share:null,label:'Holder wallet',kind:'unclassified',source:'Birdeye'});
 }
 if(d.items.length&&!items.length)throw new Error('Holder balances could not be verified.');
 return {count:count(d.holder),top10:share(d.top10_hold_percent??d.top10HoldPercent),items};
}
export function normalizeDistribution(raw:any,address:string){
 const d=data(raw);if(d.token_address!==address||d.mode!=='top')throw new Error('Distribution token identity mismatch.');
 if(!Array.isArray(d.holders)||!d.summary)throw new Error('Distribution data is incomplete.');
 const seen=new Set<string>();const items=d.holders.slice(0,10).flatMap((h:any)=>{const a=sol(h.wallet);if(!a||seen.has(a))return [];seen.add(a);return [{address:a,share:share(h.percent_of_supply)}]});
 const total=share(d.summary.percent_of_supply),n=count(d.summary.wallet_count);
 if(n!==null&&n>10||total!==null&&items.every((x:any)=>x.share!==null)&&items.reduce((s:number,x:any)=>s+x.share,0)>total+.1)throw new Error('Distribution values are inconsistent.');
 return {topN:10,count:n,share:total,items};
}
export function normalizeTransfers(raw:any,address:string,from:number,to:number){
 const d=data(raw);if(!Array.isArray(d))throw new Error('Transfer data is incomplete.');
 const seen=new Set<string>();const items:TransferEvidence[]=[];
 for(const r of d.slice(0,100)){
  if(r.token_address!==address)throw new Error('Transfer token identity mismatch.');
  const a=sol(r.from_address),b=sol(r.to_address),hash=sig(r.tx_hash),at=when(r.unix_time),time=num(r.unix_time),units=nonnegative(r.ui_amount);
  if(r.action!=='transfer'||!a||!b||a===b||!hash||!at||time===null||time<from||time>to||units===null||units===0)continue;
  const key=[hash,a,b,r.amount,r.from_token_account,r.to_token_account].join(':');if(seen.has(key))continue;seen.add(key);
  items.push({from:a,to:b,amount:String(units),usd:nonnegative(r.value),hash,at,block:count(r.block_number)?.toString()||null});
 }
 return {from:new Date(from*1000).toISOString(),to:new Date(to*1000).toISOString(),items:items.sort((a,b)=>b.at.localeCompare(a.at)),limit:100};
}
export function normalizeTraders(raw:any,address:string){
 const d=data(raw);if(!Array.isArray(d.items))throw new Error('Trader data is incomplete.');const seen=new Set<string>();
 return {window:'24h' as const,items:d.items.slice(0,10).flatMap((r:any)=>{if(r.tokenAddress!==address)throw new Error('Trader token identity mismatch.');const a=sol(r.owner);if(!a||seen.has(a))return [];seen.add(a);return [{address:a,buys:count(r.tradeBuy),sells:count(r.tradeSell),volume:nonnegative(r.volumeUsd),buyVolume:nonnegative(r.volumeBuyUSD),sellVolume:nonnegative(r.volumeSellUSD)}]})};
}
export function normalizeLaunch(raw:any,address:string){const d=data(raw);if(d.address!==address)throw new Error('Launch token identity mismatch.');const m=d.meme_info;if(!m||typeof m!=='object')throw new Error('Launch information is not available for this token.');return {platform:clean(m.platform_name||m.source||m.platform_id,70),creator:sol(m.creator),createdAt:when(m.creation_time)||when(m.created_at?.block_time),tx:sig(m.created_at?.tx_hash),graduated:typeof m.graduated==='boolean'?m.graduated:null,graduatedAt:when(m.graduated_time)||when(m.graduated_at?.block_time),progress:share(m.progress_percent)};}
export function transferLinks(items:TransferEvidence[],holders:Holder[]):Link[]{const included=new Set(holders.map(h=>h.address)),edges=new Map<string,Link>();for(const t of items){if(!included.has(t.from)||!included.has(t.to)||t.from===t.to)continue;const key=t.from+':'+t.to;const old=edges.get(key);edges.set(key,{from:t.from,to:t.to,transfers:(old?.transfers||0)+1,source:'Birdeye',txHash:t.hash,at:t.at,amount:t.amount});}return [...edges.values()]}
export async function enrichIntelligence(r:LensReport,deep=false){
 if(r.network!=='solana')return;
 if(!env.BIRDEYE_API_KEY){if(deep)r.intelligence={version:1,holders:{state:{state:'unavailable',at:null,detail:'Extended research is not connected.'},count:null,top10:null,items:[]}};return;}
 const intel:TokenIntelligence={version:1};r.intelligence=intel;
 const run=async(key:'holders'|'distribution'|'transfers'|'traders'|'launch',path:string,cost:number,ttl:number,normalize:(j:any)=>any,body?:unknown)=>{
  const cacheKey=`be-intel-v1:${r.address}:${key}`;try{const result=await birdeyeCached(cacheKey,ttl,path,{cost,chain:'solana',body},normalize);(intel as any)[key]={...result.data,state:state(result.at)};r.sources.push({id:'intel-'+key,name:'Birdeye '+key,state:'ok',detail:'Bounded token research. Inspect the observation time and coverage.',url:'https://data.birdeye.so/docs/guides/data-accessibility-by-packages',fetchedAt:new Date().toISOString(),observedAt:result.at});}
  catch(e){const detail=e instanceof Error?e.message:'Research temporarily unavailable.';(intel as any)[key]={state:{state:'unavailable',at:null,detail}};r.sources.push({id:'intel-'+key,name:'Birdeye '+key,state:'unavailable',detail,url:'https://data.birdeye.so/docs/guides/data-accessibility-by-packages',fetchedAt:new Date().toISOString()})}
 };
 // Sequenced, cached calls leave space for charts on the Standard request allowance.
 await run('holders',`/defi/v3/token/holder?address=${r.address}&mode=wallet&get_holder_infos=false&ui_amount_mode=raw&offset=0&limit=100`,30,600000,j=>normalizeIntelHolders(j,r.address));
 await run('launch',`/defi/v3/token/meme/detail/single?address=${r.address}`,15,3600000,j=>normalizeLaunch(j,r.address));
 if(deep){
  await run('distribution',`/holder/v1/distribution?token_address=${r.address}&address_type=wallet&mode=top&top_n=10&include_list=true&offset=0&limit=10`,30,600000,j=>normalizeDistribution(j,r.address));
  const to=Math.floor(Date.now()/1000),from=to-86400;
  await run('transfers','/token/v1/transfer',8,120000,j=>normalizeTransfers(j,r.address,from,to),{token_address:r.address,time_from:from,time_to:to,limit:100});
  await run('traders',`/defi/v2/tokens/top_traders?address=${r.address}&time_frame=24h&sort_type=desc&sort_by=volume_usd&offset=0&limit=10&ui_amount_mode=raw&get_holders_networth=false`,25,300000,j=>normalizeTraders(j,r.address));
 }
 const h=intel.holders;
 if(h?.state.state==='ok'&&h.items.length){
  // Retain only per-address supply shares with their own source. No price/FDV denominator.
  const existing=new Map(r.holders.items.map(x=>[x.address,x]));
  for(const item of h.items){const old=existing.get(item.address);if(old){item.kind=old.kind;item.label=old.label;item.share=old.share;item.shareSource=old.shareSource||old.source;}}
  if(intel.distribution?.state.state==='ok')for(const item of h.items){const d=intel.distribution.items.find(x=>x.address===item.address);if(d&&d.share!==null){item.share=d.share;item.shareSource='Birdeye distribution';}}
  const outside=r.holders.items.filter(old=>!h.items.some(item=>item.address===old.address)&&old.share!==null);r.holders.items=[...h.items,...outside];r.holders.source=h.items.some(x=>x.shareSource&&x.shareSource!=='Birdeye distribution')?'Birdeye / retained holder evidence':'Birdeye';r.holders.total=h.count??r.holders.total;if(h.count!==null)r.holders.countSource='Birdeye';r.holders.updatedAt=h.state.at;r.holders.scope='Up to 100 indexed holder wallets, plus earlier evidence where available. Balances and supply shares may have different observation times. This is not a complete ownership map.';
  if(intel.transfers?.state.state==='ok')r.holders.links=transferLinks(intel.transfers.items,h.items);
 }
 if(intel.transfers?.state.state==='ok')r.activity.transfers=intel.transfers.items.map(x=>({from:x.from,to:x.to,amount:x.amount,hash:x.hash,at:x.at}));
 if(intel.launch?.state.state==='ok'&&!r.creator.address)r.creator.address=intel.launch.creator;
}
