import type {WalletPerformance} from './wallet-types';
export type WalletLeader={rank:number;address:string;network:'solana';realized:number|null;unrealized:number|null;total:number|null;volume:number|null;trades:number|null;performance:WalletPerformance|null};
export type WalletLeaderboard={state:'ok'|'unavailable';rows:WalletLeader[];at:string|null;detail:string;period:'30d';minimumRealized:1000;scope:'indexed-solana-wallets'};
export type WalletSwapAlert={id:string;walletId:string;wallet:string;label:string;network:'solana';kind:'swap';received:{address:string;symbol:string;amount:number};spent:{address:string;symbol:string;amount:number};usd:number|null;hash:string;protocol:string;at:string;seen:boolean};
export type WalletHoldingAlert={id:string;walletId:string;wallet:string;label:string;network:'solana';kind:'holding_change';token:{address:string;symbol:string};change:'opened'|'increased'|'reduced'|'closed';before:string;after:string;decimals:number;fromAt:string;at:string;seen:boolean};
export type WalletAlert=WalletSwapAlert|WalletHoldingAlert;
export type BackgroundStatus={enabled:boolean;lastRun:string|null;lastSuccess:string|null;checked:number;error:string|null;healthy:boolean;intervalSeconds:number;batchSize:number};
export type WalletMonitor={id:string;address:string;network:string;label:string;enabled:boolean;minUsd:number;lastChecked:string|null;error:string|null;backlog:boolean;gap:boolean;startedAt:string};
export type WalletFeed={items:WalletAlert[];monitors:WalletMonitor[];unread:number;checked?:number;detail?:string;background?:BackgroundStatus};
