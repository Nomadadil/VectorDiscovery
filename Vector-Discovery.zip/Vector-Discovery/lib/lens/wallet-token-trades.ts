import {birdeyeCached} from './birdeye-client';
import {normalizeWalletTrades} from './wallet-alerts';
import {swaps} from './wallets';
import {num,sameAddress,validAddress,type LensReport} from './types';
import type {ObservedSwap} from './wallet-types';
export type WalletTokenTrades={state:'ok'|'unavailable';wallet:string;token:string;trades:ObservedSwap[];at:string;from:number;to:number;offset:number;nextOffset:number|null;scanned:number;scope:'wallet-30d'|'pool-24h';hasMore:boolean;detail:string};
// Share the wallet-wide page cache between assets. Filter by the mint, never by ticker.
export function normalizeTokenTradePage(raw:any,wallet:string,from:number,to:number){
 const verified=normalizeWalletTrades(raw,wallet,from,to);
 const records=new Map<string,any>();const index=(value:unknown)=>{const n=num(value);return n!==null&&Number.isSafeInteger(n)&&n>=0?n:''};
 for(const x of raw.data.items){const key=[x.tx_hash,index(x.ins_index),index(x.inner_ins_index),x.quote?.type_swap==='to'?x.quote?.address:x.base?.address,x.quote?.type_swap==='from'?x.quote?.address:x.base?.address].join(':');records.set(key,x)}
 return {scanned:raw.data.items.length,hasMore:verified.hasNext,items:verified.items.map(x=>{const original=records.get(x.eventKey);return {...x,pool:typeof original?.address==='string'?original.address:'',receivedPrice:num(original?.[original?.base?.address===x.received.address?'base':'quote']?.price),spentPrice:num(original?.[original?.base?.address===x.spent.address?'base':'quote']?.price)}})};
}
export function tokenTradeMarkers(page:ReturnType<typeof normalizeTokenTradePage>,token:string):ObservedSwap[]{return page.items.flatMap(x=>{
 const buy=x.received.address===token,sell=x.spent.address===token;if(buy===sell)return [];
 const leg=buy?x.received:x.spent,rawPrice=buy?x.receivedPrice:x.spentPrice;
 return [{id:x.eventKey,wallet:x.wallet,side:buy?'buy' as const:'sell' as const,time:Date.parse(x.at)/1000,at:x.at,hash:x.hash,amount:String(leg.amount),price:rawPrice!==null&&rawPrice>0?rawPrice:null,usd:x.usd,pool:x.pool}];
 }).sort((a,b)=>a.time-b.time||a.id.localeCompare(b.id));}
export async function walletTokenTrades(report:LensReport,wallet:string,offset=0,before?:number):Promise<WalletTokenTrades>{
 if(!validAddress(wallet,report.network))throw new Error('Enter a valid wallet address on the selected network.');
 const now=Math.floor(Date.now()/1000),to=before===undefined?Math.floor(now/300)*300:before;
 if(!Number.isSafeInteger(offset)||offset<0||offset>900||offset%100!==0||!Number.isSafeInteger(to)||to>now||to<now-86400)throw new Error('Refresh the wallet activity window.');
 const from=to-30*86400;
 const base:WalletTokenTrades={state:'unavailable',wallet,token:report.address,trades:[],at:new Date().toISOString(),from,to,offset,nextOffset:null,scanned:0,scope:report.network==='solana'?'wallet-30d':'pool-24h',hasMore:false,detail:''};
 try{
  if(report.network!=='solana'){const result=await swaps(report);if(result.state!=='ok')throw new Error(result.detail);return {...base,state:'ok',at:result.fetchedAt,from:result.earliestAt?Date.parse(result.earliestAt)/1000:to-86400,trades:result.trades.filter(t=>sameAddress(t.wallet,wallet,report.network)),scanned:result.trades.length,detail:'Recent selected-pool swaps only, not the full wallet history.'}}
  const result=await birdeyeCached(`wallet-chart-page-v1:${wallet}:${to}:${offset}`,300000,`/trader/txs/seek_by_time?address=${wallet}&tx_type=swap&before_time=${to}&offset=${offset}&limit=100&ui_amount_mode=raw`,{cost:10,chain:'solana'},raw=>normalizeTokenTradePage(raw,wallet,from,to));
  const page=result.data;return {...base,state:'ok',at:result.at,trades:tokenTradeMarkers(page,report.address),scanned:page.scanned,hasMore:page.hasMore,nextOffset:page.hasMore&&offset<900?offset+100:null,detail:'Observed swap legs, filtered by token mint. Transfers are excluded. Not proof of a net position entry or exit.'};
 }catch(e){return {...base,detail:e instanceof Error?e.message:'Wallet activity is unavailable.'}}
}
