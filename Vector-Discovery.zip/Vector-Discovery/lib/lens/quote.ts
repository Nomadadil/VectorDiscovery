import {fetchJson} from './http';
import {db} from './storage';
import {readCache,writeCache} from './cache';
import {decimalUnits,clean,num,type LensReport,type Quote} from './types';
const SOL='So11111111111111111111111111111111111111112';
const USDC='EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v';
const NATIVE='0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE';
const positive=(v:unknown)=>typeof v==='string'&&/^\d+$/.test(v)&&BigInt(v)>BigInt(0);
export function normalizeJupiter(q:any,input:string,output:string,units:string){
 if(q?.inputMint!==input||q?.outputMint!==output||q?.inAmount!==units||!positive(q?.outAmount)||q?.errorCode)throw new Error('No usable route was returned for this amount. This is not by itself a honeypot finding.');
 return {buyAmount:q.outAmount as string,minBuyAmount:positive(q.otherAmountThreshold)?q.otherAmountThreshold:undefined,route:[...new Set<string>((q.routePlan||[]).map((x:any)=>clean(x.swapInfo?.label,50)).filter(Boolean))].slice(0,10),estimatedImpact:num(q.priceImpact)===null?null:String(num(q.priceImpact)),feeBps:num(q.feeBps)};
}
export function normalizeKyber(q:any,input:string,output:string,units:string){const s=q?.data?.routeSummary;
 if(q?.code!==0||s?.tokenIn?.toLowerCase()!==input.toLowerCase()||s?.tokenOut?.toLowerCase()!==output.toLowerCase()||String(s?.amountIn)!==units||!positive(s?.amountOut))throw new Error('No usable route was returned for this amount. This is not by itself a honeypot finding.');
 return {buyAmount:s.amountOut as string,route:[...new Set<string>((s.route||[]).flat().map((x:any)=>clean(x.exchange,50)).filter(Boolean))].slice(0,10),estimatedImpact:null};
}
export async function quote(report:LensReport,amount:string):Promise<Quote>{
 const provider=report.network==='solana'?'Jupiter':'KyberSwap';const result:Quote={state:'unavailable',detail:'',provider,at:new Date().toISOString(),amount};
 if(report.mode==='demo')return {...result,state:'unsupported',detail:'Inspect a real token to request a position-size quote.'};
 if(report.token.decimals===null)return {...result,detail:'Token precision could not be verified. An exact amount cannot be quoted.'};
 const units=decimalUnits(amount,report.token.decimals),key=`route:v2:${report.network}:${report.address}:${units}`;const cached=await readCache<Quote>(key,15000);if(cached)return cached.data;
 try{
 let fields:Partial<Quote>;
 if(report.network==='solana'){
  // Keyless Jupiter permits 0.5 rps. Never pass a wallet/taker or request execution.
  const now=Date.now(),slot=await db().prepare(`INSERT INTO lens_rate_limits (key,window,count) VALUES ('jupiter-next-request',?,0) ON CONFLICT(key) DO UPDATE SET window=MAX(window+2100,excluded.window) WHERE window<=excluded.window+6000 RETURNING window`).bind(now).first<{window:number}>();
  if(!slot)throw new Error('Research is busy. Please retry shortly.');if(slot.window>now)await new Promise(r=>setTimeout(r,slot.window-now));
  const output=report.address===SOL?USDC:SOL;const params=new URLSearchParams({inputMint:report.address,outputMint:output,amount:units,slippageBps:'50'});
  fields={...normalizeJupiter(await fetchJson('https://api.jup.ag/swap/v2/order?'+params,{},12000),report.address,output,units),buySymbol:output===SOL?'SOL':'USDC',buyDecimals:output===SOL?9:6};
 }else{
  const chain={ethereum:'ethereum',bsc:'bsc'}[report.network];
  const params=new URLSearchParams({tokenIn:report.address,tokenOut:NATIVE,amountIn:units});
  fields={...normalizeKyber(await fetchJson(`https://aggregator-api.kyberswap.com/${chain}/api/v1/routes?${params}`,{headers:{'x-client-id':'Vector-Discovery','user-agent':'Vector-Discovery-quote-research/1.0'}},12000),report.address,NATIVE,units),buySymbol:report.network==='bsc'?'BNB':'ETH',buyDecimals:18};
 }
 const response:Quote={...result,...fields,state:'ok',at:new Date().toISOString(),detail:'Indicative router quote, not a completed trade or a wallet-specific simulation. Gas and price can change.'};await writeCache(key,response);return response;
 }catch(e){return {...result,detail:e instanceof Error?e.message:'Quote is unavailable.'}}
}
