import {fetchJson} from './http';
import {readCache,writeCache} from './cache';
import {db,throttle} from './storage';
import {NETWORKS,num,sameAddress,validAddress,clean,type LensReport,type Network} from './types';
import {normalizeChartPools,type ChartPool} from './chart';
import type {FollowedWallet,ObservedSwap,SwapWindow} from './wallet-types';
export function normalizeSwaps(raw:any,network:Network,address:string,pool:string):ObservedSwap[]{
 const rows:ObservedSwap[]=[];const seen=new Set<string>();
 for(const item of Array.isArray(raw?.data)?raw.data:[]){const a=item?.attributes;if(item?.type!=='trade'||!a||typeof item.id!=='string'||seen.has(item.id))continue;
  const to=typeof a.to_token_address==='string'&&sameAddress(a.to_token_address,address,network),from=typeof a.from_token_address==='string'&&sameAddress(a.from_token_address,address,network);if(to===from)continue;
  const side=to?'buy':'sell',leg=to?'to':'from';const price=num(a[`price_${leg}_in_usd`]),amount=a[`${leg}_token_amount`],usd=num(a.volume_in_usd),time=Date.parse(a.block_timestamp)/1000,wallet=a.tx_from_address,hash=a.tx_hash;
  if(!validAddress(wallet||'',network)||typeof hash!=='string'||!(network==='solana'?/^[1-9A-HJ-NP-Za-km-z]{64,90}$/:/^0x[0-9a-fA-F]{64}$/).test(hash)||!Number.isFinite(time)||time<=0||time>Date.now()/1000+60||price===null||price<=0||typeof amount!=='string'||!/^\d+(\.\d+)?$/.test(amount)||!(Number(amount)>0))continue;
  seen.add(item.id);rows.push({id:item.id,wallet:network==='solana'?wallet:wallet.toLowerCase(),side,time,at:new Date(time*1000).toISOString(),hash,amount,price,usd:usd!==null&&usd>=0?usd:null,pool});
 }return rows.sort((a,b)=>a.time-b.time||a.id.localeCompare(b.id)).slice(-300);
}
export async function swaps(report:LensReport,requestedPool?:string):Promise<SwapWindow>{
 const result:SwapWindow={state:'unavailable',detail:'',network:report.network,address:report.address,pool:null,pools:[],trades:[],fetchedAt:new Date().toISOString(),earliestAt:null,latestAt:null,source:'GeckoTerminal',maxRows:300,allHistory:false};
 const root=`https://api.geckoterminal.com/api/v2/networks/${NETWORKS[report.network].gecko}`;
 try{let pools=await readCache<ChartPool[]>(`gt:pools:${report.network}:${report.address}`,300000);if(!pools){await throttle('gecko-upstream',9);const raw=await fetchJson(`${root}/tokens/${report.address}/pools?page=1`,{headers:{accept:'application/json;version=20230203'}},12000);pools={data:normalizeChartPools(raw,report.network,report.address),at:Date.now()};await writeCache(`gt:pools:${report.network}:${report.address}`,pools.data)}
  result.pools=pools.data;result.pool=requestedPool?pools.data.find(p=>sameAddress(p.address,requestedPool,report.network))||null:pools.data.find(p=>report.market.pools.some(x=>x.priceUsd!==null&&x.priceUsd===report.market.priceUsd&&sameAddress(x.address,p.address,report.network)))||pools.data[0]||null;if(!result.pool)throw new Error('No supported pool is available for swap history.');
  const key=`gt:trades:${report.network}:${report.address}:${result.pool.address}`;const cached=await readCache<SwapWindow>(key,65000);if(cached)return cached.data;
  await throttle('gecko-upstream',9);const raw=await fetchJson(`${root}/pools/${result.pool.address}/trades`,{headers:{accept:'application/json;version=20230203'}},12000);
  if(!Array.isArray(raw?.data))throw new Error('The trade provider returned an incomplete response.');result.trades=normalizeSwaps(raw,report.network,report.address,result.pool.address);result.state='ok';result.earliestAt=result.trades[0]?.at||null;result.latestAt=result.trades.at(-1)?.at||null;result.fetchedAt=new Date().toISOString();result.detail='Up to 300 recent swaps in this pool, within 24 hours. Not a complete wallet history.';await writeCache(key,result);return result;
 }catch(e){result.detail=e instanceof Error?e.message:'Swap history is unavailable.';return result}
}
const row=(r:any):FollowedWallet=>({id:r.id,network:r.network,address:r.address,label:r.label,createdAt:r.created_at});
export async function listWallets(user:string){const r=await db().prepare('SELECT id,network,address,label,created_at FROM lens_wallets WHERE user_id=? ORDER BY created_at DESC LIMIT 50').bind(user).all();return r.results.map(row)}
export async function followWallet(user:string,network:Network,address:string,label:string){
 if(!Object.hasOwn(NETWORKS,network)||!validAddress(address,network))throw new Error('Enter a valid wallet address on the selected network.');address=network==='solana'?address:address.toLowerCase();label=clean(label,40).trim();
 await db().prepare('INSERT INTO lens_wallets (id,user_id,network,address,label,created_at) SELECT ?,?,?,?,?,? WHERE (SELECT COUNT(*) FROM lens_wallets WHERE user_id=?)<50 OR EXISTS (SELECT 1 FROM lens_wallets WHERE user_id=? AND network=? AND address=?) ON CONFLICT(user_id,network,address) DO UPDATE SET label=excluded.label').bind(crypto.randomUUID(),user,network,address,label,new Date().toISOString(),user,user,network,address).run();
 const items=await listWallets(user);if(!items.some(w=>w.network===network&&w.address===address))throw new Error('Wallet Watch supports 50 addresses per account.');return items;
}
export async function unfollowWallet(user:string,id:string){await db().batch([db().prepare('DELETE FROM lens_wallet_balances WHERE wallet_id=? AND user_id=?').bind(id,user),db().prepare('DELETE FROM lens_wallet_alerts WHERE wallet_id=? AND user_id=?').bind(id,user),db().prepare('DELETE FROM lens_wallet_monitors WHERE wallet_id=? AND user_id=?').bind(id,user),db().prepare('DELETE FROM lens_wallets WHERE id=? AND user_id=?').bind(id,user)]);return listWallets(user)}
