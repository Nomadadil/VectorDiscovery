import {assessRisk} from './risk';
import {NETWORKS,type LensReport} from './types';
export type CardLocale='en'|'ru';
export type CardFormat='feed'|'story'|'wide';
export const CARD_FORMATS={feed:{width:1080,height:1350},story:{width:1080,height:1920},wide:{width:1200,height:675}} as const;
export function cardContent(r:LensReport,locale:CardLocale){
 const ru=locale==='ru',risk=assessRisk(r),c=(en:string,ruText:string)=>ru?ruText:en;
 const labels={unknown:c('Not rated','Без оценки'),lower:c('Lower risk','Риск ниже'),medium:c('Medium risk','Средний риск'),high:c('High risk','Высокий риск'),critical:c('Very high risk','Очень высокий риск')};
 const findings=risk.reasons.slice(0,3).map(x=>({title:x.title[locale],detail:x.detail[locale],tone:x.severity>=7?'bad':'warn'}));
 if(findings.length<3)findings.push({title:r.simulation.success===true?c('A sell test completed','Тест продажи завершён'):c('Sale not established','Продажа не подтверждена'),detail:r.simulation.success===true?c('Only the tested route and amount. Your position was not tested.','Только проверенные маршрут и сумма. Ваша позиция не тестировалась.'):c('No usable completed simulation. A missing result is not a pass.','Нет пригодного результата симуляции. Это не пройденная проверка.'),tone:r.simulation.success===true?'neutral':'warn'});
 if(findings.length<3)findings.push({title:c('Liquidity is not exit depth','Ликвидность не равна выходу'),detail:c('Reported pool value does not establish what your sale would return.','Стоимость пула не определяет сумму, которую вы получите при продаже.'),tone:'neutral'});
 if(findings.length<3)findings.push({title:c('Ownership remains partial','Владельцы известны не полностью'),detail:c('Holder samples do not establish every owner or connected wallet.','Выборка держателей не устанавливает всех владельцев и связи.'),tone:'neutral'});
 return {risk,label:labels[risk.level],findings,network:NETWORKS[r.network].name,stamp:new Date(r.generatedAt).toISOString().slice(0,16).replace('T',' ')+' UTC',coverage:c(`${risk.covered}/5 evidence areas observed`,`${risk.covered}/5 областей с данными`),limitation:risk.gaps[0]?.[locale]||c('Future changes remain unknown.','Будущие изменения неизвестны.'),caption:c(`${r.token.symbol} · ${NETWORKS[r.network].name}\nVector Discovery: ${labels[risk.level]}${risk.score===null?'':` · ${risk.score}/10`}.\n${findings.map(x=>'• '+x.title).join('\n')}\nObserved ${new Date(r.generatedAt).toISOString()}.\nContract: ${r.address}\nPartial evidence. Research, not a buy signal.`,`${r.token.symbol} · ${NETWORKS[r.network].name}\nVector Discovery: ${labels[risk.level]}${risk.score===null?'':` · ${risk.score}/10`}.\n${findings.map(x=>'• '+x.title).join('\n')}\nСнимок ${new Date(r.generatedAt).toISOString()}.\nКонтракт: ${r.address}\nДанные неполны. Исследование, не сигнал к покупке.`)};
}
export async function renderShareCard(r:LensReport,locale:CardLocale,format:CardFormat):Promise<Blob>{
 await document.fonts.load('500 32px Inter');await document.fonts.ready;
 const size=CARD_FORMATS[format],canvas=document.createElement('canvas');canvas.width=size.width;canvas.height=size.height;
 const x=canvas.getContext('2d');if(!x)throw new Error('Image export is unavailable in this browser.');
 const data=cardContent(r,locale),ru=locale==='ru',c=(en:string,ruText:string)=>ru?ruText:en,wide=format==='wide',story=format==='story';
 const ink='#F5F8FF',muted='#ACBADD',line='#304373',accent=data.risk.score===null?'#ACBADD':data.risk.score>=7?'#EF98A2':data.risk.score>=4?'#EDBE79':'#4BD7BE';
 x.fillStyle='#101F54';x.fillRect(0,0,canvas.width,canvas.height);x.textBaseline='top';
 const font=(px:number,weight=400)=>{x.font=`${weight} ${px}px Inter, sans-serif`;};
 const text=(str:string,px:number,left:number,top:number,color=ink,weight=400,max?:number)=>{font(px,weight);x.fillStyle=color;if(max){while(x.measureText(str).width>max&&px>14){font(--px,weight)}}x.fillText(str,left,top);};
 const wrap=(str:string,left:number,top:number,width:number,px:number,lines:number,color=muted,weight=400)=>{
  font(px,weight);x.fillStyle=color;const words=str.split(/\s+/),rows:string[]=[];let row='';
  for(const word of words){
   if(x.measureText(word).width>width){if(row){rows.push(row);row='';}let part='';for(const ch of word){if(x.measureText(part+ch).width>width){rows.push(part);part='';}part+=ch;}row=part;continue;}
   const next=row?row+' '+word:word;if(row&&x.measureText(next).width>width){rows.push(row);row=word;}else row=next;
  }
  if(row)rows.push(row);for(let i=0;i<Math.min(lines,rows.length);i++){let value=rows[i];if(i===lines-1&&rows.length>lines){while(x.measureText(value+'…').width>width)value=value.slice(0,-1);value=value.trimEnd()+'…';}x.fillText(value,left,top+i*px*1.32);}

 };
 const rule=(left:number,top:number,width:number)=>{x.fillStyle=line;x.fillRect(left,top,width,1);};
 const round=(left:number,top:number,w:number,h:number,radius:number,color:string)=>{x.fillStyle=color;x.beginPath();x.roundRect(left,top,w,h,radius);x.fill();};
 const pad=wide?48:64,offset=story?200:0;
 const logo=await new Promise<HTMLImageElement|null>(resolve=>{const image=new Image();image.onload=()=>resolve(image);image.onerror=()=>resolve(null);image.src='/brand/symbol.svg';});
 if(logo)x.drawImage(logo,pad,offset+(wide?33:37),wide?37:45,wide?37:45);
 text('Vector Discovery',wide?28:36,pad+(wide?51:61),offset+(wide?36:42),ink,550);
 text(c('ETH · BSC · SOL','ETH · BSC · SOL'),wide?13:19,wide?916:750,offset+(wide?44:51),muted,500);
 rule(pad,offset+(wide?92:108),size.width-pad*2);
 const demo=r.mode==='demo';
 text(demo?c('EXAMPLE · NOT LIVE DATA','ПРИМЕР · НЕ ЖИВЫЕ ДАННЫЕ'):c('TOKEN RESEARCH SNAPSHOT','СНИМОК АНАЛИЗА АКТИВА'),wide?14:21,pad,offset+(wide?121:142),demo?'#EDBE79':muted,500);
 wrap(r.token.name,pad,offset+(wide?155:182),wide?430:950,wide?46:57,2,ink,550);
 text(`${r.token.symbol}  /  ${data.network}`,wide?20:27,pad,offset+(wide?272:332),muted,400,wide?430:950);
 const scoreY=offset+(wide?325:397);
 text(data.risk.score===null?'—':String(data.risk.score),wide?81:94,pad,scoreY,accent,500);
 text('/10',wide?28:33,pad+(data.risk.score===10?110:69),scoreY+(wide?44:48),muted,400);
 text(data.label,wide?24:32,pad+(wide?155:195),scoreY+9,ink,500,wide?280:735);
 text(c('RISK · 1 LOWER / 10 HIGHER','РИСК · 1 НИЖЕ / 10 ВЫШЕ'),wide?12:19,pad+(wide?155:195),scoreY+(wide?44:57),muted,500,wide?280:735);
 if(!wide){for(let i=0;i<10;i++)round(pad+i*96,offset+514,85,5,2,data.risk.score!==null&&i<data.risk.score?accent:line);text(c('Partial assessment','Неполная оценка')+' · '+data.coverage,20,pad,offset+548,muted);}
 else {text(data.coverage,15,pad,offset+427,muted);text(c('Partial assessment','Неполная оценка'),14,pad,offset+452,muted);}
 const left=wide?548:pad,fw=wide?604:952,fy=offset+(wide?123:611),rowH=wide?127:139;
 for(const [i,f] of data.findings.entries()){
  const y=fy+i*rowH;rule(left,y,fw);
  text('0'+(i+1),wide?13:18,left,y+20,muted,500);
  wrap(f.title,left+(wide?37:49),y+17,fw-(wide?37:49),wide?21:26,2,ink,500);
  wrap(f.detail,left+(wide?37:49),y+(wide?78:86),fw-(wide?37:49),wide?16:19,2,muted);
 }
 const footer=offset+(wide?525:1061);
 rule(pad,footer,size.width-pad*2);
 text(c('LIMITS REMAIN','ОГРАНИЧЕНИЯ ОСТАЮТСЯ'),wide?12:17,pad,footer+18,accent,550);
 wrap(data.limitation,pad+(wide?167:244),footer+16,size.width-pad*2-(wide?167:244),wide?15:19,2,muted);
 text(data.stamp,wide?13:18,pad,footer+(wide?68:90),muted);
 text(c('Research, not a buy signal.','Исследование, не сигнал к покупке.'),wide?13:18,wide?808:571,footer+(wide?68:90),muted,400,wide?344:445);
 text(r.address,wide?14:20,pad,footer+(wide?99:130),ink,400,size.width-pad*2);
 text(c('REPORT','ОТЧЁТ')+' '+r.id,wide?10:14,pad,footer+(wide?122:164),muted);
 if(story){text(c('READ THE SIGNALS. KNOW THE LIMITS.','ИЗУЧАЙ СИГНАЛЫ. ЗНАЙ ОГРАНИЧЕНИЯ.'),24,pad,1653,ink,500,952);rule(pad,1713,952);}
 const blob=await new Promise<Blob|null>(resolve=>canvas.toBlob(resolve,'image/png'));if(!blob)throw new Error('Image export failed.');return blob;
}
export function cardFilename(r:LensReport,format:CardFormat,locale:CardLocale){return `Vector-Discovery-${r.mode==='demo'?'EXAMPLE-':''}${r.token.symbol.replace(/[^a-z0-9_-]/ig,'').slice(0,20)||'token'}-${format}-${locale}-${r.id.slice(0,8)}.png`;}
export function saveCard(blob:Blob,filename:string){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);}
