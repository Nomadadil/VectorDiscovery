export class AllowanceError extends Error{
 constructor(public code:string,public resetsAt:string,message:string){super(message);this.name='AllowanceError';}
}
