import {normalizeNewPools} from './discovery-types';
import {clean,num,tri,sameAddress,validAddress,publicSourceUrl,NETWORKS,type Network} from './types';
import {SIGNAL_THRESHOLDS as T,type SignalCheck,type SignalCheckState,type SignalItem} from './signals-types';
export type SignalPool=Omit<SignalItem,'id'|'firstSeen'|'lastChecked'|'expiresAt'|'status'|'checks'|'reasons'|'lockPercent'|'lockUntil'>;
const nonnegative=(v:unknown)=>{const n=num(v);return n!==null&&n>=0?n:null};
const count=(v:unknown)=>{const n=nonnegative(v);return n!==null&&Number.isSafeInteger(n)?n:null};
const check=(id:string,state:SignalCheckState,detail:string,source:string,now:number):SignalCheck=>({id,state,detail,source,observedAt:new Date(now).toISOString()});
export function normalizeSignalPools(raw:any,network:Network,now=Date.now()):SignalPool[]{
 const page=normalizeNewPools(raw,network,1,now),map=new Map<string,any>((raw.data||[]).map((x:any)=>[x.attributes?.address,x.attributes]));
 return page.items.map(x=>{const a=map.get(x.pool),buys=count(a.transactions?.h1?.buys),sells=count(a.transactions?.h1?.sells);return {
  network,address:x.address,pool:x.pool,name:x.name,symbol:x.symbol,logo:x.logo,createdAt:x.createdAt,
  price:x.price,cap:x.cap,fdv:x.fdv,liquidity:x.liquidity,volumeH1:nonnegative(a.volume_usd?.h1),changeH1:num(a.price_change_percentage?.h1),
  buysH1:buys,sellsH1:sells,transactionsH1:buys!==null&&sells!==null?buys+sells:null,links:[]
 }});
}
export function marketChecks(p:SignalPool,maxAgeMinutes=120,now=Date.now()):SignalCheck[]{
 const rows:SignalCheck[]=[];
 if(p.network==='solana'){const age=now-Date.parse(p.createdAt);rows.push(check('pool-age',!Number.isFinite(age)?'unknown':age>=0&&age<=maxAgeMinutes*60000?'pass':'fail','Age of the observed pool; not a verified token launch time.','GeckoTerminal',now));}
 for(const [id,value,min] of [['market-cap',p.cap,T.minMarketCap],['liquidity',p.liquidity,T.minLiquidity],...(p.network==='solana'?[['hourly-buys',p.buysH1,T.minBuysH1],['hourly-sells',p.sellsH1,T.minSellsH1],['hourly-transactions',p.transactionsH1,T.minTransactionsH1]]:[])] as [string,number|null,number][]){
  rows.push(check(id,value===null?'unknown':value>=min?'pass':'fail',id==='market-cap'?'Reported market cap only; FDV is not a substitute.':id==='liquidity'?'Liquidity belongs to the selected pool.':'Rolling one-hour swap count; buys plus sells, not unique wallets.','Market snapshot',now));
 }return rows;
}
export function enrichSignalPool(p:SignalPool,raw:any,now=Date.now()){
 const pairs=Array.isArray(raw)?raw:raw?.pairs;
 if(!Array.isArray(pairs))return {pool:{...p,cap:null,fdv:null,liquidity:null,price:null,volumeH1:null,changeH1:null,buysH1:null,sellsH1:null,transactionsH1:null},ageCheck:check('token-age','unknown','Earlier pools could not be checked.','DEX Screener',now)};
 const valid=pairs.filter((x:any)=>x?.chainId===NETWORKS[p.network].dex&&[x.baseToken?.address,x.quoteToken?.address].some(a=>typeof a==='string'&&sameAddress(a,p.address,p.network))&&validAddress(x.pairAddress||'',p.network));
 const primary=valid.find((x:any)=>sameAddress(x.pairAddress,p.pool,p.network)&&sameAddress(x.baseToken?.address||'',p.address,p.network)),links=new Map<string,{label:string;url:string}>();
 for(const x of [...(primary?.info?.websites||[]),...(primary?.info?.socials||[])]){const url=publicSourceUrl(x.url);if(url)links.set(url,{url,label:clean(x.label||x.type||'Website',30)});}
 const buys=count(primary?.txns?.h1?.buys),sells=count(primary?.txns?.h1?.sells);
 const updated={...p,cap:nonnegative(primary?.marketCap),fdv:nonnegative(primary?.fdv),liquidity:nonnegative(primary?.liquidity?.usd),price:nonnegative(primary?.priceUsd),volumeH1:nonnegative(primary?.volume?.h1),changeH1:num(primary?.priceChange?.h1),buysH1:buys,sellsH1:sells,transactionsH1:buys!==null&&sells!==null?buys+sells:null,logo:publicSourceUrl(primary?.info?.imageUrl)||p.logo,links:[...links.values()].slice(0,8)};
 const knownEarlier=valid.some((x:any)=>{const t=num(x.pairCreatedAt);return t!==null&&t>0&&t<now-T.maxAgeMinutes*60000;});
 return {pool:updated,ageCheck:check('token-age',knownEarlier?'fail':valid.length?'pass':'unknown',knownEarlier?'An older pool for this token was found.':'No older pool was found in the returned sample; token mint time is unverified.','DEX Screener',now)};
}
export function goPlusResult(raw:any,network:Network,address:string):any|null{
 if(raw?.code!==1||!raw.result||typeof raw.result!=='object')return null;
 return Object.entries(raw.result).find(([key])=>sameAddress(key,address,network))?.[1]??null;
}
export function permissionCheck(raw:any,network:Network,address:string,now=Date.now()):SignalCheck{
 const g=goPlusResult(raw,network,address),sol=network==='solana';
 const fields=sol?['mintable','freezable','closable','balance_mutable_authority','default_account_state_upgradable','transfer_fee_upgradable','transfer_hook_upgradable','non_transferable']:['is_honeypot','cannot_sell_all','cannot_buy','owner_change_balance','transfer_pausable','is_mintable','hidden_owner','is_blacklisted','slippage_modifiable','personal_slippage_modifiable','trading_cooldown','selfdestruct'];
 let missing=false;const flagged:string[]=[];
 for(const f of fields){const v=tri(sol&&f!=='non_transferable'?g?.[f]?.status:g?.[f]);if(v===null)missing=true;if(v===true)flagged.push(f);}
 if(sol){if(g?.default_account_state==='2'||g?.default_account_state===2)flagged.push('frozen_default');if(g?.default_account_state!=='1'&&g?.default_account_state!==1)missing=true;if(!Array.isArray(g?.transfer_hook))missing=true;else if(g.transfer_hook.length)flagged.push('active_transfer_hook');if(!g?.transfer_fee||typeof g.transfer_fee!=='object'||Array.isArray(g.transfer_fee)||Object.keys(g.transfer_fee).length)missing=true;}
 else{for(const f of ['buy_tax','sell_tax']){const v=num(g?.[f]);if(v===null||v<0||v>1)missing=true;else if(v>.05)flagged.push(f);}if(tri(g?.is_open_source)!==true)missing=true;}
 return check('permissions',flagged.length?'fail':missing?'unknown':'pass',flagged.length?'Material transfer or control flags were returned.':missing?'Some required permission checks are unavailable.':'Required transfer and control checks returned no flags.',sol?'GoPlus Solana':'GoPlus',now);
}
export function rugCheck(raw:any,address:string,now=Date.now()):SignalCheck{
 if(!raw||raw.mint!==address||!Array.isArray(raw.risks)||tri(raw.rugged)===null)return check('rugcheck','unknown','The token risk report could not be verified.','RugCheck',now);
 const flagged=tri(raw.rugged)===true||raw.risks.some((r:any)=>/danger|warn|critical|high/i.test(clean(r.level,30)));
 const unknown=raw.risks.some((r:any)=>!/^(info|low|warn|warning|danger|critical|high)$/i.test(clean(r.level,30)));
 return check('rugcheck',flagged?'fail':unknown?'unknown':'pass',flagged?'The token report contains material risk flags.':unknown?'Some returned risk entries could not be classified.':'No material risk flags in the returned token report.','RugCheck',now);
}
export type LockEvidence={check:SignalCheck;percent:number|null;until:string|null};
const lockUnknown=(now:number):LockEvidence=>({check:check('lp-lock','unknown','Pool-specific locked or burned LP share could not be established.','Liquidity evidence',now),percent:null,until:null});
export function solanaLock(raw:any,p:SignalPool,now=Date.now()):LockEvidence{
 if(raw?.mint!==p.address||!Array.isArray(raw.markets))return lockUnknown(now);
 const m=raw.markets.find((x:any)=>x.pubkey===p.pool),lp=m?.lp;
 if(!m||![m.mintA,m.mintB].includes(p.address)||!validAddress(m.mintLP||'','solana')||m.mintLP==='11111111111111111111111111111111'||m.mintLPAccount?.isInitialized!==true||!(num(lp?.lpTotalSupply)!>0))return lockUnknown(now);
 const pct=num(lp?.lpLockedPct),supply=num(m.mintLPAccount?.supply);
 // With zero LP mint supply and an initialized LP mint, the provider's 100%
 // locked share is burn evidence. Aggregate locked percentage alone does not
 // establish whether time locks have expired, so it is not admitted below.
 if(pct===100&&supply===0)return {check:check('lp-lock','pass','Selected pool LP reported fully burned; no unlock date applies.','RugCheck',now),percent:100,until:null};
 if(pct!==null&&pct>=0&&pct<95)return {check:check('lp-lock','fail','Selected pool LP lock share is below 95%.','RugCheck',now),percent:pct,until:null};
 return lockUnknown(now);
}
export function evmLock(raw:any,p:SignalPool,now=Date.now()):LockEvidence{
 // Read the selected pair contract itself. Token-global GoPlus LP holder lists
 // cannot establish which pair they belong to and are deliberately not used.
 if(!Array.isArray(raw)||p.network==='solana')return lockUnknown(now);
 const results=new Map<number,string>();
 for(const row of raw){if(results.has(row?.id))return lockUnknown(now);if(!Number.isInteger(row?.id)||row.error||typeof row.result!=='string'||!/^0x[0-9a-fA-F]{64}$/.test(row.result)||results.has(row.id))continue;results.set(row.id,row.result);}
 if([1,2,3,4,5].some(id=>!results.has(id)))return lockUnknown(now);
 const token0='0x'+results.get(4)!.slice(-40),token1='0x'+results.get(5)!.slice(-40);
 if(![token0,token1].some(token=>sameAddress(token,p.address,p.network)))return lockUnknown(now);
 const supply=BigInt(results.get(1)!),zero=BigInt(results.get(2)!),dead=BigInt(results.get(3)!);
 if(supply<=BigInt(0)||zero+dead>supply)return lockUnknown(now);
 const percent=Number((zero+dead)*BigInt(1000000)/supply)/10000;
 if(percent<T.minLockedPercent)return lockUnknown(now); // Other scoped locks may exist.
 return {check:check('lp-lock','pass','At least 95% of selected pool LP supply is held at known burn addresses.','Selected pool contract',now),percent,until:null};
}
export function sellSimulation(raw:any,p:SignalPool,now=Date.now()):SignalCheck{
 const token=raw?.token?.address,pair=raw?.pair?.pair?.address||raw?.pairAddress,sim=raw?.simulationResult;
 if(!sameAddress(token||'',p.address,p.network)||!sameAddress(pair||'',p.pool,p.network))return check('sell-simulation','unknown','Sell simulation did not identify the selected token and pool.','Honeypot.is',now);
 if(tri(raw?.honeypotResult?.isHoneypot)===true)return check('sell-simulation','fail','A honeypot flag was returned for the selected pool.','Honeypot.is',now);
 const buy=num(sim?.buyTax),sell=num(sim?.sellTax);
 const known=raw?.simulationSuccess===true&&tri(raw?.honeypotResult?.isHoneypot)===false&&buy!==null&&sell!==null&&buy>=0&&sell>=0;
 return check('sell-simulation',!known?'unknown':buy!>5||sell!>5?'fail':'pass',known?'Provider-selected sell simulation; not your wallet or order size.':'A successful sell simulation has not been established.','Honeypot.is',now);
}
export function routeCheck(state:'ok'|'unavailable'|'unsupported'|'not_configured',now=Date.now()):SignalCheck{return check('sell-route',state==='ok'?'pass':'unknown',state==='ok'?'An indicative sell route was returned; this is not a simulated or completed sale.':'An indicative sell route has not been established.','Jupiter',now);}
export function unknownCheck(id:string,now=Date.now()):SignalCheck{return check(id,'unknown','This check is awaiting confirmation.','Pending check',now);}
export function makeSignal(p:SignalPool,checks:SignalCheck[],lock:LockEvidence|null,now=Date.now()):SignalItem{
 const qualified=checks.length>0&&checks.every(x=>x.state==='pass')&&(!lock?.until||Date.parse(lock.until)>now);const lockExpiry=lock?.until?Date.parse(lock.until):Infinity;const expires=Math.min(now+(p.network==='solana'?10:20)*60000,p.network==='solana'?Date.parse(p.createdAt)+T.maxAgeMinutes*60000:Infinity,Number.isFinite(lockExpiry)?lockExpiry:Infinity);
 return {...p,id:`${p.network}:${p.address}`,firstSeen:new Date(now).toISOString(),lastChecked:new Date(now).toISOString(),expiresAt:new Date(expires).toISOString(),status:qualified?'qualified':'pending',lockPercent:lock?.percent??null,lockUntil:lock?.until??null,checks,reasons:checks.filter(x=>x.state!=='pass').map(x=>x.id)};
}
