import {AllowanceError} from './allowance-error';
export {AllowanceError} from './allowance-error';
import {AsyncLocalStorage} from 'node:async_hooks';
import {db,digest} from './storage';

// These are application allowances, never a representation of a provider invoice.
// Raising an allowance requires a separate review of the purchased plan.
export const ECONOMY={monthlyCU:24000,dailyCU:800,personalCU:200,guestCU:80,scansPerDay:600,personalScans:20,guestScans:5,guestPoolCU:240} as const;
export const FEATURES=['scan','research','chart','portfolio','wallet-history','wallet-trades','wallet-ranking','monitoring','discovery','quote','social','other'] as const;
export type ResearchFeature=typeof FEATURES[number];
export const BUCKETS={analysis:240,charts:320,wallets:160,monitoring:80} as const;
export type BudgetBucket=keyof typeof BUCKETS;
export const isGuest=(actor:string)=>actor==='guest'||actor.startsWith('guest:');
export function bucketFor(feature:ResearchFeature):BudgetBucket{return feature==='chart'?'charts':feature==='monitoring'?'monitoring':feature==='portfolio'||feature.startsWith('wallet-')?'wallets':'analysis';}
type Context={actor:string;feature:ResearchFeature;blocked:boolean;allowance?:AllowanceError};
const context=new AsyncLocalStorage<Context>();
export const researchContext=()=>context.getStore();
export function featureFor(action:string):ResearchFeature{
 if(action==='scan')return 'scan';if(action==='retry-check')return 'research';
 if(action==='chart'||action==='signals-chart')return 'chart';if(action==='wallet-portfolio')return 'portfolio';
 if(action==='wallet-history'||action==='wallet-performance')return 'wallet-history';
 if(action==='wallet-token-trades'||action==='swaps')return 'wallet-trades';
 if(action.startsWith('wallet-leaders'))return 'wallet-ranking';
 if(action==='background-run'||action==='watch-refresh'||action==='wallet-alerts-refresh')return 'monitoring';
 if(action.startsWith('discovery')||action.startsWith('signals'))return 'discovery';
 return action==='quote'||action==='social'?action:'other';
}
export function withResearchContext<T>(actor:string,feature:ResearchFeature,work:()=>Promise<T>){return context.run({actor,feature,blocked:false},work);}
export function dayWindow(){return Math.floor(Date.now()/86400000);}
export function nextDay(){return new Date((dayWindow()+1)*86400000).toISOString();}
export function nextMonth(){const d=new Date();return new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+1,1)).toISOString();}
export async function meter(metric:'upstream'|'cu'|'cache'|'shared'|'blocked',amount=1){
 const ctx=researchContext();if(!ctx)return;
 await db().prepare(`INSERT INTO lens_usage (day,feature,metric,count) VALUES (?,?,?,?)
 ON CONFLICT(day,feature,metric) DO UPDATE SET count=count+excluded.count`).bind(dayWindow(),ctx.feature,metric,amount).run();
}
export async function deny(code:string,reset:string,message:string):Promise<never>{const e=new AllowanceError(code,reset,message),c=researchContext();if(c){c.blocked=true;c.allowance=e;}await meter('blocked');throw e;}
// Conditional UPSERT admits no request beyond the allowance, including concurrency.
export async function reserve(key:string,window:number,amount:number,limit:number){
 const row=await db().prepare(`INSERT INTO lens_rate_limits (key,window,count) SELECT ?,?,? WHERE ?<=?
 ON CONFLICT(key) DO UPDATE SET count=CASE WHEN window=excluded.window THEN count+excluded.count ELSE excluded.count END,window=excluded.window
 WHERE CASE WHEN window=excluded.window THEN count+excluded.count ELSE excluded.count END<=?
 RETURNING count`).bind(key,window,amount,amount,limit,limit).first<{count:number}>();
 return !!row&&Number.isSafeInteger(row.count)&&row.count<=limit;
}
type BudgetRule={key:string;window:number;limit:number;seed?:number;code:string;reset:string;message:string};
// D1 batch is one transaction. Admit all counters together or none, so a
// depleted shared bucket cannot silently consume someone's personal quota.
async function reserveTogether(amount:number,rules:BudgetRule[]){
 if(!Number.isSafeInteger(amount)||amount<1)throw new Error('Invalid research reservation.');
 const claim='economy-claim:'+crypto.randomUUID();
 const current='COALESCE((SELECT count FROM lens_rate_limits WHERE key=? AND window=?),?)';
 const params=rules.flatMap(r=>[r.key,r.window,r.seed||0,amount,r.limit]);
 const admission=db().prepare(`INSERT INTO lens_rate_limits (key,window,count) SELECT ?,0,1 WHERE ${rules.map(()=>current+'+?<=?').join(' AND ')}`).bind(claim,...params);
 const statements=rules.map(r=>db().prepare(`INSERT INTO lens_rate_limits (key,window,count) SELECT ?,?,? WHERE EXISTS (SELECT 1 FROM lens_rate_limits WHERE key=?)
 ON CONFLICT(key) DO UPDATE SET count=CASE WHEN window=excluded.window THEN count+? ELSE excluded.count END,window=excluded.window`).bind(r.key,r.window,(r.seed||0)+amount,claim,amount));
 const result=await db().batch([admission,...statements,db().prepare('DELETE FROM lens_rate_limits WHERE key=?').bind(claim)]);
 if(result[0].meta.changes===1)return;
 for(const r of rules){const row=await db().prepare('SELECT count FROM lens_rate_limits WHERE key=? AND window=?').bind(r.key,r.window).first<{count:number}>();if((row?.count??r.seed??0)+amount>r.limit)await deny(r.code,r.reset,r.message);}
 await deny('RESEARCH_BUSY',new Date(Date.now()+5000).toISOString(),'This check is already in progress. Please try again in a few seconds.');
}
export async function reserveFreshScan(){
 const ctx=researchContext();if(!ctx)return;const window=dayWindow(),reset=nextDay();
 await reserveTogether(1,[
  {key:'economy-scans:'+ctx.actor,window,limit:isGuest(ctx.actor)?ECONOMY.guestScans:ECONOMY.personalScans,code:'PERSONAL_SCAN_LIMIT',reset,message:'Your daily allowance for fresh token checks has been reached. Saved reports remain available. Resets at 00:00 UTC.'},
  {key:'economy-scans:global',window,limit:ECONOMY.scansPerDay,code:'SCAN_LIMIT',reset,message:'Today’s shared allowance for fresh token checks has been reached. Saved reports remain available. Resets at 00:00 UTC.'}
 ]);
}
async function bucketSeed(bucket:BudgetBucket){
 const features=FEATURES.filter(f=>bucketFor(f)===bucket);
 const row=await db().prepare(`SELECT COALESCE(SUM(count),0) AS count FROM lens_usage WHERE day=? AND metric='cu' AND feature IN (${features.map(()=>'?').join(',')})`).bind(dayWindow(),...features).first<{count:number}>();return row?.count||0;
}
export async function reserveDailyCU(cost:number){
 const ctx=researchContext();if(!ctx)return;
 const window=dayWindow(),reset=nextDay(),bucket=bucketFor(ctx.feature),d=new Date(),month=d.getUTCFullYear()*12+d.getUTCMonth();
 const legacy=await db().prepare("SELECT count FROM lens_rate_limits WHERE key='birdeye-month-budget' AND window=?").bind(month).first<{count:number}>();
 const oldGuests=await db().prepare("SELECT count FROM lens_rate_limits WHERE key='economy-cu:guest' AND window=?").bind(window).first<{count:number}>();
 const rules:BudgetRule[]=[
  {key:'economy-cu:'+ctx.actor,window,limit:isGuest(ctx.actor)?ECONOMY.guestCU:ECONOMY.personalCU,code:'PERSONAL_RESEARCH_LIMIT',reset,message:'Your daily research allowance has been reached. Saved results remain available. Resets at 00:00 UTC.'},
  {key:'economy-cu:global',window,limit:ECONOMY.dailyCU,code:'DAILY_RESEARCH_LIMIT',reset,message:'Today’s shared research allowance has been reached. Saved results remain available. Resets at 00:00 UTC.'},
  {key:'economy-bucket:'+bucket,window,limit:BUCKETS[bucket],seed:await bucketSeed(bucket),code:'FEATURE_RESEARCH_LIMIT',reset,message:'Today’s refresh allowance for this section has been reached. Other sections and saved results remain available. Resets at 00:00 UTC.'},
  {key:'birdeye-cu-budget-v1',window:month,limit:ECONOMY.monthlyCU,seed:(legacy?.count||0)*100,code:'MONTHLY_RESEARCH_LIMIT',reset:nextMonth(),message:'The monthly research allowance has been reached.'}
 ];
 if(isGuest(ctx.actor))rules.push({key:'economy-cu:guest-pool',window,limit:ECONOMY.guestPoolCU,seed:oldGuests?.count||0,code:'GUEST_RESEARCH_LIMIT',reset,message:'Today’s shared guest research allowance has been reached. Saved results remain available. Resets at 00:00 UTC.'});
 await reserveTogether(cost,rules);
}
// All external JSON requests from the Vector Discovery HTTP routes pass this gate. Existing
// per-provider minute throttles stay in place; this adds a shared daily ceiling.
export async function beforeUpstream(url:string){
 if(!researchContext())return;
 const host=new URL(url).hostname;
 const group=host==='public-api.birdeye.so'?'birdeye':host==='api.dexscreener.com'?'market':host==='api.geckoterminal.com'?'candles':host==='api.gopluslabs.io'||host==='api.honeypot.is'||host==='api.rugcheck.xyz'?'checks':'other';
 const cap=group==='market'?10000:group==='candles'?4000:group==='checks'?5000:group==='birdeye'?800:10000;
 if(!await reserve('economy-upstream:'+group,dayWindow(),1,cap))await deny('SOURCE_DAILY_LIMIT',nextDay(),'Today’s data refresh allowance has been reached. Saved results remain available. Resets at 00:00 UTC.');
 await meter('upstream');
}
export async function allowanceStatus(user:string){
 return actorAllowanceStatus(await digest(user));
}
export async function actorAllowanceStatus(actor:string){
 const day=dayWindow(),d=new Date(),month=d.getUTCFullYear()*12+d.getUTCMonth();
 const keys=['birdeye-cu-budget-v1','birdeye-month-budget','economy-cu:global','economy-cu:'+actor,'economy-scans:'+actor,'economy-cu:guest-pool','economy-cu:guest',...Object.keys(BUCKETS).map(b=>'economy-bucket:'+b)];
 const rows=await db().prepare(`SELECT key,window,count FROM lens_rate_limits WHERE key IN (${keys.map(()=>'?').join(',')})`).bind(...keys).all<{key:string;window:number;count:number}>();
 const value=(key:string,w:number)=>{const r=rows.results.find(x=>x.key===key&&x.window===w);return r?Math.max(0,r.count):0};
 const current=rows.results.find(x=>x.key===keys[0]&&x.window===month),monthly=current?current.count:value(keys[1],month)*100;
 const since=Math.floor(Date.UTC(d.getUTCFullYear(),d.getUTCMonth(),1)/86400000);
 const usage=await db().prepare('SELECT feature,metric,SUM(count) AS count FROM lens_usage WHERE day>=? AND day<=? GROUP BY feature,metric').bind(since,day).all<{feature:string;metric:string;count:number}>();
 const buckets=await Promise.all(Object.entries(BUCKETS).map(async([key,limit])=>({key,limit,used:rows.results.some(r=>r.key==='economy-bucket:'+key&&r.window===day)?value('economy-bucket:'+key,day):await bucketSeed(key as BudgetBucket)})));
 const guest=isGuest(actor);
 return {mode:'economy',audience:guest?'guest':'account',buckets,limits:{...ECONOMY,personalCU:guest?ECONOMY.guestCU:ECONOMY.personalCU,personalScans:guest?ECONOMY.guestScans:ECONOMY.personalScans},used:{guestCU:rows.results.some(r=>r.key===keys[5]&&r.window===day)?value(keys[5],day):value(keys[6],day),monthlyCU:Math.max(0,monthly),dailyCU:value(keys[2],day),personalCU:value(keys[3],day),personalScans:value(keys[4],day)},resetDay:nextDay(),resetMonth:nextMonth(),usage:usage.results,at:new Date().toISOString()};
}
