import {num,clean,validAddress,sameAddress,NETWORKS,tri,publicSourceUrl,type Network} from './types';
export type BasicCheck={state:'clear'|'flagged'|'unknown';flags:string[];checked:number;total:number;at:string};
export type FreshPool={pool:string;address:string;name:string;symbol:string;logo:string|null;quote:string;dex:string;createdAt:string;cap:number|null;fdv:number|null;liquidity:number|null;volume:number|null;change:number|null;price:number|null;buys:number|null;sells:number|null};
export type DiscoveryPage={network:Network;page:number;at:string;items:FreshPool[];nextPage:number|null};
export type DiscoveryFilters={minutes:number;valuation:'cap'|'fdv';minCap:string;maxCap:string;minLiquidity:string;maxLiquidity:string;hideFlagged:boolean;checkedOnly:boolean};
const positive=(v:unknown)=>{const n=num(v);return n!==null&&n>=0?n:null};
export function normalizeNewPools(raw:any,network:Network,page:number,now=Date.now()):DiscoveryPage{
 if(!Array.isArray(raw?.data)||(raw.data.length>0&&!Array.isArray(raw?.included)))throw new Error('Fresh pool data is unavailable.');
 const prefix=NETWORKS[network].gecko+'_',tokens=new Map<string,any>((raw.included||[]).filter((x:any)=>x?.type==='token'&&typeof x.id==='string').map((x:any)=>[x.id,x.attributes]));
 const items:FreshPool[]=raw.data.slice(0,20).flatMap((x:any)=>{const a=x?.attributes,base=x?.relationships?.base_token?.data?.id,q=tokens.get(x?.relationships?.quote_token?.data?.id),b=tokens.get(base),time=Date.parse(a?.pool_created_at);
 if(!a||x.type!=='pool'||x.id!==prefix+a.address||typeof base!=='string'||!base.startsWith(prefix)||!validAddress(a.address,network)||!validAddress(b?.address,network)||!sameAddress(base.slice(prefix.length),b.address,network)||!Number.isFinite(time)||time>now+60000)return [];
 return [{pool:a.address,address:b.address,name:clean(b.name,90)||clean(b.symbol,30)||'Token',symbol:clean(b.symbol,30)||'TOKEN',logo:publicSourceUrl(b.image_url),quote:clean(q?.symbol,30),dex:clean(x.relationships?.dex?.data?.id,40),createdAt:new Date(time).toISOString(),cap:positive(a.market_cap_usd),fdv:positive(a.fdv_usd),liquidity:positive(a.reserve_in_usd),volume:positive(a.volume_usd?.h24),change:num(a.price_change_percentage?.h24),price:positive(a.base_token_price_usd),buys:positive(a.transactions?.h24?.buys),sells:positive(a.transactions?.h24?.sells)}];});
 return {network,page,at:new Date(now).toISOString(),items,nextPage:raw.data.length===20&&page<10?page+1:null};
}
export function normalizeBasicCheck(raw:any,network:Network,address:string,now=Date.now()):BasicCheck{
 const result=raw?.code===1&&raw.result&&typeof raw.result==='object'?Object.entries(raw.result).find(([k])=>sameAddress(k,address,network))?.[1] as any:null;
 const sol=network==='solana',fields=sol?['mintable','freezable','balance_mutable_authority','closable','non_transferable','transfer_hook_upgradable','transfer_fee_upgradable']:['is_honeypot','cannot_sell_all','owner_change_balance','transfer_pausable','is_mintable','selfdestruct','slippage_modifiable'];
 let checked=0;const flags:string[]=[];
 for(const key of fields){const value=tri(sol&&key!=='non_transferable'?result?.[key]?.status:result?.[key]);if(value!==null)checked++;if(value===true)flags.push(key);}
 if(!sol){for(const key of ['buy_tax','sell_tax']){const n=num(result?.[key]);if(n!==null&&n>=0&&n<=1){checked++;if(n>.1)flags.push(key)}}}
 const total=fields.length+(sol?0:2);return {state:flags.length?'flagged':checked===total?'clear':'unknown',flags,checked,total,at:new Date(now).toISOString()};
}
export function discoveryMatches(row:FreshPool,check:BasicCheck|undefined,f:DiscoveryFilters,now=Date.now()){
 const age=now-Date.parse(row.createdAt);if(!Number.isFinite(age)||age < -60000||age>f.minutes*60000)return false;
 for(const [value,min,max] of [[row[f.valuation],f.minCap,f.maxCap],[row.liquidity,f.minLiquidity,f.maxLiquidity]] as const){const lo=min.trim()===''?null:Number(min),hi=max.trim()===''?null:Number(max);if(lo!==null&&(!Number.isFinite(lo)||lo<0)||hi!==null&&(!Number.isFinite(hi)||hi<0)||lo!==null&&hi!==null&&lo>hi)return false;if((lo!==null||hi!==null)&&value===null)return false;if(value!==null&&(lo!==null&&value<lo||hi!==null&&value>hi))return false;}
 if(f.hideFlagged&&check?.state==='flagged'||f.checkedOnly&&check?.state!=='clear')return false;return true;
}
