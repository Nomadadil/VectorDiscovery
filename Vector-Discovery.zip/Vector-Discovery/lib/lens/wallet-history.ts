import {birdeyeCached} from './birdeye-client';
import {fetchJson} from './http';
import {readCache,writeCache} from './cache';
import {throttle} from './storage';
import {NETWORKS,validAddress,clean,publicSourceUrl,type Network} from './types';
import {normalizeWalletHistory,type WalletHistory,type HistoryDuration} from './wallet-history-types';
export async function walletHistory(network:Network,wallet:string,duration:HistoryDuration='30d',offset=0):Promise<WalletHistory>{
 if(!Object.hasOwn(NETWORKS,network)||!validAddress(wallet,network)||!['7d','30d','all'].includes(duration)||!Number.isSafeInteger(offset)||offset<0||offset>10000||offset%20)throw new Error('Choose a valid wallet, history window and page.');
 const base:WalletHistory={state:'unavailable',wallet,duration,at:new Date().toISOString(),items:[],nextOffset:null,detail:''};
 if(network!=='solana')return {...base,state:'unsupported',detail:'Per-token trading history is currently available for Solana.'};
 try{
 const result=await birdeyeCached(`wallet-history:v1:${wallet}:${duration}:${offset}`,600000,'/wallet/v2/pnl/details',{cost:30,chain:'solana',body:{wallet,duration,position_scope:'duration_only',pnl_method:'wac',sort_by:'last_trade',sort_type:'desc',offset,limit:20}},raw=>normalizeWalletHistory(raw,wallet,duration,offset));
 // No token_addresses filter: include sold-out tokens as well as current holdings.
 const history=result.data;const addresses=history.items.filter(x=>!x.logo).map(x=>x.address);if(!addresses.length)return history;
 try{const key='history-metadata:'+addresses.join(','),cache=await readCache<any>(key,86400000);let metadata=cache?.data;if(!metadata){await throttle('gecko-upstream',9);metadata=await fetchJson(`https://api.geckoterminal.com/api/v2/networks/solana/tokens/multi/${addresses.join(',')}`,{},6000);if(!Array.isArray(metadata?.data))throw new Error('Token metadata unavailable.');await writeCache(key,metadata)}
 const tokens=new Map<string,any>((metadata.data||[]).filter((x:any)=>x?.type==='token'&&x.id===`solana_${x.attributes?.address}`&&addresses.includes(x.attributes?.address)).map((x:any)=>[x.attributes.address,x.attributes]));
 return {...history,items:history.items.map(x=>{const a=tokens.get(x.address);return a?{...x,name:clean(a.name,90)||x.name,logo:publicSourceUrl(a.image_url)||x.logo}:x})};
 }catch{return history}
 }catch(e){return {...base,detail:e instanceof Error?e.message:'Trading history is unavailable.'}}
}
