import {clean,num,validAddress,publicSourceUrl} from './types';
export type HistoryDuration='7d'|'30d'|'all';
export type TradedAsset={address:string;symbol:string;name:string;logo:string|null;lastTrade:string|null;buys:number|null;sells:number|null;realized:number|null;realizedPercent:number|null;unrealized:number|null;total:number|null;holding:number|null;price:number|null;openIssue:boolean};
export type WalletHistory={wallet:string;duration:HistoryDuration;at:string;items:TradedAsset[];nextOffset:number|null;state:'ok'|'unsupported'|'unavailable';detail:string};
const count=(v:unknown)=>{const n=num(v);return n!==null&&Number.isSafeInteger(n)&&n>=0?n:null};
export function normalizeWalletHistory(raw:any,wallet:string,duration:HistoryDuration,offset:number,limit=20):WalletHistory{
 const d=raw?.data;if(raw?.success===false||d?.meta?.address!==wallet||d?.meta?.currency?.toLowerCase()!=='usd'||!Array.isArray(d?.tokens))throw new Error('Trading history identity or currency mismatch.');
 const at=Date.parse(d.meta.time);if(!Number.isFinite(at)||at>Date.now()+60000)throw new Error('Trading history time is unavailable.');
 const seen=new Set<string>();const items:TradedAsset[]=d.tokens.map((r:any)=>{if(!validAddress(r?.address,'solana')||seen.has(r.address))throw new Error('Trading history token identity mismatch.');seen.add(r.address);const last=num(r.last_trade_unix_time),holding=num(r.quantity?.holding),p=r.pnl||{};
 return {address:r.address,symbol:clean(r.symbol,30)||'TOKEN',name:clean(r.name,90)||clean(r.symbol,30)||'Token',logo:publicSourceUrl(r.logo_uri||r.logo_url),lastTrade:last!==null&&last>0&&last*1000<=Date.now()+60000?new Date(last*1000).toISOString():null,buys:count(r.counts?.total_buy),sells:count(r.counts?.total_sell),realized:num(p.realized_profit_usd),realizedPercent:num(p.realized_profit_percent),unrealized:num(p.unrealized_usd),total:num(p.total_usd),openIssue:holding===0&&Math.abs(num(p.unrealized_usd)??0)>.01,holding:holding!==null&&holding>=0?holding:null,price:num(r.pricing?.current_price)};});
 if(items.length>limit)throw new Error('Trading history page exceeds requested limit.');
 return {state:'ok',wallet,duration,at:new Date(at).toISOString(),items,nextOffset:items.length===limit&&offset+items.length<=10000?offset+items.length:null,detail:''};
}
