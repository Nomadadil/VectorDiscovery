import type {LensReport} from './types';
import type {LookupIssue} from './lookup';
export type ScanProgress={stage:'identity'|'market'|'checks'|'research';report?:LensReport};
export async function readScan(response:Response,onProgress:(p:ScanProgress)=>void):Promise<{report:LensReport;cached?:boolean;note?:string;code?:string;resetsAt?:string}>{
 const failure=(data:any)=>Object.assign(new Error(data.error||'Token check failed.'),{lookup:data.lookup as LookupIssue|undefined,code:data.code,resetsAt:data.resetsAt});
 if(!response.headers.get('content-type')?.includes('application/x-ndjson')){const data:any=await response.json();if(!response.ok||data.error)throw failure(data);return data;}
 if(!response.body)throw new Error('The analysis connection was interrupted. Please retry.');
 const reader=response.body.getReader(),decoder=new TextDecoder();let pending='',result:{report:LensReport;cached?:boolean;note?:string;code?:string;resetsAt?:string}|null=null,bytes=0;
 const accept=(line:string)=>{if(!line.trim())return;const event=JSON.parse(line);if(event.type==='error')throw failure(event);if(event.type==='progress')onProgress(event);if(event.type==='complete'&&event.report)result=event;};
 try{while(true){const {done,value}=await reader.read();if(done)break;bytes+=value.byteLength;if(bytes>8000000)throw new Error('The analysis response is too large.');pending+=decoder.decode(value,{stream:true});const lines=pending.split('\n');pending=lines.pop()||'';for(const line of lines)accept(line);}pending+=decoder.decode();accept(pending);if(!result)throw new Error('The analysis connection was interrupted. Please retry.');return result;}
 finally{await reader.cancel().catch(()=>{});reader.releaseLock();}
}
