import {fetchJson} from './http';
import {db,digest} from './storage';
import {validAddress} from './types';
import type {WalletHoldingAlert} from './wallet-leader-types';
export const TOKEN_PROGRAMS=['TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA','TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb'] as const;
export type HoldingSnapshot={at:string;slots:number[];tokens:Record<string,{raw:string;decimals:number}>};
// Read both token programs completely. An unavailable program must never imply a zero balance.
export function normalizeHoldingAccounts(raw:any,wallet:string,program:string){
 const slot=raw?.result?.context?.slot,values=raw?.result?.value;
 if(raw?.error||!Number.isSafeInteger(slot)||slot<=0||!Array.isArray(values)||values.length>2000)throw new Error('Complete token balances were not returned.');
 const tokens:HoldingSnapshot['tokens']={},seen=new Set<string>();
 for(const v of values){
  const a=v?.account,info=a?.data?.parsed?.info,t=info?.tokenAmount;
  if(!validAddress(v?.pubkey||'','solana')||seen.has(v.pubkey)||a?.owner!==program||a?.data?.parsed?.type!=='account'||info?.owner!==wallet||!validAddress(info?.mint||'','solana')||!['initialized','frozen'].includes(info.state)||!/^\d{1,20}$/.test(t?.amount||'')||!Number.isInteger(t.decimals)||t.decimals<0||t.decimals>255)throw new Error('Token balance identity or amount could not be verified.');
  seen.add(v.pubkey);const old=tokens[info.mint];if(old&&old.decimals!==t.decimals)throw new Error('Conflicting token precision.');
  tokens[info.mint]={raw:(BigInt(old?.raw||'0')+BigInt(t.amount)).toString(),decimals:t.decimals};
 }
 return {slot,tokens};
}
export async function readHoldingSnapshot(wallet:string):Promise<HoldingSnapshot>{
 if(!validAddress(wallet,'solana'))throw new Error('Invalid Solana wallet.');
 const tokens:HoldingSnapshot['tokens']={},slots:number[]=[];
 for(const program of TOKEN_PROGRAMS){
  const raw=await fetchJson('https://api.mainnet-beta.solana.com',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method:'getTokenAccountsByOwner',params:[wallet,{programId:program},{encoding:'jsonParsed',commitment:'confirmed',...(slots.length?{minContextSlot:slots[0]}:{})}]})},10000,4000000);
  const result=normalizeHoldingAccounts(raw,wallet,program);slots.push(result.slot);
  for(const [mint,value] of Object.entries(result.tokens)){if(tokens[mint])throw new Error('Conflicting token program.');if(BigInt(value.raw)>0)tokens[mint]=value;}
 }
 if(Math.abs(slots[1]-slots[0])>256||Object.keys(tokens).length>250)throw new Error('Balance snapshot exceeds the supported window.');
 return {at:new Date().toISOString(),slots,tokens};
}
export function holdingChanges(before:HoldingSnapshot,after:HoldingSnapshot){
 if(Date.parse(after.at)<=Date.parse(before.at)||Math.min(...after.slots)<Math.max(...before.slots))throw new Error('Balance snapshot is older than the saved observation.');
 const items:{address:string;before:string;after:string;decimals:number;change:WalletHoldingAlert['change']}[]=[];
 for(const mint of new Set([...Object.keys(before.tokens),...Object.keys(after.tokens)])){
  const a=before.tokens[mint],b=after.tokens[mint];if(a&&b&&a.decimals!==b.decimals)throw new Error('Token precision changed.');
  const prev=BigInt(a?.raw||'0'),next=BigInt(b?.raw||'0');if(prev===next)continue;
  items.push({address:mint,before:prev.toString(),after:next.toString(),decimals:(b||a).decimals,change:prev===BigInt(0)?'opened':next===BigInt(0)?'closed':next>prev?'increased':'reduced'});
 }return items;
}
export async function observeWalletHoldings(m:any){
 const snapshot=await readHoldingSnapshot(m.address),old=await db().prepare('SELECT * FROM lens_wallet_balances WHERE wallet_id=? AND user_id=?').bind(m.wallet_id,m.user_id).first<any>();
 const baseline=old?.started_at===m.started_at?JSON.parse(old.payload) as HoldingSnapshot:null;
 const changes=baseline?holdingChanges(baseline,snapshot):[];
 const recent=await db().prepare('SELECT payload FROM lens_wallet_alerts WHERE wallet_id=? AND user_id=? ORDER BY at DESC LIMIT 100').bind(m.wallet_id,m.user_id).all<{payload:string}>();
 const symbols=new Map<string,string>();for(const row of recent.results){const e=JSON.parse(row.payload);if(e.kind==='swap')for(const t of [e.received,e.spent])if(!symbols.has(t.address))symbols.set(t.address,t.symbol);}
 const events=[];for(const x of changes){const id=await digest(m.user_id+':'+m.wallet_id+':balance:'+m.started_at+':'+baseline!.at+':'+snapshot.at+':'+x.address);
  const event:WalletHoldingAlert={id,walletId:m.wallet_id,wallet:m.address,label:m.label,network:'solana',kind:'holding_change',token:{address:x.address,symbol:symbols.get(x.address)||x.address.slice(0,6)},change:x.change,before:x.before,after:x.after,decimals:x.decimals,fromAt:baseline!.at,at:snapshot.at,seen:false};events.push({id,at:event.at,payload:JSON.stringify(event)});
 }
 // Atomic insert plus baseline advancement; pause, resume or threshold changes cancel an in-flight write.
 const guard='EXISTS(SELECT 1 FROM lens_wallet_monitors WHERE wallet_id=? AND user_id=? AND enabled=1 AND started_at=? AND min_usd=?)',args=[m.wallet_id,m.user_id,m.started_at,m.min_usd];
 await db().batch([
  db().prepare(`INSERT OR IGNORE INTO lens_wallet_alerts(id,user_id,wallet_id,at,payload,seen) SELECT json_extract(value,'$.id'),?,?,json_extract(value,'$.at'),json_extract(value,'$.payload'),0 FROM json_each(?) WHERE ${guard}`).bind(m.user_id,m.wallet_id,JSON.stringify(events),...args),
  db().prepare(`INSERT INTO lens_wallet_balances(wallet_id,user_id,started_at,at,payload) SELECT ?,?,?,?,? WHERE ${guard} ON CONFLICT(wallet_id) DO UPDATE SET started_at=excluded.started_at,at=excluded.at,payload=excluded.payload WHERE user_id=excluded.user_id`).bind(m.wallet_id,m.user_id,m.started_at,snapshot.at,JSON.stringify(snapshot),...args)
 ]);
 return {changes:events.length,baseline:!baseline};
}
