import type {LensReport} from './types';
import type {Candle} from './chart';

export type ChartMetric = 'price' | 'marketCap';
// Both values come from the same primary DEX Screener pair in normalizeDex.
// Do not substitute FDV or total supply: neither establishes circulating cap.
export function marketCapBasis(report: LensReport): number | null {
 const {priceUsd, marketCap} = report.market;
 if (priceUsd === null || marketCap === null || !Number.isFinite(priceUsd) || !Number.isFinite(marketCap) || priceUsd <= 0 || marketCap <= 0) return null;
 const units = marketCap / priceUsd;
 return Number.isFinite(units) && units > 0 ? units : null;
}

export function metricCandles(candles: Candle[], metric: ChartMetric, basis: number | null): Candle[] {
 if (metric === 'price') return candles;
 if (basis === null || !Number.isFinite(basis) || basis <= 0) return [];
 const converted = candles.map(c => ({...c, open:c.open*basis, high:c.high*basis, low:c.low*basis, close:c.close*basis}));
 // Volume is already USD, and timestamps / gaps must remain unchanged.
 return converted.every(c => [c.open,c.high,c.low,c.close].every(n => Number.isFinite(n) && n > 0)) ? converted : [];
}
