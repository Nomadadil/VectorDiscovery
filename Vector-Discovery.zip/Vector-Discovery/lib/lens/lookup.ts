import {NETWORKS,sameAddress,validAddress,clean,type Network,type LensReport} from './types';
import {fetchJson} from './http';
export type TokenCandidate={network:Network;address:string;name:string;symbol:string;kind:'token'|'pool_token';pool?:string};
export type LookupIssue={state:'choose_network'|'choose_pool_token'|'unresolved'|'unavailable';network:Network;address:string;candidates:TokenCandidate[];detail:string};

export {hasTokenEvidence} from './token-evidence';
export function exactPair(raw:any,network:Network,address:string){return (Array.isArray(raw?.pairs)?raw.pairs:[]).find((p:any)=>p?.chainId===NETWORKS[network].dex&&typeof p.pairAddress==='string'&&sameAddress(p.pairAddress,address,network)&&validAddress(p.baseToken?.address||'',network));}
export function tokenCandidates(raw:any,address:string):TokenCandidate[]{
 const found=new Map<string,TokenCandidate>();
 for(const p of Array.isArray(raw?.pairs)?raw.pairs:[]){const network=(Object.keys(NETWORKS) as Network[]).find(n=>NETWORKS[n].dex===p?.chainId);if(!network||!validAddress(address,network))continue;
  for(const side of ['baseToken','quoteToken']){const token=p[side];if(!validAddress(token?.address||'',network)||!sameAddress(token.address,address,network))continue;const a=network==='solana'?token.address:token.address.toLowerCase();found.set(network+':'+a,{network,address:a,name:clean(token.name,70)||clean(token.symbol,20)||'Token',symbol:clean(token.symbol,20),kind:'token'});}
 }
 return [...found.values()];
}
export function pairCandidates(raw:any,network:Network,address:string):TokenCandidate[]{const p=exactPair(raw,network,address);if(!p)return [];const seen=new Set<string>();return [p.baseToken,p.quoteToken].filter(t=>validAddress(t?.address||'',network)).flatMap(t=>{const a=network==='solana'?t.address:t.address.toLowerCase();if(seen.has(a))return [];seen.add(a);return [{network,address:a,name:clean(t.name,70)||clean(t.symbol,20)||'Token',symbol:clean(t.symbol,20),kind:'pool_token' as const,pool:p.pairAddress}]});}
export async function resolveMissing(r:LensReport):Promise<LookupIssue>{
 const {network,address}=r;
 const [pairs,search]=await Promise.allSettled([
  fetchJson(`https://api.dexscreener.com/latest/dex/pairs/${NETWORKS[network].dex}/${address}`,{},6000),
  fetchJson(`https://api.dexscreener.com/latest/dex/search?q=${encodeURIComponent(address)}`,{},6000)
 ]);
 const fromPool=pairs.status==='fulfilled'?pairCandidates(pairs.value,network,address):[];
 if(fromPool.length)return {state:'choose_pool_token',network,address,candidates:fromPool,detail:'This is a pool address. Choose which token to inspect.'};
 const candidates=search.status==='fulfilled'?tokenCandidates(search.value,address).filter(c=>c.network!==network):[];
 if(candidates.length)return {state:'choose_network',network,address,candidates,detail:'This exact address has markets on another network. Choose the network to inspect.'};
 const market=r.sources.find(s=>s.id==='dexscreener');const unavailable=(market?.state==='unavailable'&&market.detail!=='No matching pools returned on this network.')||pairs.status==='rejected'||search.status==='rejected';
 return {state:unavailable?'unavailable':'unresolved',network,address,candidates:[],detail:unavailable?'The market source could not respond. Retry or check the network.':'No token was identified on the selected network. Check the network and the full contract address.'};
}
