import type {Network} from './types';
export type SignalCheckState='pass'|'fail'|'unknown';
export type SignalCheck={id:string;state:SignalCheckState;detail:string;source:string;observedAt:string};
export type SignalItem={
 id:string;network:Network;address:string;pool:string;name:string;symbol:string;logo:string|null;
 createdAt:string;firstSeen:string;lastChecked:string;expiresAt:string;status:'qualified'|'pending';
 price:number|null;cap:number|null;fdv:number|null;liquidity:number|null;volumeH1:number|null;changeH1:number|null;
 buysH1:number|null;sellsH1:number|null;transactionsH1:number|null;lockPercent:number|null;lockUntil:string|null;
 links:{label:string;url:string}[];checks:SignalCheck[];reasons:string[];
};
export type SignalsPage={
 network:Network;mode:'fresh'|'trending';maxAgeMinutes:60|120;at:string;lastSuccessfulAt:string|null;
 nextRefreshAt:string;stale:boolean;status:'ok'|'partial'|'unavailable';
 items:SignalItem[];pending:SignalItem[];excludedCount:number;scannedCount:number;checkedCount:number;
 coverage:string;detail:string;
};
export type SignalSubscription={enabled:boolean;networks:Network[];startedAt:string|null;lastRead:string|null};
export type SignalAlert=SignalItem&{seen:boolean;active:boolean};
export type SignalsFeed={subscription:SignalSubscription;items:SignalAlert[];unread:number;at:string;retentionDays:number};
export const SIGNAL_THRESHOLDS={maxAgeMinutes:120,minMarketCap:25000,minLiquidity:15000,minBuysH1:5,minSellsH1:5,minTransactionsH1:25,minLockedPercent:95} as const;
