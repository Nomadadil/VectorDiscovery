import {db} from './storage';
import {NETWORKS,type Network} from './types';
import type {SignalItem,SignalsPage,SignalSubscription,SignalsFeed} from './signals-types';
export const SIGNAL_RETENTION_DAYS=7;
const networks=(v:unknown):Network[]=>Array.isArray(v)?[...new Set(v.filter((n):n is Network=>typeof n==='string'&&Object.hasOwn(NETWORKS,n)))]:[];
export async function saveSignalsPage(page:SignalsPage){
 const now=Date.now(),iso=new Date(now).toISOString(),statements=[];
 // Expire previous results before atomically upserting this checked batch.
 // A missing or newly failing candidate must not keep its old alert active.
 statements.push(db().prepare('UPDATE vector_signals SET expires_at=MIN(expires_at,?) WHERE network=?').bind(iso,page.network));
 for(const item of page.items){statements.push(db().prepare(`INSERT INTO vector_signals(id,network,address,first_seen,last_checked,expires_at,payload) VALUES(?,?,?,?,?,?,?)
 ON CONFLICT(id) DO UPDATE SET last_checked=excluded.last_checked,expires_at=excluded.expires_at,payload=excluded.payload`).bind(item.id,item.network,item.address,item.firstSeen,item.lastChecked,item.expiresAt,JSON.stringify(item)));}
 statements.push(db().prepare(`INSERT INTO vector_signal_runs(network,last_attempt,last_success,status,detail) VALUES(?,?,?,?,?)
 ON CONFLICT(network) DO UPDATE SET last_attempt=excluded.last_attempt,last_success=COALESCE(excluded.last_success,last_success),status=excluded.status,detail=excluded.detail`).bind(page.network,page.at,page.status==='unavailable'?null:page.at,page.status,page.detail));
 statements.push(db().prepare('DELETE FROM vector_signals WHERE first_seen<?').bind(new Date(now-SIGNAL_RETENTION_DAYS*86400000).toISOString()));
 // Hard bounded storage even if upstream volume grows unexpectedly.
 statements.push(db().prepare('DELETE FROM vector_signals WHERE id NOT IN (SELECT id FROM vector_signals ORDER BY first_seen DESC LIMIT 2000)'));
 await db().batch(statements);
 const rows=await db().prepare('SELECT id,first_seen FROM vector_signals WHERE network=?').bind(page.network).all<{id:string;first_seen:string}>();const first=new Map(rows.results.map(x=>[x.id,x.first_seen]));
 return {...page,items:page.items.map(item=>({...item,firstSeen:first.get(item.id)||item.firstSeen}))};
}
export async function signalLastRun(network:Network){return db().prepare('SELECT last_attempt,last_success,status,detail FROM vector_signal_runs WHERE network=?').bind(network).first<{last_attempt:string;last_success:string|null;status:string;detail:string}>();}
export async function signalSubscription(user:string):Promise<SignalSubscription>{
 const row=await db().prepare('SELECT enabled,networks,started_at,last_read FROM vector_signal_subscriptions WHERE user_id=?').bind(user).first<{enabled:number;networks:string;started_at:string;last_read:string}>();
 return row?{enabled:!!row.enabled,networks:networks(JSON.parse(row.networks)),startedAt:row.started_at,lastRead:row.last_read}:{enabled:false,networks:['solana'],startedAt:null,lastRead:null};
}
export async function subscribeSignals(user:string,selected:unknown,enabled:unknown):Promise<SignalsFeed>{
 if(typeof enabled!=='boolean'||!Array.isArray(selected)||!selected.length||selected.length>3||selected.some(n=>typeof n!=='string'||!Object.hasOwn(NETWORKS,n)))throw new Error('Choose supported networks and a valid notification setting.');
 const chosen=networks(selected).sort(),previous=await signalSubscription(user),iso=new Date().toISOString();
 const changed=previous.enabled!==enabled||JSON.stringify([...previous.networks].sort())!==JSON.stringify(chosen);
 await db().prepare(`INSERT INTO vector_signal_subscriptions(user_id,enabled,networks,started_at,last_read) VALUES(?,?,?,?,?)
 ON CONFLICT(user_id) DO UPDATE SET enabled=excluded.enabled,networks=excluded.networks,started_at=excluded.started_at,last_read=excluded.last_read`).bind(user,enabled?1:0,JSON.stringify(chosen),previous.startedAt||iso,changed?iso:previous.lastRead||iso).run();return signalFeed(user);
}
export async function markSignalsRead(user:string):Promise<SignalsFeed>{await db().prepare('UPDATE vector_signal_subscriptions SET last_read=? WHERE user_id=?').bind(new Date().toISOString(),user).run();return signalFeed(user);}
export async function signalFeed(user:string):Promise<SignalsFeed>{
 const subscription=await signalSubscription(user),at=new Date().toISOString();
 if(!subscription.startedAt)return {subscription,items:[],unread:0,at,retentionDays:SIGNAL_RETENTION_DAYS};
 const selected=subscription.networks;if(!selected.length)return {subscription,items:[],unread:0,at,retentionDays:SIGNAL_RETENTION_DAYS};
 const rows=await db().prepare(`SELECT id,payload,first_seen,last_checked,expires_at FROM vector_signals WHERE network IN (${selected.map(()=>'?').join(',')}) AND first_seen>? ORDER BY first_seen DESC LIMIT 100`).bind(...selected,subscription.startedAt).all<{id:string;payload:string;first_seen:string;last_checked:string;expires_at:string}>();
 const items=rows.results.map(row=>({...JSON.parse(row.payload) as SignalItem,id:row.id,firstSeen:row.first_seen,lastChecked:row.last_checked,expiresAt:row.expires_at,seen:row.first_seen<=(subscription.lastRead||subscription.startedAt!),active:subscription.enabled&&row.expires_at>at}));
 return {subscription,items,unread:items.filter(x=>!x.seen&&x.active).length,at,retentionDays:SIGNAL_RETENTION_DAYS};
}
