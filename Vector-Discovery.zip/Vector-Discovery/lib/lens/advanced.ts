import {fetchJson} from './http';
import {readCache,writeCache} from './cache';
import {num,tri,pct,clean,validAddress,sameAddress,publicSourceUrl,type LensReport,type Holder,type Advanced} from './types';
const percent=(v:unknown,m=1)=>{const n=pct(v,m);return n!==null&&n>=0&&n<=100?n:null};
const iso=(v:unknown)=>{if(typeof v!=='string'&&typeof v!=='number')return null;const d=new Date(v);return Number.isFinite(d.getTime())&&d.getTime()>0&&d.getTime()<=Date.now()+60000?d.toISOString():null};
const knownSum=(v:(number|null)[])=>v.length&&v.every(x=>x!==null)?v.reduce<number>((a,b)=>a+(b||0),0):null;
export function enrichDex(r:LensReport,pairs:any[],primary:any){
 r.advanced||={};
 r.advanced.periods=Object.fromEntries(['m5','h1','h6','h24'].map(k=>[k,{volume:knownSum(pairs.slice(0,40).map(p=>num(p.volume?.[k]))),buys:knownSum(pairs.slice(0,40).map(p=>num(p.txns?.[k]?.[sameAddress(p.baseToken?.address||'',r.address,r.network)?'buys':'sells']))),sells:knownSum(pairs.slice(0,40).map(p=>num(p.txns?.[k]?.[sameAddress(p.baseToken?.address||'',r.address,r.network)?'sells':'buys']))),change:primary?num(primary.priceChange?.[k]):null}]));
 if(!primary)return;
 const metadata=pairs.find(p=>sameAddress(p.baseToken?.address||'',r.address,r.network)&&p.info);const links=new Map<string,{label:string;url:string}>();
 for(const x of [...(Array.isArray(metadata?.info?.websites)?metadata.info.websites:[]),...(Array.isArray(metadata?.info?.socials)?metadata.info.socials:[])]){const url=publicSourceUrl(x.url||'');if(url)links.set(url,{url,label:clean(x.label||x.type||'Website',30)});}
 if(links.size)r.advanced.profile={links:[...links.values()].slice(0,10),source:'DEX Screener'};
 r.advanced.reserves={pool:primary.pairAddress,token:num(primary.liquidity?.base),other:num(primary.liquidity?.quote),quote:clean(primary.quoteToken?.symbol,20)};
}
export function enrichGo(r:LensReport,g:any){
 r.advanced||={};
 const rows=[['can_take_back_ownership','Ownership can be reclaimed'],['is_anti_whale','Transaction / holding limits'],['anti_whale_modifiable','Limits can change'],['personal_slippage_modifiable','Address-specific fees'],['is_whitelisted','Whitelist mechanism'],['cannot_buy','Provider buy restriction'],['external_call','External contract calls']];
 for(const [key,label] of rows){const signal=tri(g[key]);r.facts.push({id:'go-'+key,label,value:signal===null?'Not established':signal?'Detected':'Not detected',signal,tone:signal&&key!=='external_call'?'warn':'neutral',source:'GoPlus',detail:key==='cannot_buy'?'Provider detection; anti-bot or simulation constraints can affect this result. This is not a quote for your wallet.':'A reported contract capability. Its presence is not proof of misuse; missing data remains unknown.'});}
 for(const [key,label] of [['creator_percent','Reported creator holdings'],['owner_percent','Reported owner holdings']]){const value=percent(g[key],100);r.facts.push({id:'go-'+key,label,value:value===null?'Not established':value.toFixed(2)+'%',signal:null,tone:'neutral',source:'GoPlus',detail:'Share reported for this address, not a combined insider or related-wallet share.'});}
 r.advanced.lp={count:num(g.lp_holder_count),source:'GoPlus',items:(Array.isArray(g.lp_holders)?g.lp_holders:[]).slice(0,20).filter((x:any)=>validAddress(x.address,r.network)).map((x:any)=>({address:x.address,share:percent(x.percent,100),locked:tri(x.is_locked),label:/^0x0{36}(dead|0000)$/i.test(x.address)?'Burn address':clean(x.tag,50)||'Unlabelled LP holder'}))};
 r.advanced.poolFees=(Array.isArray(g.dex)?g.dex:[]).slice(0,40).filter((x:any)=>typeof x.pair==='string'&&/^0x[0-9a-f]{40,64}$/i.test(x.pair)).map((x:any)=>({pool:x.pair,fee:percent(x.pool_fee,100),type:clean(x.liquidity_type,40)}));
}
export function enrichRug(r:LensReport,g:any){
 if(g.mint!==undefined&&g.mint!==r.address)throw new Error('Provider mint identity mismatch.');
 r.advanced||={};r.creator.owner=null;
 const mutable=tri(g.tokenMeta?.mutable);r.facts.push({id:'rug-metadata-mutable',label:'Metadata can be edited',value:mutable===null?'Not established':mutable?'Yes':'No',signal:mutable,tone:'neutral',source:'RugCheck',detail:'Metadata editing is separate from minting, freezing and transfers.'});
 const update=validAddress(g.tokenMeta?.updateAuthority||'',r.network)?g.tokenMeta.updateAuthority:null;r.facts.push({id:'rug-metadata-authority',label:'Metadata update authority',value:update||'Not established',signal:null,tone:'neutral',source:'RugCheck',detail:'Metadata authority is not necessarily the creator, mint authority or owner of token balances.'});
 const seen=new Set<string>(),wallets=new Map<string,Holder>();
 for(const h of (Array.isArray(g.topHolders)?g.topHolders:[]).slice(0,100)){
  if(!validAddress(h.address||'','solana')||seen.has(h.address))continue;seen.add(h.address);const owner=validAddress(h.owner||'','solana')?h.owner:h.address;const label=g.knownAccounts?.[owner]||g.knownAccounts?.[h.address];const share=percent(h.pct);const prev=wallets.get(owner);if(prev){prev.share=prev.share===null||share===null?null:prev.share+share;prev.balance=null;}else wallets.set(owner,{address:owner,balance:typeof h.uiAmountString==='string'?clean(h.uiAmountString,100):null,share,label:clean(label?.name,60)||'Unlabelled owner',kind:label?.type==='AMM'?'pool':'account',source:'RugCheck'});
 }
 if(wallets.size){r.holders.items=[...wallets.values()].sort((a,b)=>(b.share||0)-(a.share||0)).slice(0,30);r.holders.scope=`${seen.size} returned token accounts grouped into ${wallets.size} owners. Other accounts of these owners may be missing.`;}
 r.advanced.poolLocks=(Array.isArray(g.markets)?g.markets:[]).filter((m:any)=>r.market.pools.some(p=>p.address===m.pubkey)).slice(0,40).map((m:any)=>{const supported=validAddress(m.mintLP||'','solana')&&m.mintLP!=='11111111111111111111111111111111'&&m.mintLPAccount?.isInitialized===true&&(num(m.lp?.lpTotalSupply)||0)>0;return {pool:m.pubkey,name:clean(m.marketType,50),percent:supported?percent(m.lp?.lpLockedPct):null,usd:supported?num(m.lp?.lpLockedUSD):null,source:'RugCheck'}});
 r.advanced.lockerRecords=Object.values(g.lockers||{}).slice(0,15).map((x:any)=>{const n=num(x.unlockDate);const d=n&&n>0?new Date(n*1000):null;return {label:clean(x.type,50)||'Locker record',until:d&&Number.isFinite(d.getTime())?d.toISOString():null,url:publicSourceUrl(x.uri||''),source:'RugCheck'}});
}
export function normalizeExplorer(a:any,c:any,tx:any,origin:string):NonNullable<Advanced['explorer']>{
 const verification=c?.is_partially_verified===true?'Partially verified':c?.is_fully_verified===true?'Fully verified':c?.is_verified===true||a?.is_verified===true?'Verified · scope unspecified':c?.is_verified===false||a?.is_verified===false?'Not verified':'Not established';
 const creationTx=/^0x[0-9a-f]{64}$/i.test(a?.creation_transaction_hash||'')?a.creation_transaction_hash:null;
 const successful=creationTx&&tx?.hash?.toLowerCase()===creationTx.toLowerCase()&&tx?.status==='ok';
 return {creator:/^0x[0-9a-f]{40}$/i.test(a?.creator_address_hash||'')?a.creator_address_hash:null,creationTx,createdAt:successful?iso(tx.timestamp):null,block:successful&&num(tx.block_number)!==null?String(tx.block_number):null,verification,verifiedAt:iso(c?.verified_at),compiler:clean(c?.compiler_version,70)||null,language:clean(c?.language,30)||null,url:origin+'/address/'+a.hash,fetchedAt:new Date().toISOString()};
}
export async function explorerRead(r:LensReport){
 const hosts:Record<string,string>={ethereum:'https://eth.blockscout.com'};const origin=hosts[r.network];const doc='https://docs.blockscout.com/devs/apis/rest';
 if(!origin){r.sources.push({id:'explorer',name:'Blockscout',state:'unsupported',detail:'Contract provenance adapter currently covers Ethereum.',url:doc,fetchedAt:new Date().toISOString()});return;}
 try{const key=`explorer:${r.network}:${r.address}`;const saved=await readCache<NonNullable<Advanced['explorer']>>(key,3600000);let data=saved?.data;
 if(!data){const a=await fetchJson(`${origin}/api/v2/addresses/${r.address}`,{},6500);if(!sameAddress(a.hash||'',r.address,r.network))throw new Error('Explorer address identity mismatch.');
 const [contract,tx]=await Promise.allSettled([a.is_contract?fetchJson(`${origin}/api/v2/smart-contracts/${r.address}`,{},6500):Promise.resolve(null),/^0x[0-9a-f]{64}$/i.test(a.creation_transaction_hash||'')?fetchJson(`${origin}/api/v2/transactions/${a.creation_transaction_hash}`,{},6500):Promise.resolve(null)]);
 data=normalizeExplorer(a,contract.status==='fulfilled'?contract.value:null,tx.status==='fulfilled'?tx.value:null,origin);await writeCache(key,data);}
 r.advanced||={};r.advanced.explorer=data;r.sources.push({id:'explorer',name:'Blockscout',state:data.createdAt&&data.verification!=='Not established'?'ok':'partial',detail:'Deployment and source verification, where indexed. Predeploys may lack creation transactions. Verification is not an audit.',url:doc,fetchedAt:new Date().toISOString(),observedAt:data.fetchedAt});
 }catch(e){r.sources.push({id:'explorer',name:'Blockscout',state:'unavailable',detail:e instanceof Error?e.message:'Explorer unavailable.',url:doc,fetchedAt:new Date().toISOString()});}
}
