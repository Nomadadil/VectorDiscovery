import {translate,type Locale} from './i18n';
import {NETWORKS,type LensReport} from './types';
export function downloadJson(report:LensReport){download(new Blob([JSON.stringify(report,null,2)],{type:'application/json'}),`Vector-Discovery-${report.token.symbol.replace(/[^a-z0-9_-]/ig,'')}-${report.id.slice(0,8)}.json`)}
function download(blob:Blob,name:string){const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
export async function downloadCard(report:LensReport,locale:Locale='en'){
 const {renderShareCard,saveCard,cardFilename}=await import('./share-card');
 saveCard(await renderShareCard(report,locale,'feed'),cardFilename(report,'feed',locale));
}
