import {fetchJson} from './http';
import {readCache,writeCache} from './cache';
import {NETWORKS,clean,num,sameAddress,publicSourceUrl,validAddress,type LensReport} from './types';
export type TokenContext={developer?:{address:string;share:number|null};description:string;categories?:string[];category:'meme'|'unclassified';image:string|null;links:{label:string;url:string}[];source:string;url:string;fetchedAt:string;holders:{count:number|null;buckets:{label:string;share:number}[];updatedAt:string|null}};
const safeCount=(v:unknown)=>{const n=num(v);return n!==null&&Number.isSafeInteger(n)&&n>=0?n:null};
export function normalizeTokenContext(raw:any,r:Pick<LensReport,'network'|'address'>):TokenContext{
 const a=raw?.data?.attributes;if(raw?.data?.id!==`${NETWORKS[r.network].gecko}_${r.address}`||!sameAddress(a?.address||'',r.address,r.network))throw new Error('Token metadata identity mismatch.');
 const description=clean(a.description,2400).replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim();
 const links:{label:string;url:string}[]=[];for(const value of Array.isArray(a.websites)?a.websites.slice(0,4):[]){const url=publicSourceUrl(value);if(url)links.push({label:'Website',url})}
 if(/^[A-Za-z0-9_]{1,15}$/.test(a.twitter_handle||''))links.push({label:'X',url:'https://x.com/'+a.twitter_handle});
 if(/^[A-Za-z0-9_]{5,32}$/.test(a.telegram_handle||''))links.push({label:'Telegram',url:'https://t.me/'+a.telegram_handle});
 const categories=Array.isArray(a.categories)?a.categories.map((c:any)=>typeof c==='string'?c:clean(c.name,80)).join(' '):'';
 const entries=r.network==='solana'?[['top_10','Top 10'],['11_20','11–20'],['21_40','21–40'],['rest','Others']]:[['top_10','Top 10'],['11_30','11–30'],['31_50','31–50'],['rest','Others']];
 let buckets=entries.flatMap(([key,label])=>{const n=num(a.holders?.distribution_percentage?.[key]);return n!==null&&n>=0&&n<=100?[{label,share:n}]:[]});
 if(buckets.length!==4||Math.abs(buckets.reduce((s,b)=>s+b.share,0)-100)>.15)buckets=[];
 const updated=Date.parse(a.holders?.last_updated);const image=publicSourceUrl(a.image_url||'');
 const developer=validAddress(a.developer_address||'',r.network)?{address:a.developer_address,share:num(a.developer_holding_percentage)!==null&&num(a.developer_holding_percentage)!>=0&&num(a.developer_holding_percentage)!<=100?num(a.developer_holding_percentage):null}:undefined;
 return {developer,description,categories:categories?[categories]:[],category:/\bmeme(?:coin|s|\s|\b)/i.test(description+' '+categories)?'meme':'unclassified',image:image&&['coin-images.coingecko.com','assets.coingecko.com'].includes(new URL(image).hostname)?image:null,links,source:'GeckoTerminal',url:`https://www.geckoterminal.com/${NETWORKS[r.network].gecko}/tokens/${r.address}`,fetchedAt:new Date().toISOString(),holders:{count:safeCount(a.holders?.count),buckets,updatedAt:Number.isFinite(updated)&&updated<=Date.now()+60000?new Date(updated).toISOString():null}};
}
export async function tokenContextRead(r:LensReport){
 try{const key=`context-v3:${r.network}:${r.address}`;const cached=await readCache<TokenContext>(key,300000);let context=cached?.data;if(!context){const raw=await fetchJson(`https://api.geckoterminal.com/api/v2/networks/${NETWORKS[r.network].gecko}/tokens/${r.address}/info`,{},6500);context=normalizeTokenContext(raw,r);await writeCache(key,context)}r.context=context;
 if(r.holders.total===null&&context.holders.count!==null){r.holders.total=context.holders.count;r.holders.countSource='GeckoTerminal';}
 const links=new Map((r.advanced?.profile?.links||[]).map(l=>[l.url,l]));for(const l of context.links)links.set(l.url,l);r.advanced||={};if(links.size)r.advanced.profile={links:[...links.values()],source:'DEX Screener / GeckoTerminal'};
 r.sources.push({id:'token-context',name:'GeckoTerminal token profile',state:'ok',detail:'Project-submitted description and links; indexed holder aggregates. A profile is not a security review.',url:context.url,fetchedAt:new Date().toISOString(),observedAt:context.fetchedAt});
 }catch(e){r.sources.push({id:'token-context',name:'GeckoTerminal token profile',state:'unavailable',detail:e instanceof Error?e.message:'Token context unavailable.',url:'https://www.geckoterminal.com',fetchedAt:new Date().toISOString()})}
}
