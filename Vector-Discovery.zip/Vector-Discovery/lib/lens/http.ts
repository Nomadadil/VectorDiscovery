import {beforeUpstream} from './economy';
export async function fetchJson(url:string,init:RequestInit={},timeout=9000,maxBytes=2500000):Promise<any>{
 await beforeUpstream(url);
 const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),timeout);
 try{const r=await fetch(url,{...init,redirect:'manual',signal:controller.signal,headers:{accept:'application/json',...init.headers}});if(!r.ok)throw new Error(r.status===429?'Provider rate limit reached. Try again later.':r.status===401||r.status===403?'Provider access is unavailable.':`Provider returned HTTP ${r.status}.`);const length=Number(r.headers.get('content-length')||0);if(length>maxBytes)throw new Error('Provider response is too large.');const text=await r.text();if(text.length>maxBytes)throw new Error('Provider response is too large.');return JSON.parse(text)}catch(e){if(e instanceof Error&&e.name==='AbortError')throw new Error('Provider timed out.');throw e}finally{clearTimeout(timer)}
}
