import type {WalletLeader} from './wallet-leader-types';
export const MIN_CLOSED_TOKENS=20;
export const REVIEW_MAX_AGE=48*3600000;
export function assessWallet(row:WalletLeader,now=Date.now()){
 const p=row.performance?.state==='ok'?row.performance:null;
 const sample=p?.wins!=null&&p?.losses!=null?p.wins+p.losses:null;
 const age=p?now-Date.parse(p.fetchedAt):NaN;
 const fresh=Number.isFinite(age)&&age>=-60000&&age<=REVIEW_MAX_AGE;
 const signMismatch=!!p&&(['realized','total'] as const).some(k=>row[k]!==null&&p[k]!==null&&row[k]!*p[k]!<0);
 const complete=[row.realized,row.unrealized,row.total].every(n=>n!==null&&Number.isFinite(n));
 const inconsistent=complete&&Math.abs(row.realized!+row.unrealized!-row.total!)>Math.max(1,Math.abs(row.total!)*.01);
 const openLoss=row.unrealized!==null&&row.unrealized<0;
 const profitErased=complete&&row.realized!>0&&row.total!<=0;
 const sampleReady=sample!==null&&sample>=MIN_CLOSED_TOKENS;
 const comparable=complete&&!inconsistent&&!signMismatch&&fresh&&sampleReady;
 return {sample,fresh,signMismatch,inconsistent,openLoss,profitErased,sampleReady,complete,comparable};
}
export type WalletFilter='all'|'positive'|'sample';
export function selectLeaders(rows:WalletLeader[],query:string,sort:string,filter:WalletFilter,now=Date.now()){
 return rows.filter(r=>r.address.toLowerCase().includes(query.trim().toLowerCase())).filter(r=>filter==='positive'?(r.total!==null&&r.total>0):filter==='sample'?assessWallet(r,now).comparable:true).sort((a,b)=>{
  const value=(r:WalletLeader)=>sort==='win'?(assessWallet(r,now).comparable?r.performance?.winRate??null:null):sort==='realized'?r.realized:r.total;
  const av=value(a),bv=value(b);if(av===null||bv===null)return av===bv?a.rank-b.rank:av===null?1:-1;
  return bv-av||a.rank-b.rank;
 });
}
