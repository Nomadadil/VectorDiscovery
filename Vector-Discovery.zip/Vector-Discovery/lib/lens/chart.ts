import {AllowanceError} from './allowance-error';
import {supportsBirdeyeChart,cachedBirdeyeChart,birdeyeChart} from './birdeye-chart';
import {fetchJson} from './http';
import {readCache,writeCache} from './cache';
import {throttle} from './storage';
import {NETWORKS,sameAddress,num,clean,validAddress,type LensReport,type Network} from './types';
export const INTERVALS={'1m':{unit:'minute',aggregate:1},'5m':{unit:'minute',aggregate:5},'15m':{unit:'minute',aggregate:15},'1h':{unit:'hour',aggregate:1},'4h':{unit:'hour',aggregate:4},'1d':{unit:'day',aggregate:1}} as const;
export type Interval=keyof typeof INTERVALS;
export type Candle={time:number;open:number;high:number;low:number;close:number;volume:number};
export type ChartPool={address:string;name:string;dex:string;reserve:number|null};
export type ChartResult={state:'ok'|'stale'|'unavailable';detail:string;candles:Candle[];pools:ChartPool[];pool:ChartPool|null;interval:Interval;fetchedAt:string;provider:'GeckoTerminal'|'Birdeye';scope?:'pool'|'token';resetsAt?:string;code?:string;needsExtended?:boolean;network:Network;address:string};
const root='https://api.geckoterminal.com/api/v2';
async function get(path:string){await throttle('gecko-upstream',9);return fetchJson(root+path,{headers:{accept:'application/json;version=20230203'}},12000);}
export function normalizeChartPools(raw:any,network:Network,address:string):ChartPool[]{
 const prefix=NETWORKS[network].gecko+'_';const seen=new Set<string>();
 return (Array.isArray(raw?.data)?raw.data:[]).filter((p:any)=>{const matches=['base_token','quote_token'].some(side=>{const id=p?.relationships?.[side]?.data?.id;return typeof id==='string'&&id.startsWith(prefix)&&sameAddress(id.slice(prefix.length),address,network)});const a=p?.attributes?.address;return matches&&typeof a==='string'&&/^[a-zA-Z0-9]{20,100}$/.test(a)&&!seen.has(a)&&!!seen.add(a)}).map((p:any)=>({address:p.attributes.address,name:clean(p.attributes.name,70),dex:clean(p.relationships?.dex?.data?.id,50),reserve:num(p.attributes.reserve_in_usd)})).slice(0,10);
}
export function normalizeCandles(raw:any,network:Network,address:string):Candle[]{
 // Explicit token=address selects token orientation; response metadata must corroborate it.
 if(!sameAddress(raw?.meta?.base?.address||'',address,network))throw new Error('Chart token orientation could not be verified.');
 if(!Array.isArray(raw?.data?.attributes?.ohlcv_list))throw new Error('No candle series returned.');
 const unique=new Map<number,Candle>();
 for(const row of raw.data.attributes.ohlcv_list){if(!Array.isArray(row)||row.length<6)continue;const vals=row.slice(0,6).map(num);if(vals.some((x:number|null)=>x===null))continue;const [time,open,high,low,close,volume]=vals as number[];if(!Number.isInteger(time)||time<=0||time>Date.now()/1000+60||Math.min(open,high,low,close)<=0||volume<0||high<Math.max(open,close,low)||low>Math.min(open,close,high))continue;unique.set(time,{time,open,high,low,close,volume});}
 return [...unique.values()].sort((a,b)=>a.time-b.time).slice(-240);
}
async function geckoChart(report:LensReport,interval:Interval,requestedPool?:string):Promise<ChartResult>{
 if(!Object.hasOwn(INTERVALS,interval))throw new Error('Choose a supported candle interval.');
 const network=report.network,address=report.address;const base:ChartResult={state:'unavailable',detail:'',candles:[],pools:[],pool:null,interval,fetchedAt:new Date().toISOString(),provider:'GeckoTerminal',network,address};
 const poolsKey=`gt:pools:${network}:${address}`;
 try{
  let saved=await readCache<ChartPool[]>(poolsKey,300000);
  // A temporary empty discovery must not block later retries for five minutes.
  // Ignore legacy empty entries; only retain discoveries with verified pools.
  if(!saved?.data.length){try{const raw=await get(`/networks/${NETWORKS[network].gecko}/tokens/${address}/pools?page=1`);const pools=normalizeChartPools(raw,network,address);if(pools.length)await writeCache(poolsKey,pools);saved={data:pools,at:Date.now()}}catch(e){saved=await readCache<ChartPool[]>(poolsKey,86400000);if(!saved?.data.length){
   // DEX report pools are already matched to this chain and token. Candle metadata
   // still verifies the requested token orientation before any series is displayed.
   const pools=report.mode==='live'?report.market.pools.filter(p=>p.source==='DEX Screener'&&validAddress(p.address,network)).slice(0,10).map(p=>({address:p.address,name:report.token.symbol+' / '+p.quote,dex:p.dex,reserve:p.liquidityUsd})):[];
   if(!pools.length)throw e;saved={data:pools,at:Date.now()};
  }}}
  base.pools=saved.data;if(!base.pools.length)throw new Error('This provider has no chartable pool for this token.');
  base.pool=requestedPool?base.pools.find(p=>sameAddress(p.address,requestedPool,network))||null:base.pools.find(p=>report.market.pools.some(x=>x.priceUsd!==null&&x.priceUsd===report.market.priceUsd&&sameAddress(x.address,p.address,network)))||base.pools[0];if(!base.pool)throw new Error('Select one of the returned pools.');
  const cacheKey=`gt:ohlcv:${network}:${address}:${base.pool.address}:${interval}`;const cached=await readCache<Pick<ChartResult,'candles'|'fetchedAt'>>(cacheKey,60000);
  if(cached)return {...base,...cached.data,state:'ok',detail:'Provider-cached pool candles. Gaps are kept; the last candle may still be open.'};
  try{const conf=INTERVALS[interval];const raw=await get(`/networks/${NETWORKS[network].gecko}/pools/${base.pool.address}/ohlcv/${conf.unit}?aggregate=${conf.aggregate}&limit=240&currency=usd&token=${address}&include_empty_intervals=false`);base.candles=normalizeCandles(raw,network,address);if(!base.candles.length)throw new Error('No usable candles were returned for this interval.');base.state='ok';base.fetchedAt=new Date().toISOString();base.detail='Pool-specific USD candles, not a consolidated market price. Gaps are kept; the last candle may still be open.';await writeCache(cacheKey,{candles:base.candles,fetchedAt:base.fetchedAt});return base;}catch(e){const stale=await readCache<Pick<ChartResult,'candles'|'fetchedAt'>>(cacheKey,86400000);if(stale)return {...base,...stale.data,state:'stale',...(e instanceof AllowanceError?{resetsAt:e.resetsAt,code:e.code}:{}),detail:'Showing an earlier saved chart. '+(e instanceof Error?e.message:'Provider unavailable.')};throw e;}
 }catch(e){return {...base,state:'unavailable',...(e instanceof AllowanceError?{resetsAt:e.resetsAt,code:e.code}:{}),detail:e instanceof Error?e.message:'The chart provider is unavailable.'}}
}

// An explicitly selected pool must never be replaced by a token-wide chart.
export async function chart(report:LensReport,interval:Interval,requestedPool?:string,extended=false):Promise<ChartResult>{
 if(!Object.hasOwn(INTERVALS,interval))throw new Error('Choose a supported candle interval.');
 const fallback=supportsBirdeyeChart(report,requestedPool);
 if(fallback){const cached=await cachedBirdeyeChart(report,interval);if(cached)return cached;}
 const primary=await geckoChart(report,interval,requestedPool);
 if(primary.state==='ok'||!fallback)return primary;
 if(!extended){
  const old=await cachedBirdeyeChart(report,interval,86400000);
  if(old&&primary.state!=='stale')return {...old,state:'stale',needsExtended:true,detail:'Showing an earlier saved chart. Extended refresh is available on request.'};
  return {...primary,needsExtended:true,detail:primary.state==='stale'?primary.detail:'The standard chart is unavailable. Request the extended chart or open the market link.'};
 }
 try{return await birdeyeChart(report,interval)}catch(e){return {...primary,...(e instanceof AllowanceError?{resetsAt:e.resetsAt,code:e.code}:{}),detail:primary.state==='stale'?'Showing an earlier saved chart. '+(e instanceof Error?e.message:'Provider unavailable.'):e instanceof Error?e.message:'Alternative chart source is unavailable.'};}
}
