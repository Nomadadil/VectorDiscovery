import {sharedResearch} from './shared-research';
import {env} from 'cloudflare:workers';
import {birdeyeCached} from './birdeye-client';
import {fetchJson} from './http';
import {readCache,writeCache} from './cache';
import {NETWORKS,validAddress,formatUnits,decimalUnits,num,clean,type Network} from './types';
import type {WalletPortfolio,WalletAsset,PositionPnL} from './portfolio-types';
const NATIVE_SOL='So11111111111111111111111111111111111111111';
const safeImage=(v:unknown)=>{try{const u=new URL(String(v));return u.protocol==='https:'&&!u.username&&!u.password?u.href:null}catch{return null}};
const timestamp=(v:unknown)=>{const d=new Date(typeof v==='number'?(v<1e12?v*1000:v):String(v));return Number.isFinite(d.getTime())?d.toISOString():null};
export function normalizePortfolio(raw:any,wallet:string,offset:number){
 const d=raw?.data,p=raw?.pagination;if(raw?.success===false||!d||!Array.isArray(d.items)||(d.wallet||d.wallet_address)!==wallet||d.currency?.toLowerCase()!=='usd'||!Number.isInteger(p?.total)||p.total<0||p.offset!==offset)throw new Error('The portfolio response is incomplete.');
 const items:WalletAsset[]=[],seen=new Set<string>();
 for(const row of d.items){if(row.network!=='solana'||!validAddress(row.address,'solana')||seen.has(row.address)||!/^\d+$/.test(String(row.balance))||!Number.isInteger(row.decimals)||row.decimals<0||row.decimals>36)throw new Error('The portfolio response is incomplete.');seen.add(row.address);
 const price=num(row.price),value=num(row.value);items.push({address:row.address,native:row.address===NATIVE_SOL,name:clean(row.name,80)||'Token',symbol:clean(row.symbol,24)||'TOKEN',logo:safeImage(row.logo_uri),balance:String(row.balance),amount:formatUnits(String(row.balance),row.decimals),price:price!==null&&price>0?price:null,value:price!==null&&price>0&&value!==null&&value>=0?value:null,pnl:null});}
 if(d.items.length>100)throw new Error('The portfolio response is incomplete.');
 if(!d.items.length&&offset<p.total)throw new Error('The portfolio page did not advance.');
 return {items,totalValue:num(d.total_value),totalItems:p.total,nextOffset:offset+d.items.length<p.total&&offset+d.items.length<=10000?offset+d.items.length:null,at:timestamp(d.current_timestamp)||new Date().toISOString()};
}
export function normalizePositions(raw:any,wallet:string,addresses:string[]){
 const d=raw?.data;if(raw?.success===false||!d||!Array.isArray(d.tokens)||d.meta?.address!==wallet||(d.meta.currency&&d.meta.currency.toLowerCase()!=='usd'))throw new Error('The position history response is incomplete.');
 const result:Record<string,PositionPnL>={};const allowed=new Set(addresses);
 for(const row of d.tokens){if(!allowed.has(row.address))continue;if(result[row.address])throw new Error('Duplicate position history.');const p=row.pnl,q=row.quantity,c=row.cashflow_usd;
 const holding=num(q?.holding);const value=num(c?.current_value),unrealized=num(p?.unrealized_usd),cost=value!==null&&unrealized!==null?value-unrealized:null;
 // A percentage only has meaning when the indexed position has a positive cost basis.
 const historyPrice=num(row.pricing?.current_price);const hasBasis=holding!==null&&holding>0&&historyPrice!==null&&historyPrice>0&&value!==null&&value>=0&&cost!==null&&cost>0&&Number.isFinite(cost)&&Number.isFinite(100*unrealized!/cost);
 result[row.address]={holding,unrealized:hasBasis?unrealized:null,percent:hasBasis?100*unrealized!/cost!:null,realized:num(p?.realized_profit_usd),total:num(p?.total_usd),totalPercent:num(p?.total_percent),averageBuy:hasBasis?cost!/holding!:null};}
 return {items:result,at:timestamp(d.meta?.time)||new Date().toISOString()};
}
async function loadWalletPortfolio(network:Network,wallet:string,offset=0):Promise<WalletPortfolio>{
 if(!Object.hasOwn(NETWORKS,network)||!validAddress(wallet,network))throw new Error('Enter a valid wallet address on the selected network.');
 if(!Number.isInteger(offset)||offset<0||offset>10000)throw new Error('Invalid portfolio page.');
 const base:WalletPortfolio={state:'unavailable',network,wallet,at:new Date().toISOString(),totalValue:null,items:[],totalItems:null,offset,nextOffset:null,complete:false,pnlState:'unavailable',pnlAt:null,detail:'',pnlDetail:''};
 if(network!=='solana')return evmPortfolio(base);
 try{
  const h=await birdeyeCached(`portfolio:v1:${wallet}:${offset}`,120000,`/wallet/v2/current-net-worth?${new URLSearchParams({wallet,sort_by:'value',sort_type:'desc',offset:String(offset),limit:'100',flags:'include_low_liquidity'})}`,{cost:20,chain:'solana'},r=>normalizePortfolio(r,wallet,offset));
  const result:WalletPortfolio={...base,...h.data,state:'ok',complete:offset+h.data.items.length>=h.data.totalItems,detail:'Current indexed holdings. Low-liquidity assets are included. Valuations are estimates, not cash available to withdraw.'};
  const mints=result.items.filter(x=>!x.native).map(x=>x.address);
  if(!mints.length){result.pnlState='ok';return result}
  try{
   const p=await birdeyeCached(`positions:v1:${wallet}:${mints.join(',')}`,300000,'/wallet/v2/pnl/details',{cost:30,chain:'solana',body:{wallet,token_addresses:mints,duration:'all',position_scope:'duration_only',pnl_method:'wac',sort_by:'last_trade',sort_type:'desc',offset:0,limit:100}},r=>normalizePositions(r,wallet,mints));
   result.items=result.items.map(x=>({...x,pnl:p.data.items[x.address]||null}));result.pnlAt=p.data.at;result.pnlState=mints.every(a=>p.data.items[a])?'ok':'partial';
  }catch(e){result.pnlDetail=e instanceof Error?e.message:'Position history is unavailable.';}
  return result;
 }catch(e){return {...base,detail:e instanceof Error?e.message:'Wallet balances are unavailable.'}}
}
async function evmPortfolio(base:WalletPortfolio):Promise<WalletPortfolio>{
 const {network,wallet}=base,key=`portfolio:evm:v1:${network}:${wallet.toLowerCase()}`,cached=await readCache<WalletPortfolio>(key,120000);if(cached)return cached.data;
 try{
  const url=(env as any)[network.toUpperCase()+'_RPC_URL']||NETWORKS[network].rpc;
  const rpc=async(method:string,params:unknown[])=>{const j=await fetchJson(url,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method,params})},7000);if(j.error||!/^0x[0-9a-f]+$/i.test(j.result))throw new Error('Wallet balances are unavailable.');return j.result as string};
  if(BigInt(await rpc('eth_chainId',[]))!==BigInt(NETWORKS[network].chainId!))throw new Error('RPC network mismatch.');
  const block=await rpc('eth_blockNumber',[]),balance=BigInt(await rpc('eth_getBalance',[wallet,block])).toString(),symbol=network==='bsc'?'BNB':'ETH';
  const result:WalletPortfolio={...base,state:'partial',pnlState:'unsupported',items:[{address:'native',native:true,name:symbol,symbol,logo:null,balance,amount:formatUnits(balance,18),price:null,value:null,pnl:null}],detail:'Native balance at an RPC block snapshot. Token holdings and position PnL are not connected for this network.'};
  await writeCache(key,result);return result;
 }catch(e){return {...base,pnlState:'unsupported',detail:e instanceof Error?e.message:'Wallet balances are unavailable.'}}
}

export async function walletPortfolio(network:Network,wallet:string,offset=0):Promise<WalletPortfolio>{
 // Validate before creating any durable cache/lease key. EVM addresses share casing.
 if(!Object.hasOwn(NETWORKS,network)||!validAddress(wallet,network)||!Number.isInteger(offset)||offset<0||offset>10000)throw new Error('Enter a valid wallet address and portfolio page.');
 const address=network==='solana'?wallet:wallet.toLowerCase(),key=`portfolio-snapshot:v2:${network}:${address}:${offset}`;
 try{return await sharedResearch(key,120000,async()=>{
  const result=await loadWalletPortfolio(network,address,offset);
  if(result.state==='unavailable'){const old=await readCache<WalletPortfolio>(key,86400000);if(old)return {...old.data,state:'stale' as const,detail:'Showing a saved portfolio. '+result.detail};}
  if(result.state==='ok'||result.state==='partial')await writeCache(key,result);
  return result;
 },r=>r.state==='ok'||r.state==='partial');}
 catch(e){const old=await readCache<WalletPortfolio>(key,86400000);if(old)return {...old.data,state:'stale',detail:'Showing a saved portfolio. '+(e instanceof Error?e.message:'Refresh unavailable.')};throw e;}
}
