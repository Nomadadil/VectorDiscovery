import type {TokenIntelligence} from './intelligence';
import type {TokenContext} from './token-context';
import type {HolderWindow} from './holder-sample';
export type Network = 'ethereum'|'bsc'|'solana';
export type SourceState = 'ok'|'partial'|'not_configured'|'unavailable'|'unsupported';
export type Tone = 'neutral'|'good'|'warn'|'bad';
export type Source = {id:string;name:string;state:SourceState;detail:string;url:string;fetchedAt:string;observedAt?:string};
export type Fact = {id:string;label:string;value:string;signal:boolean|null;tone:Tone;source:string;detail:string};
export type Holder = {address:string;balance:string|null;share:number|null;label:string;kind:string;source:string;shareSource?:string;locked?:boolean|null;lockUntil?:string|null};
// Retained observations are useful individually, but must not form a mixed-snapshot total.
export function sumHolderShares(rows:Holder[]):number|null{
 if(!rows.length||rows.some(h=>h.share===null||!Number.isFinite(h.share)||h.share<0||h.share>100))return null;
 if(new Set(rows.map(h=>h.shareSource||h.source)).size!==1)return null;
 const total=rows.reduce((n,h)=>n+h.share!,0);return total<=100.01?Math.min(total,100):null;
}
export type Pool = {address:string;dex:string;quote:string;liquidityUsd:number|null;volume24h:number|null;priceUsd:number|null;buys:number|null;sells:number|null;createdAt:string|null;url:string;source:string;feePercent?:number|null;liquidityType?:string;};
export type Period = {volume:number|null;buys:number|null;sells:number|null;change:number|null};
export type Advanced = {
 profile?:{links:{label:string;url:string}[];source:string};
 periods?:Record<string,Period>;
 explorer?:{creator:string|null;creationTx:string|null;createdAt:string|null;block:string|null;verification:string;verifiedAt:string|null;compiler:string|null;language:string|null;url:string;fetchedAt:string};
 lp?:{count:number|null;items:{address:string;share:number|null;locked:boolean|null;label:string}[];source:string};
 reserves?:{pool:string;token:number|null;other:number|null;quote:string};
 poolFees?:{pool:string;fee:number|null;type:string}[];
 poolLocks?:{pool:string;name:string;percent:number|null;usd:number|null;source:string}[];
 lockerRecords?:{label:string;until:string|null;url:string;source:string}[];
};
export type Link = {from:string;to:string;transfers:number|null;source:string;txHash?:string;at?:string;amount?:string};
export type LensReport = {
 schemaVersion:1;rulesVersion:'1.0';id:string;mode:'live'|'demo';generatedAt:string;network:Network;address:string;
 intelligence?:TokenIntelligence;
 advanced?:Advanced;
 context?:TokenContext;
 holderWindow?:HolderWindow;
 recentHolders?:{items:Holder[];links:Link[];window:HolderWindow;transfers?:import('./intelligence').TransferEvidence[]};
 token:{name:string;symbol:string;decimals:number|null;totalSupply:string|null};
 sources:Source[];facts:Fact[];findings:{title:string;detail:string;tone:Tone;module:string}[];
 market:{priceUsd:number|null;marketCap:number|null;fdv:number|null;liquidityUsd:number|null;volume24h:number|null;buys:number|null;sells:number|null;change24h:number|null;pools:Pool[]};
 holders:{total:number|null;countSource:string|null;items:Holder[];links:Link[];source:string;scope:string;topShare:number|null;adjustedShare:number|null;excluded:number;updatedAt:string|null};
 creator:{address:string|null;owner:string|null;history:{address:string;label:string}[];historyState:string};
 simulation:{success:boolean|null;honeypot:boolean|null;buyTax:number|null;sellTax:number|null;transferTax:number|null;maxSell:string|null;pair:string|null;scope:string;source:string;error:string|null;sample:{total:number|null;successful:number|null;failed:number|null}|null};
 liquidity:{locks:{address:string;label:string;share:number|null;until:string|null;source:string;scope:string}[];scope:string};
 activity:{orders:{type:string;status:string;at:string|null}[];boosts:number|null;ordersAvailable:boolean;transfers:{from:string;to:string;amount:string;hash:string;at:string}[]};
 chain:{block:string|null;hash:string|null;codePresent:boolean|null;ownerCall:string|null;implementation:string|null;source:string};
 coverage:{available:number;requested:number;gaps:string[]};
};
export type WatchItem = {id:string;network:Network;address:string;symbol:string;reportId:string;createdAt:string;checkedAt:string;paused:boolean;threshold:number};
export type WatchEvent = {id:string;watchId:string;symbol:string;title:string;detail:string;at:string;reportId:string;tone:Tone};
export type Quote = {state:'ok'|'not_configured'|'unavailable'|'unsupported';detail:string;provider:string;at:string;amount:string;buyAmount?:string;buySymbol?:string;buyDecimals?:number;minBuyAmount?:string;route?:string[];block?:string;gas?:string;estimatedImpact?:string|null;feeBps?:number|null};
export const NETWORKS:Record<Network,{name:string;chainId:number|null;dex:string;gecko:string;explorer:string;rpc:string;example:string}>={
 ethereum:{name:'Ethereum',chainId:1,dex:'ethereum',gecko:'eth',explorer:'https://etherscan.io',rpc:'https://ethereum-rpc.publicnode.com',example:'0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2'},
 bsc:{name:'BNB Chain',chainId:56,dex:'bsc',gecko:'bsc',explorer:'https://bscscan.com',rpc:'https://bsc-dataseed.bnbchain.org',example:'0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c'},
 solana:{name:'Solana',chainId:null,dex:'solana',gecko:'solana',explorer:'https://solscan.io',rpc:'https://api.mainnet-beta.solana.com',example:'So11111111111111111111111111111111111111112'}
};
export const shortAddress=(value:string)=>value.length>16?`${value.slice(0,6)}…${value.slice(-4)}`:value;
export const sameAddress=(a:string,b:string,network:Network)=>network==='solana'?a===b:a.toLowerCase()===b.toLowerCase();
export const num=(v:unknown):number|null=>(typeof v!=='number'&&typeof v!=='string')||(typeof v==='string'&&!v.trim())||!Number.isFinite(Number(v))?null:Number(v);
export const tri=(v:unknown):boolean|null=>v==='1'||v===1||v===true?true:v==='0'||v===0||v===false?false:null;
export const clean=(v:unknown,max=120)=>typeof v==='string'?v.replace(/[\u0000-\u001f]/g,' ').slice(0,max):'';
export const pct=(v:unknown,multiply=1)=>{const n=num(v);return n===null?null:n*multiply};
export function validAddress(address:string,network:Network){
 if(!Object.hasOwn(NETWORKS,network)||typeof address!=='string')return false;
 if(network!=='solana')return /^0x[0-9a-fA-F]{40}$/.test(address);
 if(!/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(address))return false;
 const alphabet='123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';let n=BigInt(0);for(const c of address)n=n*BigInt(58)+BigInt(alphabet.indexOf(c));let bytes=0;for(let x=n;x>0;x>>=BigInt(8))bytes++;return bytes+(address.match(/^1*/)?.[0].length||0)===32;
}
export function parseInput(input:string,selected:Network):{network:Network;address:string;pair:boolean}{
 if(!Object.hasOwn(NETWORKS,selected))throw new Error('Choose a supported network.');
 let value=input.trim(),network=selected,pair=false;
 if(value.length>600)throw new Error('The address or link is too long.');
 if(/^https?:\/\//i.test(value)){
  const u=new URL(value);if(u.protocol!=='https:'||u.username||u.password)throw new Error('Use an HTTPS explorer or DEX Screener link.');
  const parts=u.pathname.split('/').filter(Boolean);
  if(u.hostname==='dexscreener.com'||u.hostname==='www.dexscreener.com'){
   const n=Object.keys(NETWORKS).find(k=>NETWORKS[k as Network].dex===parts[0]) as Network|undefined;if(!n)throw new Error('That DEX Screener network is not supported yet.');network=n;value=parts[1]||'';pair=true;
  }else{
   const n=Object.keys(NETWORKS).find(k=>new URL(NETWORKS[k as Network].explorer).hostname===u.hostname) as Network|undefined;
   if(!n||!['token','address'].includes(parts[0]))throw new Error('Paste a token address, DEX Screener pair link or supported explorer token link.');network=n;value=parts[1]||'';
  }
 }
 if(!validAddress(value,network))throw new Error(network==='solana'?'Enter a valid 32-byte Solana mint address.':'Enter the full token contract address: 0x followed by 40 hexadecimal characters.');
 if(!pair&&network!=='solana'&&(/^0x0{40}$/i.test(value)||/^0xe{40}$/i.test(value)))throw new Error('Use the wrapped token contract, not a native-asset placeholder.');
 return {network,address:network==='solana'?value:value.toLowerCase(),pair};
}
export function decimalUnits(value:string,decimals:number):string{
 if(!Number.isInteger(decimals)||decimals<0||decimals>36||!/^\d{1,30}(\.\d{1,36})?$/.test(value))throw new Error('Enter a valid token amount.');
 const [a,b='']=value.split('.');if(b.length>decimals&&/[1-9]/.test(b.slice(decimals)))throw new Error(`This token supports ${decimals} decimal places.`);
 const units=BigInt(a+b.slice(0,decimals).padEnd(decimals,'0'));if(units<=0)throw new Error('Amount must be greater than zero.');return units.toString();
}
export function formatUnits(value:string,decimals:number){if(!/^\d+$/.test(value))return value;const s=value.padStart(decimals+1,'0');return decimals?`${s.slice(0,-decimals)}.${s.slice(-decimals).replace(/0+$/,'')||'0'}`:s;}
export function publicSourceUrl(url:string){try{const u=new URL(url);return u.protocol==='https:'&&!u.username&&!u.password?u.href:''}catch{return ''}}
