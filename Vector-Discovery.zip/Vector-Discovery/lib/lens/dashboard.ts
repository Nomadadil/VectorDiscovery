import {db} from './storage';
import type {LensReport,Network} from './types';
export interface RecentAsset {id:string;network:Network;address:string;name:string;symbol:string;image:string|null;price:number|null;at:string;viewedAt:string;paused?:boolean}
export interface LensDashboard {recent:RecentAsset[];watched:RecentAsset[];walletCount:number}
export async function rememberReport(user:string,report:LensReport){
 if(report.mode!=='live')return;
 const database=db();
 await database.batch([
  database.prepare('INSERT INTO lens_recent_reports (user_id,network,address,report_id,viewed_at) VALUES (?,?,?,?,?) ON CONFLICT(user_id,network,address) DO UPDATE SET report_id=excluded.report_id,viewed_at=excluded.viewed_at').bind(user,report.network,report.address,report.id,new Date().toISOString()),
  database.prepare('DELETE FROM lens_recent_reports WHERE user_id=? AND rowid NOT IN (SELECT rowid FROM lens_recent_reports WHERE user_id=? ORDER BY viewed_at DESC,rowid DESC LIMIT 12)').bind(user,user)
 ]);
}
function asset(row:any):RecentAsset{
 const r=JSON.parse(row.payload) as LensReport;
 return {id:r.id,network:r.network,address:r.address,name:r.token.name,symbol:r.token.symbol,image:r.context?.image||null,price:r.market?.priceUsd??null,at:r.generatedAt,viewedAt:row.viewed_at||r.generatedAt,...(row.paused===undefined?{}:{paused:!!row.paused})};
}
export async function dashboard(user:string):Promise<LensDashboard>{
 const database=db();
 const [recent,watched,count]=await Promise.all([
  database.prepare('SELECT r.payload,h.viewed_at FROM lens_recent_reports h JOIN lens_reports r ON r.id=h.report_id WHERE h.user_id=? ORDER BY h.viewed_at DESC,h.rowid DESC LIMIT 12').bind(user).all(),
  database.prepare('SELECT r.payload,w.paused FROM lens_watches w JOIN lens_reports r ON r.id=w.report_id WHERE w.user_id=? ORDER BY w.paused,w.created_at DESC LIMIT 20').bind(user).all(),
  database.prepare('SELECT COUNT(*) AS total FROM lens_wallets WHERE user_id=?').bind(user).first<{total:number}>()
 ]);
 return {recent:recent.results.map(asset),watched:watched.results.map(asset),walletCount:count?.total||0};
}
