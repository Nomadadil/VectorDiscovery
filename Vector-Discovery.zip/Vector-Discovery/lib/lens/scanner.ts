import {env} from 'cloudflare:workers';
import {solanaSecurity} from './solana-security';
import {readCache,writeCache} from './cache';
import {throttle} from './storage';
import {enrichIntelligence} from './intelligence';
import {tokenContextRead} from './token-context';
import {recentHolderSample} from './holder-sample';
import {fetchJson} from './http';
import {enrichDex,enrichGo,enrichRug,explorerRead} from './advanced';
import {NETWORKS,sumHolderShares,clean,num,tri,pct,sameAddress,validAddress,publicSourceUrl,type Network,type LensReport,type Source,type Holder,type Pool} from './types';
const docs={dex:'https://docs.dexscreener.com/api/reference',go:'https://docs.gopluslabs.io/reference/response-details',honey:'https://docs.honeypot.is/ishoneypot',rug:'https://rugcheck.xyz/',bit:'https://docs.bitquery.io/',bubble:'https://docs.bubblemaps.io/',sniffer:'https://tokensniffer.com/',rpc:'https://ethereum.org/developers/docs/apis/json-rpc/'};
export function emptyReport(network:Network,address:string):LensReport{return {schemaVersion:1,rulesVersion:'1.0',id:crypto.randomUUID(),mode:'live',generatedAt:new Date().toISOString(),network,address,token:{name:'Token',symbol:'TOKEN',decimals:null,totalSupply:null},sources:[],facts:[],findings:[],market:{priceUsd:null,marketCap:null,fdv:null,liquidityUsd:null,volume24h:null,buys:null,sells:null,change24h:null,pools:[]},holders:{total:null,countSource:null,items:[],links:[],source:'Not available',scope:'Holder coverage has not been established.',topShare:null,adjustedShare:null,excluded:0,updatedAt:null},creator:{address:null,owner:null,history:[],historyState:'Earlier deployments have not been established.'},simulation:{success:null,honeypot:null,buyTax:null,sellTax:null,transferTax:null,maxSell:null,pair:null,scope:'No sell simulation is available.',source:'Not available',error:null,sample:null},liquidity:{locks:[],scope:'Lock status is not established for all pools.'},activity:{orders:[],boosts:null,ordersAvailable:false,transfers:[]},chain:{block:null,hash:null,codePresent:null,ownerCall:null,implementation:null,source:'RPC'},coverage:{available:0,requested:0,gaps:[]}}}
function source(r:LensReport,id:string,name:string,state:Source['state'],detail:string,url:string){r.sources.push({id,name,state,detail,url,fetchedAt:new Date().toISOString()})}
function flag(r:LensReport,id:string,label:string,value:unknown,provider:string,detail:string,inverse=false){const v=tri(value);r.facts.push({id,label,value:v===null?'Not established':v?'Detected':'Not detected',signal:v,tone:v===null?'neutral':inverse?(v?'neutral':'warn'):(v?'warn':'neutral'),source:provider,detail});}
function safeAddress(value:unknown,network:Network){const s=clean(value,80);return validAddress(s,network)?s:null}
function validDate(v:unknown){if(typeof v!=='string'&&typeof v!=='number')return null;const d=new Date(v);return Number.isFinite(d.getTime())?d.toISOString():null}
const sumKnown=(a:(number|null)[])=>a.length&&a.every(x=>x!==null)?a.reduce<number>((s,x)=>s+(x||0),0):null;
export function normalizeDex(r:LensReport,raw:any){
 const rows=Array.isArray(raw)?raw:[];const seen=new Set();const pairs=rows.filter(p=>p?.chainId===NETWORKS[r.network].dex&&(sameAddress(p.baseToken?.address||'',r.address,r.network)||sameAddress(p.quoteToken?.address||'',r.address,r.network))).filter(p=>!seen.has(p.pairAddress)&&seen.add(p.pairAddress));
 const base=pairs.filter(p=>sameAddress(p.baseToken.address,r.address,r.network));base.sort((a,b)=>(num(b.liquidity?.usd)||0)-(num(a.liquidity?.usd)||0));const primary=base[0];
 const identity=primary?.baseToken || pairs[0]?.quoteToken;if(identity){r.token.name=clean(identity.name,70)||r.token.name;r.token.symbol=clean(identity.symbol,20)||r.token.symbol;}
 r.market.pools=pairs.slice(0,40).map((p:any):Pool=>{const isBase=sameAddress(p.baseToken?.address||'',r.address,r.network);return {address:clean(p.pairAddress,140),dex:clean(p.dexId,40),quote:clean(isBase?p.quoteToken?.symbol:p.baseToken?.symbol,20),liquidityUsd:num(p.liquidity?.usd),volume24h:num(p.volume?.h24),priceUsd:isBase?num(p.priceUsd):null,buys:isBase?num(p.txns?.h24?.buys):num(p.txns?.h24?.sells),sells:isBase?num(p.txns?.h24?.sells):num(p.txns?.h24?.buys),createdAt:validDate(p.pairCreatedAt),url:publicSourceUrl(p.url||''),source:'DEX Screener'}});
 if(primary){r.market.priceUsd=num(primary.priceUsd);r.market.marketCap=num(primary.marketCap);r.market.fdv=num(primary.fdv);r.market.change24h=num(primary.priceChange?.h24);r.activity.boosts=num(primary.boosts?.active);}
 r.market.liquidityUsd=sumKnown(r.market.pools.map(p=>p.liquidityUsd));r.market.volume24h=sumKnown(r.market.pools.map(p=>p.volume24h));r.market.buys=sumKnown(r.market.pools.map(p=>p.buys));r.market.sells=sumKnown(r.market.pools.map(p=>p.sells));
 enrichDex(r,pairs,primary);return pairs.length;
}
export function normalizeGo(r:LensReport,g:any){
 enrichGo(r,g);
 r.token.name=clean(g.token_name,70)||r.token.name;r.token.symbol=clean(g.token_symbol,20)||r.token.symbol;r.token.totalSupply=clean(g.total_supply,100)||null;
 const rows=[['is_honeypot','Honeypot signal','Provider detection. A negative signal is not a guarantee of sale.'],['is_mintable','Additional minting','Provider analysis of minting capability.'],['is_proxy','Proxy contract','GoPlus proxy classification; other call-path detectors may differ.'],['hidden_owner','Hidden owner','Provider analysis of administrative control.'],['owner_change_balance','Administrator can change balances','This capability can affect balances without a normal holder transfer.'],['is_blacklisted','Address blocking','Administrative capability; context matters for regulated assets.'],['transfer_pausable','Transfers can be paused','A pause permission can affect trading.'],['slippage_modifiable','Trading fees can change','Provider detection of modifiable tax/slippage settings.'],['cannot_sell_all','Full-position sell restriction','Provider-specific detection; inspect simulation scope.'],['trading_cooldown','Trading cooldown','A time restriction may apply between transactions.']];
 for(const [key,label,detail] of rows)flag(r,'go-'+key,label,g[key],'GoPlus',detail);flag(r,'go-is_open_source','Verified source',g.is_open_source,'GoPlus','Published source code is not a security audit.',true);
 r.creator.address=safeAddress(g.creator_address,r.network);r.creator.owner=safeAddress(g.owner_address,r.network);
 const total=num(g.holder_count);if(total!==null){r.holders.total=total;r.holders.countSource='GoPlus';}
 if(Array.isArray(g.holders)&&g.holders.length){r.holders.items=g.holders.slice(0,50).filter((h:any)=>safeAddress(h.address,r.network)).map((h:any):Holder=>({address:h.address,balance:clean(h.balance,100)||null,share:pct(h.percent,100),label:clean(h.tag,80)||'Unlabelled address',kind:tri(h.is_contract)?'contract':'unclassified',source:'GoPlus',locked:tri(h.is_locked),lockUntil:Array.isArray(h.locked_detail)?h.locked_detail.map((x:any)=>num(x.end_time)).filter((x:any)=>x!==null&&x>0).sort((a:number,b:number)=>b-a).map((x:number)=>validDate(x*1000))[0]||null:null}));r.holders.source='GoPlus';r.holders.scope=`${r.holders.items.length} provider-returned addresses; partial distribution. Percentages use provider-reported total supply.`;}
 for(const lp of Array.isArray(g.lp_holders)?g.lp_holders.slice(0,20):[]){for(const lock of Array.isArray(lp.locked_detail)?lp.locked_detail.slice(0,8):[]){const end=num(lock.end_time);r.liquidity.locks.push({address:clean(lp.address,100),label:clean(lock.tag||lp.tag,50)||'Reported LP lock',share:null,until:end?validDate(end*1000):null,source:'GoPlus',scope:'A lock record was returned. The share belonging to this individual lock is not established; the holder’s full LP balance is not assigned to this lock.'})}}
 r.simulation.buyTax=pct(g.buy_tax,100);r.simulation.sellTax=pct(g.sell_tax,100);r.simulation.transferTax=pct(g.transfer_tax,100);r.simulation.source='GoPlus';r.simulation.scope='Reported contract taxes from GoPlus. No completed provider sell simulation has been established.';
}
export function normalizeHoney(r:LensReport,h:any){
 if(h?.token?.address&&!sameAddress(h.token.address,r.address,r.network))throw new Error('Provider token identity mismatch.');
 const returnedChain=num(h.pair?.chainId);if(returnedChain!==null&&returnedChain!==NETWORKS[r.network].chainId)throw new Error('Provider network mismatch.');
 if(h.token?.address&&sameAddress(h.token.address,r.address,r.network)){r.token.name=clean(h.token.name,70)||r.token.name;r.token.symbol=clean(h.token.symbol,20)||r.token.symbol;}
 if(num(h.token?.decimals)!==null)r.token.decimals=num(h.token.decimals);const sim=h.simulationResult;const success=tri(h.simulationSuccess);
 r.simulation={success,honeypot:tri(h.honeypotResult?.isHoneypot),buyTax:num(sim?.buyTax),sellTax:num(sim?.sellTax),transferTax:num(sim?.transferTax),maxSell:sim?.maxSell?.token?String(sim.maxSell.token):null,pair:clean(h.pairAddress||h.pair?.pair?.address,140)||null,scope:'Honeypot.is selected the test amount and route. This does not test the amount you enter below.',source:'Honeypot.is',error:clean(h.simulationError,220)||null,sample:h.holderAnalysis?{total:num(h.holderAnalysis.holders),successful:num(h.holderAnalysis.successful),failed:num(h.holderAnalysis.failed)}:null};
 flag(r,'honey-honeypot','Honeypot simulation signal',h.honeypotResult?.isHoneypot,'Honeypot.is','Applies to the provider-selected route and current simulation.');flag(r,'honey-proxy','Proxy in checked code',h.contractCode?.isProxy,'Honeypot.is','Call-path analysis can include different code from a root-contract proxy check.');
 const reported=num(h.token?.totalHolders);if(r.holders.total===null&&reported!==null){r.holders.total=reported;r.holders.countSource='Honeypot.is';}
 else if(reported!==null&&r.holders.total!==null&&reported!==r.holders.total)r.facts.push({id:'honey-holder-count',label:'Alternative holder count',value:reported.toLocaleString('en-US'),signal:null,tone:'neutral',source:'Honeypot.is',detail:'Provider holder counts can differ by indexing time and methodology.'});
 if(success===null&&h.summary?.risk==='unknown')throw new Error('Provider could not establish a simulation result.');
}
export function normalizeRug(r:LensReport,g:any){
 if(g.mint!==undefined&&g.mint!==r.address)throw new Error('Provider mint identity mismatch.');
 r.token.name=clean(g.tokenMeta?.name,70)||r.token.name;r.token.symbol=clean(g.tokenMeta?.symbol,20)||r.token.symbol;r.token.decimals=num(g.token?.decimals);
 r.creator.address=safeAddress(g.creator,r.network);r.creator.owner=safeAddress(g.tokenMeta?.updateAuthority,r.network);
 for(const k of ['mintAuthority','freezeAuthority']){const v=g.token&&Object.hasOwn(g.token,k)?g.token[k]:g[k];flag(r,'rug-'+k,k==='mintAuthority'?'Mint authority present':'Freeze authority present',v===null?false:typeof v==='string'&&validAddress(v,'solana')?true:null,'RugCheck','An authority is a capability, not proof of malicious intent.');}
 for(const item of (Array.isArray(g.risks)?g.risks:[]).slice(0,16)){r.facts.push({id:'rug-'+clean(item.name,60),label:clean(item.name,100),value:clean(item.value,100)||clean(item.level,30)||'Reported',signal:null,tone:item.level==='danger'?'bad':'warn',source:'RugCheck',detail:clean(item.description,320)})}
 if(Array.isArray(g.topHolders)&&g.topHolders.length){r.holders.items=g.topHolders.slice(0,30).filter((x:any)=>validAddress(x.owner||x.address,'solana')).map((x:any)=>({address:x.owner||x.address,balance:x.amount===undefined?null:String(x.amount),share:num(x.pct),label:clean(g.knownAccounts?.[x.owner||x.address]?.name,60)||'Unlabelled account',kind:'account',source:'RugCheck'}));r.holders.source='RugCheck';r.holders.scope='Provider-returned accounts; multiple token accounts may belong to one wallet.';r.holders.total=num(g.totalHolders);r.holders.countSource='RugCheck';}
 const tokens=Array.isArray(g.creatorTokens)?g.creatorTokens:[];r.creator.history=tokens.slice(0,20).filter((x:any)=>safeAddress(x.mint,r.network)).map((x:any)=>({address:x.mint,label:clean(x.symbol||x.name,60)||'Earlier mint'}));if(tokens.length)r.creator.historyState='Provider-reported deployments; not a complete creator history.';
 enrichRug(r,g);
 r.facts.push({id:'rug-extensions',label:'Token-2022 extensions',value:g.token_extensions?'Provider data returned':'Not established',signal:null,tone:'neutral',source:'RugCheck',detail:'Absent extension data does not prove the token has no transfer hooks, delegates or other extensions.'});
}
async function rpcRead(r:LensReport){
 const configured=(env as any)[r.network.toUpperCase()+'_RPC_URL'];const url=configured||NETWORKS[r.network].rpc;let rpcId=1;
 const call=async(method:string,params:any[])=>{const j=await fetchJson(url,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:rpcId++,method,params})},5500);if(j.error||!Object.hasOwn(j,'result'))throw new Error('RPC could not complete this read.');return j.result;};
 if(r.network==='solana'){
  const result=await call('getAccountInfo',[r.address,{encoding:'jsonParsed',commitment:'confirmed'}]);const a=result?.value;const mint=a?.data?.parsed;
  const programs=['TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA','TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb'];
  if(!a||!programs.includes(a.owner)||mint?.type!=='mint')throw new Error('RPC did not return a recognized token mint.');
  r.chain.block=String(result.context.slot);r.chain.codePresent=null;r.chain.source='Solana RPC';r.token.decimals=num(mint.info.decimals);r.token.totalSupply=String(mint.info.supply||'');
  for(const k of ['mintAuthority','freezeAuthority'])flag(r,'rpc-'+k,k==='mintAuthority'?'Onchain mint authority':'Onchain freeze authority',mint.info[k]===null?false:typeof mint.info[k]==='string'?true:null,'Solana RPC','Observed mint authority at the reported confirmed slot. Other extensions may add capabilities.');
  const extensions=mint.info.extensions;if(Array.isArray(extensions))for(const x of extensions)r.facts.push({id:'extension-'+x.extension,label:'Token extension',value:clean(x.extension,80),signal:null,tone:'neutral',source:'Solana RPC',detail:'Extension observed on the mint. Review the extension before interpreting transfer behavior.'});return;
 }
 const chain=await call('eth_chainId',[]);if(Number.parseInt(chain,16)!==NETWORKS[r.network].chainId)throw new Error('RPC returned a different network.');
 const block=await call('eth_blockNumber',[]);if(!/^0x[0-9a-f]+$/i.test(block))throw new Error('RPC returned an invalid block.');r.chain.block=BigInt(block).toString();
 const selectors=['0x8da5cb5b','0x313ce567'];const [code,owner,decimals,impl,blockInfo]=await Promise.allSettled([call('eth_getCode',[r.address,block]),...selectors.map(data=>call('eth_call',[{to:r.address,data},block])),call('eth_getStorageAt',[r.address,'0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc',block]),call('eth_getBlockByNumber',[block,false])]);
 if(code.status!=='fulfilled'||typeof code.value!=='string'||!/^0x[0-9a-f]*$/i.test(code.value))throw new Error('Contract code could not be read.');r.chain.codePresent=code.value!=='0x';if(!r.chain.codePresent)r.facts.push({id:'rpc-no-code',label:'Contract code',value:'No code at this block',signal:true,tone:'warn',source:'RPC',detail:'This address did not contain contract code at the selected block.'});
 const word=(x:PromiseSettledResult<any>)=>x.status==='fulfilled'&&/^0x[0-9a-f]{64}$/i.test(x.value)?x.value:null;
 const o=word(owner);if(o){r.chain.ownerCall='0x'+o.slice(-40);r.facts.push({id:'rpc-owner',label:'owner() read',value:r.chain.ownerCall,signal:null,tone:'neutral',source:'RPC',detail:'A returned address, including zero, does not establish all administrative roles or upgrade permissions.'});}
 const d=word(decimals);if(d){const n=Number(BigInt(d));if(n>=0&&n<=36)r.token.decimals=n;}
 const im=word(impl);if(im&&BigInt(im)!==BigInt(0)){const a='0x'+im.slice(-40);const c=await call('eth_getCode',[a,block]).catch(()=>null);if(c&&c!=='0x'){r.chain.implementation=a;r.facts.push({id:'rpc-implementation',label:'ERC-1967 implementation slot',value:a,signal:true,tone:'warn',source:'RPC',detail:'A nonzero implementation address with code. Upgrade authority has not been established.'});}}
 if(blockInfo.status==='fulfilled')r.chain.hash=clean(blockInfo.value?.hash,80)||null;
}
async function bubbleRead(r:LensReport){
 if(!env.BUBBLEMAPS_API_KEY){source(r,'bubblemaps','Bubblemaps','not_configured','Wallet links require a connected Bubblemaps account.',docs.bubble);return;}
 await run(r,'bubblemaps','Bubblemaps',docs.bubble,async()=>{
  const chain=r.network==='ethereum'?'eth':r.network;
  const j=await fetchJson(`https://api.bubblemaps.io/v0/tokens/map/${chain}/${r.address}?limit=80&return_nodes=true&return_relationships=true&return_clusters=true`,{headers:{'X-ApiKey':env.BUBBLEMAPS_API_KEY!}},18000);
  const nodes=j.nodes?.top_holders;if(!Array.isArray(nodes)||!nodes.length)throw new Error('No map is available for this token.');
  r.holders.items=nodes.filter((n:any)=>validAddress(n.address,r.network)).map((n:any)=>({address:n.address,balance:n.holder_data?.amount===undefined?null:String(n.holder_data.amount),share:pct(n.holder_data?.share,100),label:clean(n.address_details?.label,80)||(n.address_details?.is_cex?'Exchange':n.address_details?.is_dex?'DEX/pool':'Unlabelled address'),kind:n.address_details?.is_cex?'exchange':n.address_details?.is_dex?'pool':n.address_details?.is_contract?'contract':'unclassified',source:'Bubblemaps'}));
  r.holders.links=(Array.isArray(j.relationships)?j.relationships:[]).filter((x:any)=>validAddress(x.from_address,r.network)&&validAddress(x.to_address,r.network)).slice(0,160).map((x:any)=>({from:x.from_address,to:x.to_address,transfers:num(x.data?.total_transfers),source:'Bubblemaps'}));r.holders.source='Bubblemaps';r.holders.scope='Top holder map. Links are observed transfer relationships, not proof of one owner.';r.holders.updatedAt=validDate(j.metadata?.dt_update);
  return `${r.holders.items.length} map addresses; ${r.holders.links.length} relationships.`;
 });
}
async function bitqueryTransfers(r:LensReport,net:string){
 await run(r,'bitquery-transfers','Bitquery transfers',docs.bit,async()=>{
  const query=`query LensTransfers($token: String!) { EVM(network: ${net}, dataset: realtime) { Transfers(where: {Transfer: {Currency: {SmartContract: {is: $token}}, Success: true}}, orderBy: {descending: Block_Time}, limit: {count: 50}) { Block { Time Number } Transaction { Hash } Transfer { Amount Sender Receiver Success } } } }`;
  const j=await fetchJson('https://streaming.bitquery.io/graphql',{method:'POST',headers:{'content-type':'application/json',Authorization:`Bearer ${env.BITQUERY_ACCESS_TOKEN}`},body:JSON.stringify({query,variables:{token:r.address}})},12000);
  if(j.errors?.length||!Array.isArray(j.data?.EVM?.Transfers))throw new Error('Recent transfers are unavailable for this account or network.');
  r.activity.transfers=j.data.EVM.Transfers.filter((x:any)=>validAddress(x.Transfer?.Sender,r.network)&&validAddress(x.Transfer?.Receiver,r.network)&&/^0x[0-9a-f]{64}$/i.test(x.Transaction?.Hash||'')&&validDate(x.Block?.Time)).slice(0,50).map((x:any)=>({from:x.Transfer.Sender,to:x.Transfer.Receiver,amount:String(x.Transfer.Amount),hash:x.Transaction.Hash,at:validDate(x.Block.Time)!}));
  return `${r.activity.transfers.length} recent transfer rows. This bounded window does not establish unique traders or organic volume.`;
 });
}
async function bitqueryRead(r:LensReport){
 if(!env.BITQUERY_ACCESS_TOKEN){source(r,'bitquery','Bitquery','not_configured','Extended holder and transfer history requires a Bitquery account.',docs.bit);return;}
 if(!['ethereum','bsc'].includes(r.network)){source(r,'bitquery','Bitquery','unsupported','This adapter currently covers selected EVM networks.',docs.bit);return;}
 const net=r.network==='ethereum'?'eth':r.network;
 await Promise.all([bitqueryTransfers(r,net),run(r,'bitquery','Bitquery holders',docs.bit,async()=>{
  const query=`query LensHolders($token: String!) { EVM(network: ${net}, dataset: archive) { holders: Holders(where: {Currency: {SmartContract: {is: $token}}, Balance: {Amount: {gt: "0"}}}, orderBy: {descending: Balance_Amount}, limit: {count: 20}) { Holder { Address } Balance { Amount } } stats: Holders(where: {Currency: {SmartContract: {is: $token}}, Balance: {Amount: {gt: "0"}}}) { count total: sum(of: Balance_Amount) } } }`;
  const j=await fetchJson('https://streaming.bitquery.io/graphql',{method:'POST',headers:{'content-type':'application/json',Authorization:`Bearer ${env.BITQUERY_ACCESS_TOKEN}`},body:JSON.stringify({query,variables:{token:r.address}})},12000);
  if(j.errors?.length)throw new Error('Holder query is unavailable for this account or network.');const a=j.data?.EVM;if(!a?.holders?.length)throw new Error('No indexed holder distribution returned.');
  if(!r.holders.items.length){r.holders.items=a.holders.filter((x:any)=>validAddress(x.Holder?.Address,r.network)).map((x:any)=>({address:x.Holder.Address,balance:String(x.Balance.Amount),share:null,label:'Unlabelled address',kind:'unclassified',source:'Bitquery'}));r.holders.source='Bitquery';r.holders.scope='Twenty largest indexed balances. Supply percentages are not inferred.';}
  if(r.holders.total===null){r.holders.total=num(a.stats?.[0]?.count);r.holders.countSource='Bitquery';}return 'Indexed holder data returned.';
 })]);
}
async function snifferRead(r:LensReport){
 if(!env.TOKENSNIFFER_API_KEY){source(r,'tokensniffer','TokenSniffer','not_configured','Creator history and code similarity need a TokenSniffer account.',docs.sniffer);return;}
 if(r.network==='solana'){source(r,'tokensniffer','TokenSniffer','unsupported','Use the Solana source set for this mint.',docs.sniffer);return;}
 await run(r,'tokensniffer','TokenSniffer',docs.sniffer,async()=>{
  const j=await fetchJson(`https://tokensniffer.com/api/v2/tokens/${NETWORKS[r.network].chainId}/${r.address}?include_similar=true`,{headers:{'X-API-Key':env.TOKENSNIFFER_API_KEY!}},10000);
  if(j.status&&j.status!=='ready')throw new Error('TokenSniffer analysis is still pending.');
  if(Array.isArray(j.similar))for(const s of j.similar.slice(0,10)){const a=safeAddress(s.address,r.network);if(a)r.facts.push({id:'sniffer-similar-'+a,label:'Similar contract',value:a,signal:null,tone:'neutral',source:'TokenSniffer',detail:'Code similarity does not prove the same creator or intent.'});}
  if(r.creator.address){
   const history=await fetchJson(`https://tokensniffer.com/api/v2/addresses/${r.creator.address}`,{headers:{'X-API-Key':env.TOKENSNIFFER_API_KEY!}},10000);
   if(history.message&&history.message!=='OK')throw new Error('Creator history was not returned.');
   if(Array.isArray(history.contracts)){r.creator.history=history.contracts.filter((c:any)=>Number(c.chainId)===NETWORKS[r.network].chainId&&safeAddress(c.address,r.network)).slice(0,30).map((c:any)=>({address:c.address,label:Array.isArray(c.types)?c.types.map((x:any)=>clean(x,30)).join(', '):'Provider-flagged deployment'}));r.creator.historyState=`TokenSniffer reported ${num(history.malicious_contracts_count)??'an unknown number of'} flagged deployments across its networks. Listed rows match this network; this is not a complete deployment history.`;}
  }
  return 'Code similarity and available creator-history response received.';
 });
}
async function run(r:LensReport,id:string,name:string,url:string,fn:()=>Promise<string|void|{detail:string;observedAt:string}>){try{const result=await fn();source(r,id,name,'ok',(typeof result==='object'?result.detail:result)||'Response received. Inspect each finding for scope and missing fields.',url);if(typeof result==='object')r.sources[r.sources.length-1].observedAt=result.observedAt;}catch(e){source(r,id,name,'unavailable',e instanceof Error?e.message:'Provider is unavailable.',url)}}
export function finalize(r:LensReport){
 r.findings=[];
 for(const h of r.holders.items){if(r.market.pools.some(p=>sameAddress(p.address,h.address,r.network))){h.kind='pool';h.label='Observed liquidity pool';}else if(r.network!=='solana'&&/^0x0{36}(?:0000|dead)$/i.test(h.address)){h.kind='burn';h.label='Burn address';}}
 r.holders.topShare=sumHolderShares(r.holders.items);
 const excluded=r.holders.items.filter(x=>['pool','exchange','burn','bridge'].includes(x.kind));r.holders.excluded=excluded.length;r.holders.adjustedShare=r.holders.topShare===null?null:r.holders.topShare-excluded.reduce((s,x)=>s+(x.share||0),0);
 r.coverage.available=r.sources.filter(s=>s.state==='ok'||s.state==='partial').length;r.coverage.requested=r.sources.length;r.coverage.gaps=r.sources.filter(s=>s.state!=='ok').map(s=>`${s.name}: ${s.detail}`);
 if(r.simulation.honeypot===true)r.findings.push({title:'A honeypot signal was returned',detail:'Inspect the provider result and route before interpreting it. No transaction was sent by Vector Discovery.',tone:'bad',module:'Exit Check'});
 else if(r.simulation.success===true)r.findings.push({title:'A sell simulation completed',detail:'The provider-tested amount and route completed. Your chosen position size is a separate check.',tone:'good',module:'Exit Check'});
 else r.findings.push({title:'Sale outcome is not established',detail:r.simulation.error||'A supported sell simulation did not return a usable result.',tone:'warn',module:'Exit Check'});
 const capability=r.facts.find(f=>f.tone==='warn'&&f.signal===true&&!f.id.includes('proxy'));
 if(capability)r.findings.push({title:capability.label,detail:capability.detail,tone:'warn',module:'Creator'});
 else r.findings.push({title:r.holders.items.length?'See who holds the supply':'Holder coverage is incomplete',detail:r.holders.items.length?`${r.holders.items.length} addresses returned. Contract and exchange balances need context.`:'A missing holder dataset does not imply an even distribution.',tone:'neutral',module:'Holders'});
 const proxy=r.facts.find(f=>f.id==='go-is_proxy');const hproxy=r.facts.find(f=>f.id==='honey-proxy');
 if(proxy&&hproxy&&proxy.signal!==null&&hproxy.signal!==null&&proxy.signal!==hproxy.signal)r.findings.push({title:'Proxy checks differ',detail:'GoPlus and Honeypot.is returned different classifications. Their scopes can differ; both are preserved.',tone:'warn',module:'Creator'});
 else r.findings.push({title:r.coverage.gaps.length?'Some checks remain open':'Review the scope of each check',detail:r.coverage.gaps.length?`${r.coverage.gaps.length} sources are unavailable, unsupported or need access. No missing result is counted as a pass.`:'Source responses are observations, not a guarantee of future trading conditions.',tone:'neutral',module:'Overview'});
}
export async function scan(network:Network,address:string,options:{deep?:boolean;onProgress?:(stage:'market'|'checks'|'research',report:LensReport)=>Promise<void>}={}):Promise<LensReport>{
 const r=emptyReport(network,address);let rugMarkets:any;const calls:Promise<any>[]=[];
 // Start the independent request early, but apply it after GoPlus so provenance
 // and precedence remain deterministic. A failed request cannot reject unhandled.
 const honeyRequest=['ethereum','bsc'].includes(network)?fetchJson(`https://api.honeypot.is/v2/IsHoneypot?address=${address}&chainID=${NETWORKS[network].chainId}`,{},12000).then(data=>({data,error:null as unknown}),error=>({data:null,error})):null;
 const progress=async(stage:'market'|'checks'|'research')=>{if(options.onProgress){const snapshot=structuredClone(r);finalize(snapshot);await options.onProgress(stage,snapshot);}};
 calls.push(run(r,'dexscreener','DEX Screener',docs.dex,async()=>{const j=await fetchJson(`https://api.dexscreener.com/token-pairs/v1/${NETWORKS[network].dex}/${address}`);const n=normalizeDex(r,j);if(!n)throw new Error('No matching pools returned on this network.');return `${n} matching pools returned. Totals cover these pools only.`}).then(()=>progress('market')));
 calls.push(run(r,'promotion','DEX Screener promotion',docs.dex,async()=>{const j=await fetchJson(`https://api.dexscreener.com/orders/v1/${NETWORKS[network].dex}/${address}`);const list=Array.isArray(j)?j:j.orders;if(!Array.isArray(list))throw new Error('Promotion data was not returned.');r.activity.orders=list.slice(0,30).map((x:any)=>({type:clean(x.type,60),status:clean(x.status,40),at:validDate(x.paymentTimestamp)}));r.activity.ordersAvailable=true;return 'Paid profile/order metadata, not proof of quality or organic demand.'}));
 if(network==='solana')calls.push(run(r,'rugcheck','RugCheck',docs.rug,async()=>{const j=await fetchJson(`https://api.rugcheck.xyz/v1/tokens/${address}/report`,{},12000,5000000);normalizeRug(r,j);rugMarkets=j.markets;}));
 else calls.push(run(r,'goplus','GoPlus',docs.go,async()=>{const key=`goplus-v1:${network}:${address}`;const cached=await readCache<any>(key,180000);let g=cached?.data,at=cached?.at;if(!g){await throttle('goplus-upstream',25);const j=await fetchJson(`https://api.gopluslabs.io/api/v1/token_security/${NETWORKS[network].chainId}?contract_addresses=${address}`,{headers:env.GOPLUS_ACCESS_TOKEN?{Authorization:`Bearer ${env.GOPLUS_ACCESS_TOKEN}`}:{}});g=j.result?.[address.toLowerCase()];if(j.code!==1||!g||!Object.keys(g).length)throw new Error('No token security data returned.');at=Date.now();await writeCache(key,g);}normalizeGo(r,g);return {detail:'Contract and holder checks. Inspect the observation time and coverage.',observedAt:new Date(at!).toISOString()};}));
 calls.push(solanaSecurity(r));
 calls.push(explorerRead(r));
 calls.push(run(r,'rpc','Onchain reads',docs.rpc,()=>rpcRead(r)));
 await Promise.all(calls);
 if(rugMarkets){const raw={markets:rugMarkets};const tmp=emptyReport(network,address);tmp.market.pools=r.market.pools;enrichRug(tmp,raw);r.advanced||={};r.advanced.poolLocks=tmp.advanced?.poolLocks;}
 if(['ethereum','bsc'].includes(network))await run(r,'honeypot','Honeypot.is',docs.honey,async()=>{const result=await honeyRequest!;if(result.error)throw result.error;normalizeHoney(r,result.data);});
 else source(r,'honeypot','Honeypot.is','unsupported','This provider supports Ethereum and BNB Chain.',docs.honey);
 await progress('checks');
 await Promise.all([options.deep?bitqueryRead(r):Promise.resolve(source(r,'bitquery','Bitquery',env.BITQUERY_ACCESS_TOKEN?'partial':'not_configured','Extended checks load only when requested.',docs.bit)),options.deep?snifferRead(r):Promise.resolve(source(r,'tokensniffer','TokenSniffer',env.TOKENSNIFFER_API_KEY?'partial':'not_configured','Extended checks load only when requested.',docs.sniffer)),options.deep?bubbleRead(r):Promise.resolve(source(r,'bubblemaps','Bubblemaps',env.BUBBLEMAPS_API_KEY?'partial':'not_configured',env.BUBBLEMAPS_API_KEY?'Open Holders and request the relationship map.':'Wallet links require a connected Bubblemaps account.',docs.bubble))]);
 await tokenContextRead(r);
 await progress('research');
 if(options.deep)await enrichIntelligence(r,true);
 if(options.deep&&r.holders.source!=='Bubblemaps')await recentHolderSample(r);
 finalize(r);return r;
}

export const RETRY_SECTIONS=['market','sale','context','research'] as const;
export type RetrySection=typeof RETRY_SECTIONS[number];
/** New immutable snapshot. Untouched sections retain their original source times. */
export async function retrySection(previous:LensReport,section:RetrySection):Promise<LensReport>{
 if(!RETRY_SECTIONS.includes(section)||previous.mode!=='live')throw new Error('Choose a supported live report section.');
 const r=structuredClone(previous),fresh=emptyReport(r.network,r.address);
 r.id=crypto.randomUUID();r.generatedAt=new Date().toISOString();
 if(section==='market'){
  r.market=fresh.market;r.advanced||={};delete r.advanced.periods;delete r.advanced.reserves;delete r.advanced.profile;r.activity.boosts=null;
  r.sources=r.sources.filter(s=>s.id!=='dexscreener');
  await run(r,'dexscreener','DEX Screener',docs.dex,async()=>{const n=normalizeDex(r,await fetchJson(`https://api.dexscreener.com/token-pairs/v1/${NETWORKS[r.network].dex}/${r.address}`));if(!n)throw new Error('No matching pools returned on this network.');return `${n} matching pools returned. Totals cover these pools only.`});
 }else if(section==='sale'){
  // Only the provider simulation is retried. Other contract observations keep
  // their source and timestamp; they are not presented as a fresh simulation.
  r.sources=r.sources.filter(s=>s.id!=='honeypot');r.facts=r.facts.filter(f=>!f.id.startsWith('honey-'));r.simulation=fresh.simulation;
  if(['ethereum','bsc'].includes(r.network))await run(r,'honeypot','Honeypot.is',docs.honey,async()=>{normalizeHoney(r,await fetchJson(`https://api.honeypot.is/v2/IsHoneypot?address=${r.address}&chainID=${NETWORKS[r.network].chainId}`,{},12000))});
  else source(r,'honeypot','Honeypot.is','unsupported','This provider supports Ethereum and BNB Chain.',docs.honey);
 }else if(section==='context'){
  r.sources=r.sources.filter(s=>s.id!=='token-context');
  if(r.holders.countSource==='GeckoTerminal'){r.holders.total=null;r.holders.countSource=null;}
  // Remove profile fields owned by the retried source before an outage can
  // leave them looking current under the new report timestamp.
  if(r.context&&r.advanced?.profile){const previousLinks=new Set(r.context.links.map(l=>l.url));r.advanced.profile.links=r.advanced.profile.links.filter(l=>!previousLinks.has(l.url));r.advanced.profile.source='DEX Screener';}
  delete r.context;
  await tokenContextRead(r);
 }else{
  r.sources=r.sources.filter(s=>!s.id.startsWith('intel-')&&s.id!=='holder-window'&&s.id!=='bubblemaps'&&s.id!=='bitquery'&&s.id!=='bitquery-transfers'&&s.id!=='tokensniffer');
  r.activity.transfers=[];
  if(r.intelligence?.launch?.creator&&r.creator.address===r.intelligence.launch.creator)r.creator.address=null;
  r.holders.items=r.holders.items.filter(h=>!h.source.startsWith('Birdeye')&&h.source!=='Bubblemaps'&&h.source!=='Bitquery');
  r.holders.links=r.holders.links.filter(l=>!l.source.startsWith('Birdeye')&&l.source!=='Bubblemaps');
  if(r.holders.countSource==='Birdeye'||r.holders.countSource==='Bitquery'){r.holders.total=null;r.holders.countSource=null;}
  r.holders.source=[...new Set(r.holders.items.map(h=>h.source))].join(' / ')||'Not available';r.holders.updatedAt=null;r.holders.scope='Retained contract-check holder sample; extended evidence is being refreshed.';
  delete r.intelligence;delete r.recentHolders;delete r.holderWindow;
  r.facts=r.facts.filter(f=>f.source!=='TokenSniffer');
  r.creator.history=[];r.creator.historyState='Not checked';
  await Promise.all([bitqueryRead(r),snifferRead(r)]);
  await enrichIntelligence(r,true);await bubbleRead(r);
  if(r.holders.source!=='Bubblemaps')await recentHolderSample(r);
 }
 finalize(r);return r;
}
