import {fetchJson} from './http';
import {readCache,writeCache} from './cache';
import {throttle,db} from './storage';
import {reserve,dayWindow,withResearchContext,researchContext,AllowanceError} from './economy';
import {sharedResearch} from './shared-research';
import {quote} from './quote';
import {emptyReport} from './scanner';
import {NETWORKS,num,type Network} from './types';
import {saveSignalsPage,signalLastRun} from './signals-storage';
import {normalizeSignalPools,marketChecks,enrichSignalPool,permissionCheck,rugCheck,solanaLock,evmLock,sellSimulation,routeCheck,unknownCheck,makeSignal,type SignalPool} from './signals-normalizers';
import type {SignalItem,SignalsPage,SignalCheck} from './signals-types';
const MAX_CANDIDATES=80;
export const SIGNAL_SCAN_LIMITS={cacheSeconds:{solana:300,ethereum:900,bsc:900},maxChecksPerNetwork:{solana:4,ethereum:3,bsc:3},maxRetainedCandidates:MAX_CANDIDATES,maxChecksDaily:1800,maxSecurityRequestsDaily:4500} as const;
const cacheMs=(network:Network)=>SIGNAL_SCAN_LIMITS.cacheSeconds[network]*1000;
class SignalBudgetError extends Error {}
async function source(url:string,init:RequestInit={},security=false){
 if(security&&!await reserve('signals-security-day',dayWindow(),1,SIGNAL_SCAN_LIMITS.maxSecurityRequestsDaily))throw new SignalBudgetError('Signals check allowance has been reached.');
 if(url.startsWith('https://api.rugcheck.xyz/')){const now=Date.now(),slot=await db().prepare(`INSERT INTO lens_rate_limits(key,window,count) VALUES('signals-rug-next-request',?,0) ON CONFLICT(key) DO UPDATE SET window=MAX(window+1100,excluded.window) WHERE window<=excluded.window+7000 RETURNING window`).bind(now).first<{window:number}>();if(!slot)throw new Error('Token checks are busy.');if(slot.window>now)await new Promise(r=>setTimeout(r,slot.window-now));}
 return fetchJson(url,init,6500,5000000);
}
async function poolList(network:Network,kind:'new_pools'|'trending_pools',page=1){
 await throttle('gecko-upstream',9);
 const params=new URLSearchParams({include:'base_token,quote_token',page:String(page)});if(kind==='trending_pools')params.set('duration','1h');
 return normalizeSignalPools(await source(`https://api.geckoterminal.com/api/v2/networks/${NETWORKS[network].gecko}/${kind}?${params}`),network);
}
async function rawOrNull(work:()=>Promise<any>){try{return await work()}catch(e){if(e instanceof SignalBudgetError||e instanceof AllowanceError)throw e;return null}}
async function checkCandidate(input:SignalPool,now:number):Promise<SignalItem>{
 const dex=await rawOrNull(()=>source(`https://api.dexscreener.com/token-pairs/v1/${NETWORKS[input.network].dex}/${input.address}`));
 const enriched=enrichSignalPool(input,dex,now),p=enriched.pool,base=marketChecks(p,120,now);
 if(p.network==='solana')base.push(enriched.ageCheck);
 if(base.some(x=>x.state==='fail'))return makeSignal(p,base,null,now);
 // The daily bound is shared by all readers and the scheduled scanner.
 if(!await reserve('signals-candidates-day',dayWindow(),1,SIGNAL_SCAN_LIMITS.maxChecksDaily))throw new SignalBudgetError('Signals check allowance has been reached.');
 const sol=p.network==='solana';
 const [security,risk,simulation,lpRpc]=await Promise.all([
  rawOrNull(async()=>{await throttle('goplus-upstream',25);return source(`https://api.gopluslabs.io/api/v1/${sol?'solana/token_security':`token_security/${NETWORKS[p.network].chainId}`}?contract_addresses=${p.address}`,{},true)}),
  sol?rawOrNull(()=>source(`https://api.rugcheck.xyz/v1/tokens/${p.address}/report`,{},true)):Promise.resolve(null),
  !sol?rawOrNull(()=>source(`https://api.honeypot.is/v2/IsHoneypot?address=${p.address}&chainID=${NETWORKS[p.network].chainId}&pair=${p.pool}`,{},true)):Promise.resolve(null),
  !sol?rawOrNull(()=>source(NETWORKS[p.network].rpc,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(['0x18160ddd','0x70a08231'+'0'.repeat(64),'0x70a08231'+'0'.repeat(60)+'dead','0x0dfe1681','0xd21220a7'].map((data,i)=>({jsonrpc:'2.0',id:i+1,method:'eth_call',params:[{to:p.pool,data},'latest']})))},true)):Promise.resolve(null)
 ]);
 const lock=sol?solanaLock(risk,p,now):evmLock(lpRpc,p,now),checks:SignalCheck[]=[...base,permissionCheck(security,p.network,p.address,now),lock.check];
 if(sol){
  checks.push(rugCheck(risk,p.address,now));
  const decimals=num(risk?.mint===p.address?risk.token?.decimals:null);
  if(checks.every(x=>x.state==='pass')&&decimals!==null&&Number.isInteger(decimals)&&decimals>=0&&decimals<=18&&p.price!==null&&p.price>0){
   const amount=(10/p.price).toFixed(Math.min(decimals,12)),r=emptyReport(p.network,p.address);r.token.decimals=decimals;
   try{const q=await quote(r,amount);checks.push(routeCheck(q.state,Date.now()));}catch{checks.push(routeCheck('unavailable',now));}
  }else checks.push(unknownCheck('sell-route',now));
 }else checks.push(sellSimulation(simulation,p,now));
 return makeSignal(p,checks,lock,now);
}
const priority=(p:SignalPool,now:number)=>marketChecks(p,120,now).reduce((n,x)=>n+(x.state==='pass'?3:x.state==='fail'?-1:0),0);
export function currentSignals(page:SignalsPage,maxAgeMinutes:60|120,now=Date.now()):SignalsPage{
 const within=(x:SignalItem)=>page.network!=='solana'||now-Date.parse(x.createdAt)<=maxAgeMinutes*60000;
 const items=page.items.filter(x=>within(x)&&Date.parse(x.expiresAt)>now);
 const pending=page.pending.filter(within);
 return {...page,maxAgeMinutes,items,pending,stale:page.stale||now-Date.parse(page.at)>cacheMs(page.network)+5*60000};
}
async function scan(network:Network):Promise<SignalsPage>{
 const now=Date.now(),at=new Date(now).toISOString(),previous=await signalLastRun(network);
 const calls=network==='solana'?[poolList(network,'new_pools',1),poolList(network,'new_pools',2),poolList(network,'trending_pools',1)]:[poolList(network,'trending_pools',1)];
 const results=await Promise.allSettled(calls),ok=results.filter((r):r is PromiseFulfilledResult<SignalPool[]>=>r.status==='fulfilled');
 const retained=await readCache<SignalPool[]>('signal-candidates:v1:'+network,2*3600000);
 const base:SignalsPage={network,mode:network==='solana'?'fresh':'trending',maxAgeMinutes:120,at,lastSuccessfulAt:ok.length?at:previous?.last_success||null,nextRefreshAt:new Date(now+cacheMs(network)).toISOString(),stale:false,status:ok.length===calls.length?'ok':ok.length?'partial':'unavailable',items:[],pending:[],excludedCount:0,scannedCount:0,checkedCount:0,
  coverage:network==='solana'?'Bounded sample: two new-pool pages plus one active-pool page, with recent candidates revisited. Pool age is not verified token launch time.':'Bounded sample: one trending-pool page. The security checks apply to the selected pool.',detail:ok.length?'':'Market data is temporarily unavailable. Previous alerts are not kept active.'};
 if(!ok.length)return saveSignalsPage({...base,stale:true});
 const map=new Map<string,SignalPool>();
 // Older retained rows only help rediscover candidates; their market metrics
 // are refreshed from a current token-pair response before qualification.
 for(const p of network==='solana'?retained?.data||[]:[])map.set(p.address,p);
 for(const p of ok.flatMap(x=>x.value)){const before=map.get(p.address);if(!before||Date.parse(p.createdAt)<Date.parse(before.createdAt)||p.pool===before.pool)map.set(p.address,p);}
 const rows=[...map.values()].filter(p=>network!=='solana'||now-Date.parse(p.createdAt)<=120*60000).sort((a,b)=>priority(b,now)-priority(a,now)||Date.parse(b.createdAt)-Date.parse(a.createdAt)).slice(0,MAX_CANDIDATES);
 await writeCache('signal-candidates:v1:'+network,rows);base.scannedCount=rows.length;
 const valid=rows;
 const queue=valid.slice(0,SIGNAL_SCAN_LIMITS.maxChecksPerNetwork[network]),checked:SignalItem[]=[];base.checkedCount=queue.length;
 await Promise.all(Array.from({length:3},async()=>{while(queue.length){const p=queue.shift()!;try{checked.push(await checkCandidate(p,now));}catch(e){const unknown={...p,cap:null,fdv:null,liquidity:null,price:null,volumeH1:null,changeH1:null,buysH1:null,sellsH1:null,transactionsH1:null};checked.push(makeSignal(unknown,[...marketChecks(unknown,120,now),unknownCheck(e instanceof SignalBudgetError||e instanceof AllowanceError?'check-budget':'permissions',now),unknownCheck('lp-lock',now)],null,now));}}}));
 for(const item of checked){if(item.checks.some(c=>c.state==='fail'))base.excludedCount++;else if(item.status==='qualified')base.items.push(item);else base.pending.push(item);}
 base.items.sort((a,b)=>Date.parse(b.createdAt)-Date.parse(a.createdAt));base.pending.sort((a,b)=>a.reasons.length-b.reasons.length||Date.parse(b.createdAt)-Date.parse(a.createdAt));
 if(valid.length>SIGNAL_SCAN_LIMITS.maxChecksPerNetwork[network])base.detail='The highest-matching candidates were checked within the shared refresh allowance. This is not a complete list of tokens.';
 if(base.pending.some(x=>x.reasons.includes('check-budget')))base.detail='The shared daily check allowance has been reached. Missing checks remain unconfirmed; refresh resumes at 00:00 UTC.';
 if(base.pending.length||ok.length<calls.length)base.status='partial';
 return saveSignalsPage(base);
}
export async function getSignals(network:Network,maxAgeMinutes:60|120=120):Promise<SignalsPage>{
 if(!Object.hasOwn(NETWORKS,network)||![60,120].includes(maxAgeMinutes))throw new Error('Choose a supported network and a one- or two-hour window.');
 const work=()=>sharedResearch(`vector-signals:v1:${network}`,cacheMs(network),()=>scan(network));
 // A public snapshot has one shared budget context even without caller context.
 // Personal subscription operations never flow through this shared cache.
 const page=await(researchContext()?work():withResearchContext('vector-signals','monitoring',work));
 return currentSignals(page,maxAgeMinutes);
}
