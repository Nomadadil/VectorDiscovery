import {db,digest} from './storage';
import {reserve,dayWindow,nextDay,AllowanceError} from './economy';

// Quota identity only: this cookie never grants access to account data.
// Server registration prevents a caller from choosing an arbitrary actor ID.
export async function guestBudget(req:Request):Promise<{actor:string;cookie?:string}>{
 const secure=new URL(req.url).protocol==='https:';
 const name=secure?'__Host-vector-discovery-guest':'vector-discovery-guest';
 const token=req.headers.get('cookie')?.split(';').map(x=>x.trim()).find(x=>x.startsWith(name+'='))?.slice(name.length+1);
 if(token&&/^[a-f0-9]{64}$/.test(token)){
  const hash=await digest(token);
  const row=await db().prepare('SELECT window FROM lens_rate_limits WHERE key=?').bind('guest-session:'+hash).first<{window:number}>();
  if(row&&row.window>Date.now())return {actor:'guest:'+hash};
 }
 // Cookie clearing is not proof of a new person. Bound issuance and keep the
 // shared guest + service budgets independent of the number of cookies.
 if(!await reserve('guest-session-issuance',dayWindow(),1,2000))throw new AllowanceError('GUEST_SESSION_LIMIT',nextDay(),'Guest access is busy today. Sign in or try again after the daily reset.');
 const value=crypto.randomUUID().replaceAll('-','')+crypto.randomUUID().replaceAll('-',''),hash=await digest(value);
 const expires=Date.now()+7*86400000;
 await db().batch([
  db().prepare('INSERT INTO lens_rate_limits (key,window,count) VALUES (?,?,0)').bind('guest-session:'+hash,expires),
  db().prepare("DELETE FROM lens_rate_limits WHERE key LIKE 'guest-session:%' AND window<=?").bind(Date.now())
 ]);
 return {actor:'guest:'+hash,cookie:`${name}=${value}; Path=/; Max-Age=604800; HttpOnly; SameSite=Lax${secure?'; Secure':''}`};
}
