import {env} from 'cloudflare:workers';
import {db} from './storage';
import {readCache,writeCache} from './cache';
import {fetchJson} from './http';
import {singleFlight} from './shared-research';
import {ECONOMY,reserveDailyCU,deny,nextMonth,meter,AllowanceError,researchContext} from './economy';

// Shared across all Birdeye features. Reserve credits atomically before requests.
// A conservative legacy baseline prevents a deployment from resetting this month's usage.
export async function reserveBirdeyeCredits(cost:number){
 if(!Number.isSafeInteger(cost)||cost<1||cost>1000)throw new Error('Invalid market-data reservation.');
 const month=new Date().getUTCFullYear()*12+new Date().getUTCMonth();
 const row=await db().prepare(`INSERT INTO lens_rate_limits (key,window,count)
 SELECT ?,?,? + COALESCE((SELECT count*100 FROM lens_rate_limits WHERE key='birdeye-month-budget' AND window=?),0)
 WHERE ? + COALESCE((SELECT count*100 FROM lens_rate_limits WHERE key='birdeye-month-budget' AND window=?),0)<=?
 ON CONFLICT(key) DO UPDATE SET count=CASE WHEN window=excluded.window THEN count+? ELSE excluded.count END,window=excluded.window
 WHERE CASE WHEN window=excluded.window THEN count+? ELSE excluded.count END<=? RETURNING count`)
 .bind('birdeye-cu-budget-v1',month,cost,month,cost,month,ECONOMY.monthlyCU,cost,cost,ECONOMY.monthlyCU).first<{count:number}>();
 if(!row||!Number.isSafeInteger(row.count)||row.count>ECONOMY.monthlyCU)await deny('MONTHLY_RESEARCH_LIMIT',nextMonth(),'The monthly research allowance has been reached.');
}
export async function birdeyeRequest(path:string,options:{cost:number;chain:string;body?:unknown}){
 if(!env.BIRDEYE_API_KEY)throw new Error('Extended research is not connected.');
 // A globally reserved time slot respects the Standard plan's 1 request/second.
 const now=Date.now();const slot=await db().prepare(`INSERT INTO lens_rate_limits (key,window,count) VALUES ('birdeye-next-request',?,0)
 ON CONFLICT(key) DO UPDATE SET window=MAX(window+1100,excluded.window) WHERE window<=excluded.window+13000 RETURNING window`).bind(now).first<{window:number}>();
 if(!slot)throw new Error('Research is busy. Please retry shortly.');
 const delay=slot.window-now;if(delay>14000)throw new Error('Research is busy. Please retry shortly.');
 if(delay>0)await new Promise(resolve=>setTimeout(resolve,delay));
 if(researchContext())await reserveDailyCU(options.cost);
 else await reserveBirdeyeCredits(options.cost);
 await meter('cu',options.cost);
 return fetchJson('https://public-api.birdeye.so'+path,{method:options.body===undefined?'GET':'POST',headers:{'X-API-KEY':env.BIRDEYE_API_KEY,'x-chain':options.chain,...(options.body===undefined?{}:{'content-type':'application/json'})},...(options.body===undefined?{}:{body:JSON.stringify(options.body)})},12000);
}
export async function birdeyeCached<T>(key:string,ttl:number,path:string,options:Parameters<typeof birdeyeRequest>[1],normalize:(raw:any)=>T):Promise<{data:T;at:string}>{
 return singleFlight('birdeye:'+key,async()=>{const cached=await readCache<{data:T;at:string}>(key,ttl);return cached?.data??null},async()=>{
 const failure=await readCache<{error:string;until:number}>(key+':failure',3600000);if(failure&&Date.now()<failure.data.until)throw new Error(failure.data.error);
 try{const result={data:normalize(await birdeyeRequest(path,options)),at:new Date().toISOString()};await writeCache(key,result);return result}
 catch(e){if(e instanceof AllowanceError)throw e;const error=e instanceof Error?e.message:'Extended research is temporarily unavailable.';await writeCache(key+':failure',{error,until:Date.now()+(error==='Provider access is unavailable.'?3600000:60000)});throw e}
 });
}
