import {NETWORKS,sameAddress,validAddress,clean,num,type Network} from './types';
import {fetchJson} from './http';
import {throttle} from './storage';
import {sharedResearch} from './shared-research';
import {INTERVALS,normalizeCandles,type ChartResult,type ChartPool,type Interval} from './chart';

export function signalChartPool(raw:any,network:Network,address:string,pool:string):ChartPool{
 const data=raw?.data,prefix=NETWORKS[network].gecko+'_';
 if(data?.type!=='pool'||data.id!==prefix+data.attributes?.address||!sameAddress(data.attributes?.address||'',pool,network))throw new Error('The chart pool could not be verified.');
 const tokenIds=['base_token','quote_token'].map(side=>data.relationships?.[side]?.data?.id);
 if(!tokenIds.some(id=>typeof id==='string'&&id.startsWith(prefix)&&sameAddress(id.slice(prefix.length),address,network)))throw new Error('This pool does not contain the requested token.');
 return {address:pool,name:clean(data.attributes.name,70),dex:clean(data.relationships?.dex?.data?.id,40),reserve:num(data.attributes.reserve_in_usd)};
}

// A card expands one pool-specific chart on demand. No full token scan or paid
// fallback is required; metadata verifies both the pool and token orientation.
export async function signalChart(network:Network,address:string,pool:string,interval:Interval='5m'):Promise<ChartResult>{
 if(!Object.hasOwn(NETWORKS,network)||!validAddress(address,network)||!validAddress(pool,network)||!['1m','5m','15m'].includes(interval))throw new Error('Choose a supported signal chart.');
 const base:ChartResult={network,address,interval,state:'unavailable',detail:'',candles:[],pools:[],pool:null,provider:'GeckoTerminal',scope:'pool',fetchedAt:new Date().toISOString()};
 try{return await sharedResearch(`signals-chart:v1:${network}:${address}:${pool}:${interval}`,120000,async()=>{
  const meta=await sharedResearch(`signals-pool:v1:${network}:${pool}:${address}`,300000,async()=>{
   await throttle('gecko-upstream',9);
   return signalChartPool(await fetchJson(`https://api.geckoterminal.com/api/v2/networks/${NETWORKS[network].gecko}/pools/${pool}`,{},9000),network,address,pool);
  });
  await throttle('gecko-upstream',9);const conf=INTERVALS[interval];
  const raw=await fetchJson(`https://api.geckoterminal.com/api/v2/networks/${NETWORKS[network].gecko}/pools/${pool}/ohlcv/${conf.unit}?aggregate=${conf.aggregate}&limit=120&currency=usd&token=${address}&include_empty_intervals=false`,{},9000);
  const candles=normalizeCandles(raw,network,address);
  return {...base,pool:meta,pools:[meta],candles,state:candles.length?'ok' as const:'unavailable' as const,fetchedAt:new Date().toISOString(),detail:candles.length?'Pool-specific USD candles. Gaps are preserved; the latest candle can still change.':'No candles have been returned for this new pool yet.'};
 },result=>result.state==='ok');}catch(e){return {...base,detail:e instanceof Error?e.message:'Chart is temporarily unavailable.'};}
}
