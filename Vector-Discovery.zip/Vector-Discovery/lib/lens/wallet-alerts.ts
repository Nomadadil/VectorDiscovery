import {db,digest} from './storage';
import {validAddress,clean,num} from './types';
import {birdeyeCached} from './birdeye-client';
import {acquireWalletLease,releaseWalletLease} from './wallet-leaders';
import {observeWalletHoldings} from './wallet-holdings';
import {backgroundEnabled} from './background-access';
import type {WalletSwapAlert,WalletFeed,WalletMonitor,BackgroundStatus} from './wallet-leader-types';
const integer=(v:unknown)=>{const n=num(v);return n!==null&&Number.isSafeInteger(n)&&n>=0?n:null};
export function normalizeWalletTrades(raw:any,wallet:string,from:number,to:number){
 const more=raw?.data?.has_next??raw?.data?.hasNext;
 if(raw?.success!==true||!Array.isArray(raw.data?.items)||typeof more!=='boolean')throw new Error('Wallet activity is incomplete.');
 const times=raw.data.items.map((x:any)=>integer(x.block_unix_time));if(times.some((x:number|null,i:number)=>x===null||x>to||(i>0&&x>times[i-1]))||more&&!times.length)throw new Error('Wallet activity order could not be verified.');
 const seen=new Set<string>(),items:(Omit<WalletSwapAlert,'id'|'walletId'|'label'|'seen'> & {eventKey:string})[]=[];
 for(const x of raw.data.items.slice(0,100)){
  if(x.owner!==wallet)throw new Error('Wallet activity identity mismatch.');
  const time=integer(x.block_unix_time),hash=x.tx_hash;if(x.tx_type!=='swap'||time===null||time<from||time>to||!/^[1-9A-HJ-NP-Za-km-z]{64,88}$/.test(hash||'')||/stake|wrap|liquidity|bridge/i.test(x.source||''))continue;
  const legs=[x.base,x.quote],a=legs.find(l=>l?.type_swap==='to'),b=legs.find(l=>l?.type_swap==='from');
  if(!a||!b||a===b||!validAddress(a.address||'','solana')||!validAddress(b.address||'','solana')||a.address===b.address)continue;
  const receive=num(a.ui_change_amount),spend=num(b.ui_change_amount);if(receive===null||spend===null||receive<=0||spend>=0)continue;
  const key=[hash,integer(x.ins_index)??'',integer(x.inner_ins_index)??'',a.address,b.address].join(':');if(seen.has(key))continue;seen.add(key);const usd=num(x.volume_usd);
  items.push({eventKey:key,wallet,network:'solana',kind:'swap',received:{address:a.address,symbol:clean(a.symbol,20)||a.address.slice(0,6),amount:receive},spent:{address:b.address,symbol:clean(b.symbol,20)||b.address.slice(0,6),amount:-spend},usd:usd!==null&&usd>=0?usd:null,hash,protocol:clean(x.source,50),at:new Date(time*1000).toISOString()});
 }return {items,hasNext:more&&!times.some((time:number)=>time<from)};
}
export async function walletFeed(user:string):Promise<WalletFeed>{
 const rows=await db().prepare('SELECT w.id,w.address,w.network,w.label,m.* FROM lens_wallets w JOIN lens_wallet_monitors m ON w.id=m.wallet_id AND w.user_id=m.user_id WHERE w.user_id=? ORDER BY w.created_at DESC').bind(user).all<any>();
 const alerts=await db().prepare('SELECT a.* FROM lens_wallet_alerts a JOIN lens_wallets w ON a.wallet_id=w.id AND a.user_id=w.user_id WHERE a.user_id=? ORDER BY a.at DESC LIMIT 100').bind(user).all<any>();
 const unread=await db().prepare('SELECT COUNT(*) AS n FROM lens_wallet_alerts a JOIN lens_wallets w ON a.wallet_id=w.id AND a.user_id=w.user_id WHERE a.user_id=? AND a.seen=0').bind(user).first<{n:number}>();
 return {items:alerts.results.map(x=>({...JSON.parse(x.payload),id:x.id,seen:!!x.seen})),monitors:rows.results.map((x):WalletMonitor=>({id:x.wallet_id,address:x.address,network:x.network,label:x.label,enabled:!!x.enabled,minUsd:x.min_usd,lastChecked:x.last_checked,error:x.error,backlog:!!x.window_end,gap:!!x.gap,startedAt:x.started_at})),unread:unread?.n||0,background:await backgroundStatus()};
}
export async function setWalletMonitor(user:string,id:string,enabled:boolean,minUsd:number){
 if(typeof enabled!=='boolean'||!Number.isSafeInteger(minUsd)||minUsd<0||minUsd>100000000)throw new Error('Choose a valid alert threshold.');
 const w=await db().prepare('SELECT * FROM lens_wallets WHERE id=? AND user_id=?').bind(id,user).first<any>();if(!w)throw new Error('Follow this wallet first.');if(w.network!=='solana')throw new Error('Trade alerts are currently available for Solana.');
 const now=new Date(),time=Math.floor(now.getTime()/1000);const result=await db().prepare(`INSERT INTO lens_wallet_monitors(wallet_id,user_id,enabled,min_usd,cursor,started_at) SELECT ?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM lens_wallets WHERE id=? AND user_id=?) AND (?=0 OR (SELECT COUNT(*) FROM lens_wallet_monitors WHERE user_id=? AND enabled=1 AND wallet_id<>?)<5)
 ON CONFLICT(wallet_id) DO UPDATE SET enabled=excluded.enabled,min_usd=excluded.min_usd,cursor=CASE WHEN enabled=0 AND excluded.enabled=1 THEN excluded.cursor ELSE cursor END,window_end=CASE WHEN enabled=0 AND excluded.enabled=1 THEN NULL ELSE window_end END,page_offset=CASE WHEN enabled=0 AND excluded.enabled=1 THEN 0 ELSE page_offset END,started_at=CASE WHEN enabled=0 AND excluded.enabled=1 THEN excluded.started_at ELSE started_at END,error=NULL`).bind(id,user,enabled?1:0,minUsd,time,now.toISOString(),id,user,enabled?1:0,user,id).run();if(!result.meta.changes)throw new Error('Up to five wallets can have active trade alerts. Pause one to enable another.');return walletFeed(user);
}
export async function markWalletAlertsRead(user:string,ids:string[],all=false){if(ids.length>99||ids.some(id=>typeof id!=='string'||!/^[a-f0-9]{64}$/.test(id)))throw new Error('Invalid notification selection.');if(all)await db().prepare('UPDATE lens_wallet_alerts SET seen=1 WHERE user_id=?').bind(user).run();else if(ids.length)await db().prepare(`UPDATE lens_wallet_alerts SET seen=1 WHERE user_id=? AND id IN (${ids.map(()=>'?').join(',')})`).bind(user,...ids).run();return walletFeed(user)}
// An hourly global quota applies equally to scheduled and manual refreshes.
// A historical heartbeat alone does not mean the scheduler is currently enabled.
export async function backgroundStatus():Promise<BackgroundStatus>{
 const row=await db().prepare("SELECT * FROM lens_background_state WHERE key=?").bind('wallets').first<any>();
 const enabled=backgroundEnabled();
 return {enabled,lastRun:row?.last_run||null,lastSuccess:row?.last_success||null,checked:row?.checked||0,error:enabled?row?.error||null:null,healthy:enabled&&!!row?.enabled&&!row?.error&&Date.now()-Date.parse(row.last_run||'')<9000000,intervalSeconds:3600,batchSize:2};
}
export async function reserveMonitorCheck(){
 const hour=Math.floor(Date.now()/3600000),month=new Date().getUTCFullYear()*12+new Date().getUTCMonth();
 const slot=await db().prepare(`INSERT INTO lens_rate_limits(key,window,count) VALUES('wallet-monitor-hour',?,1)
 ON CONFLICT(key) DO UPDATE SET window=excluded.window,count=CASE WHEN window=excluded.window THEN count+1 ELSE 1 END
 WHERE window<>excluded.window OR count<2 RETURNING count`).bind(hour).first();
 if(!slot)return false;
 const credits=await db().prepare(`INSERT INTO lens_rate_limits(key,window,count) VALUES('wallet-monitor-month',?,10)
 ON CONFLICT(key) DO UPDATE SET window=excluded.window,count=CASE WHEN window=excluded.window THEN count+10 ELSE 10 END
 WHERE window<>excluded.window OR count<=14990 RETURNING count`).bind(month).first();
 if(!credits)throw new Error('The monthly background allowance has been reached.');
 return true;
}
export async function runWalletMonitoring(user?:string){
 const scheduled=user===undefined,now=new Date(),iso=now.toISOString(),to=Math.floor(now.getTime()/1000)-30;
 const key='wallet-monitor-run',lease=await acquireWalletLease(key,300000);
 if(lease===null)return {checked:0,attempted:0,state:'busy',detail:'A wallet check is already running.'};
 let checked=0,attempted=0;const failures:string[]=[];
 try{
 if(scheduled)await db().prepare(`INSERT INTO lens_background_state(key,enabled,last_run,checked) VALUES('wallets',1,?,0) ON CONFLICT(key) DO UPDATE SET enabled=1,last_run=excluded.last_run,checked=0,error=NULL`).bind(iso).run();
 const rows=await db().prepare(`SELECT m.*,w.address,w.network,w.label FROM lens_wallet_monitors m JOIN lens_wallets w ON m.wallet_id=w.id AND m.user_id=w.user_id
 WHERE m.enabled=1 AND w.network='solana' AND (m.last_checked IS NULL OR m.last_checked<?) ${user?'AND m.user_id=?':''}
 ORDER BY COALESCE(m.last_checked,''),m.started_at,m.wallet_id LIMIT 2`).bind(new Date(now.getTime()-3300000).toISOString(),...(user?[user]:[])).all<any>();
 for(const m of rows.results){
  if(!await reserveMonitorCheck())break;
  attempted++;const owner=m.user_id,issues:string[]=[];
  const staleWindow=m.window_end&&m.window_end<to-86400,end=staleWindow?to:m.window_end||to,from=Math.max(m.cursor-2,to-86400),offset=staleWindow?0:m.page_offset||0;
  try{
   if(offset>=10000){await db().prepare('UPDATE lens_wallet_monitors SET cursor=?,window_end=NULL,page_offset=0,gap=1 WHERE wallet_id=? AND user_id=? AND enabled=1 AND cursor=? AND started_at=?').bind(end,m.wallet_id,owner,m.cursor,m.started_at).run();}
   else if(end>m.cursor){
    const result=await birdeyeCached(`wallet-trades-v1:${m.address}:${from}:${end}:${offset}`,300000,`/trader/txs/seek_by_time?address=${m.address}&tx_type=swap&before_time=${end}&offset=${offset}&limit=100&ui_amount_mode=raw`,{cost:10,chain:'solana'},j=>normalizeWalletTrades(j,m.address,from,end));
    const data=result.data,batch=[];
    for(const x of data.items){if(Date.parse(x.at)<Date.parse(m.started_at)||m.min_usd>0&&(x.usd===null||x.usd<m.min_usd))continue;
     const id=await digest(owner+':'+m.wallet_id+':'+x.eventKey),{eventKey,...rest}=x,event={...rest,id,walletId:m.wallet_id,label:m.label,seen:false};
     batch.push(db().prepare('INSERT OR IGNORE INTO lens_wallet_alerts(id,user_id,wallet_id,at,payload,seen) SELECT ?,?,?,?,?,0 WHERE EXISTS(SELECT 1 FROM lens_wallet_monitors WHERE wallet_id=? AND user_id=? AND enabled=1 AND started_at=? AND min_usd=?)').bind(id,owner,m.wallet_id,x.at,JSON.stringify(event),m.wallet_id,owner,m.started_at,m.min_usd));
    }
    batch.push(db().prepare('UPDATE lens_wallet_monitors SET cursor=?,window_end=?,page_offset=?,gap=MAX(gap,?) WHERE wallet_id=? AND user_id=? AND enabled=1 AND cursor=? AND started_at=? AND min_usd=?').bind(data.hasNext?m.cursor:end,data.hasNext?end:null,data.hasNext?offset+100:0,staleWindow||m.cursor<to-86400?1:0,m.wallet_id,owner,m.cursor,m.started_at,m.min_usd));
    await db().batch(batch);
   }
  }catch(e){issues.push(e instanceof Error?e.message:'Swap history is unavailable.');}
  try{await observeWalletHoldings(m);}catch(e){issues.push('Balance snapshot: '+(e instanceof Error?e.message:'unavailable.'));}
  await db().prepare('UPDATE lens_wallet_monitors SET last_checked=?,error=? WHERE wallet_id=? AND user_id=? AND enabled=1 AND started_at=? AND min_usd=?').bind(iso,issues.length?issues.join(' '):null,m.wallet_id,owner,m.started_at,m.min_usd).run();
  await db().prepare('DELETE FROM lens_wallet_alerts WHERE user_id=? AND id NOT IN (SELECT id FROM lens_wallet_alerts WHERE user_id=? ORDER BY at DESC LIMIT 500)').bind(owner,owner).run();
  if(issues.length)failures.push(...issues);else checked++;
 }
 const detail=failures.length?[...new Set(failures)].join(' '):attempted?'Wallet checks saved.':'No wallet check is due or the hourly allowance is used.';
 if(scheduled)await db().prepare('UPDATE lens_background_state SET checked=?,error=?,last_success=CASE WHEN ?=1 THEN ? ELSE last_success END WHERE key=?').bind(checked,failures.length?detail:null,failures.length?0:1,iso,'wallets').run();
 return {checked,attempted,state:failures.length?'partial':attempted?'ok':'idle',detail};
 }catch(e){if(scheduled)await db().prepare('UPDATE lens_background_state SET error=? WHERE key=?').bind(e instanceof Error?e.message:'Background check failed.','wallets').run();throw e}
 finally{await releaseWalletLease(key,lease);}
}
export async function refreshWalletAlerts(user:string){const result=await runWalletMonitoring(user);return {...await walletFeed(user),...result};}
