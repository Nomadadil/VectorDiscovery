import {fetchJson} from './http';
import {readCache,writeCache} from './cache';
import {throttle} from './storage';
import {NETWORKS,validAddress,type Network} from './types';
import {normalizeNewPools,normalizeBasicCheck,type DiscoveryPage,type BasicCheck} from './discovery-types';
export async function discover(network:Network,page=1):Promise<DiscoveryPage>{
 if(!Object.hasOwn(NETWORKS,network)||!Number.isSafeInteger(page)||page<1||page>10)throw new Error('Choose a supported network and page.');
 const key=`discovery:v1:${network}:${page}`,cached=await readCache<DiscoveryPage>(key,90000);if(cached)return cached.data;
 await throttle('gecko-upstream',9);const raw=await fetchJson(`https://api.geckoterminal.com/api/v2/networks/${NETWORKS[network].gecko}/new_pools?include=base_token,quote_token&page=${page}`,{},9000);
 const result=normalizeNewPools(raw,network,page);await writeCache(key,result);return result;
}
export async function discoveryChecks(network:Network,addresses:unknown){
 if(!Object.hasOwn(NETWORKS,network)||!Array.isArray(addresses)||!addresses.length||addresses.length>20||addresses.some(a=>typeof a!=='string'||!validAddress(a,network)))throw new Error('Choose up to 20 valid token addresses.');
 const items:Record<string,BasicCheck>={};const queue=[...new Set(addresses as string[])];
 // GoPlus accepts one address on these endpoints even when given a comma-separated list.
 // Bound concurrency and share the upstream allowance with other checks.
 await Promise.all(Array.from({length:3},async()=>{while(queue.length){const address=queue.shift()!,key=`discovery-check:v1:${network}:${address}`;const cached=await readCache<BasicCheck>(key,180000);if(cached){items[address]=cached.data;continue}
 try{await throttle('goplus-upstream',25);const chain=network==='solana'?'solana/token_security':`token_security/${NETWORKS[network].chainId}`;const raw=await fetchJson(`https://api.gopluslabs.io/api/v1/${chain}?contract_addresses=${address}`,{},4000);items[address]=normalizeBasicCheck(raw,network,address);await writeCache(key,items[address])}catch{items[address]=normalizeBasicCheck(null,network,address)}}}));return {items};
}
