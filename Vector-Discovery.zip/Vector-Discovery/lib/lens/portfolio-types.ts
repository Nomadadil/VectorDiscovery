import type {Network} from './types';
export type PositionPnL={unrealized:number|null;percent:number|null;realized:number|null;total:number|null;totalPercent:number|null;averageBuy:number|null;holding:number|null};
export type WalletAsset={address:string;native:boolean;name:string;symbol:string;logo:string|null;balance:string;amount:string|null;price:number|null;value:number|null;pnl:PositionPnL|null};
export type WalletPortfolio={state:'ok'|'partial'|'stale'|'unavailable'|'unsupported';network:Network;wallet:string;at:string;totalValue:number|null;items:WalletAsset[];totalItems:number|null;offset:number;nextOffset:number|null;complete:boolean;pnlState:'ok'|'partial'|'unavailable'|'unsupported';pnlAt:string|null;detail:string;pnlDetail:string};

export function matchedPosition(asset:WalletAsset){const p=asset.pnl,n=asset.amount===null?null:Number(asset.amount);if(!p||p.holding===null||n===null||!Number.isFinite(n)||n<=0||asset.price===null)return null;return Math.abs(p.holding-n)<=Math.max(Number.MIN_VALUE,Math.abs(n)*1e-8)?p:null;}
