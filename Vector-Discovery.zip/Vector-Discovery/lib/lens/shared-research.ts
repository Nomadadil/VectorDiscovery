import {db,digest} from './storage';
import {readCache,writeCache} from './cache';
import {meter,researchContext,AllowanceError} from './economy';

// A D1 lease coordinates different Worker isolates, not just one process.
// Callers may only use this for public chain evidence, never personal lists.
export async function singleFlight<T>(key:string,read:()=>Promise<T|null>,work:()=>Promise<T>):Promise<T>{
 const cached=await read();if(cached!==null){await meter('cache');return cached;}
 if(!researchContext())return work();
 const hash=await digest(key),owner=crypto.randomUUID(),now=Date.now();
 const acquired=await db().prepare(`INSERT INTO lens_research_flights (key,owner,expires) VALUES (?,?,?)
 ON CONFLICT(key) DO UPDATE SET owner=excluded.owner,expires=excluded.expires WHERE expires<=?
 RETURNING owner`).bind(hash,owner,now+180000,now).first<{owner:string}>();
 if(acquired?.owner!==owner){
  await meter('shared');
  for(let i=0;i<12;i++){await new Promise(r=>setTimeout(r,500));const shared=await read();if(shared!==null)return shared;}
  throw new AllowanceError('RESEARCH_BUSY',new Date(Date.now()+5000).toISOString(),'This check is already in progress. Please try again in a few seconds.');
 }
 try{const newer=await read();if(newer!==null){await meter('cache');return newer;}return await work();}
 finally{await db().prepare('DELETE FROM lens_research_flights WHERE key=? AND owner=?').bind(hash,owner).run();}
}
export async function sharedResearch<T>(key:string,ttl:number,work:()=>Promise<T>,accept:(value:T)=>boolean=()=>true){
 const cache='shared-research:v1:'+await digest(key);
 return singleFlight(key,async()=>{const c=await readCache<T>(cache,ttl);return c?.data??null},async()=>{const v=await work();if(accept(v))await writeCache(cache,v);return v});
}
