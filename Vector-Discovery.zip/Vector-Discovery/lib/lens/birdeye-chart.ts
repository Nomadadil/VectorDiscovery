import {AllowanceError} from './allowance-error';
import {env} from 'cloudflare:workers';
import {readCache,writeCache} from './cache';
import {birdeyeRequest} from './birdeye-client';
import {num,sameAddress,type LensReport,type Network} from './types';
import type {Candle,ChartResult,Interval} from './chart';
const intervals={ '1m':['1m',60], '5m':['5m',300], '15m':['15m',900], '1h':['1H',3600], '4h':['4H',14400], '1d':['1D',86400]} as const;
export function normalizeBirdeyeCandles(raw:any,network:Network,address:string):Candle[]{
 if(raw?.success!==true||!Array.isArray(raw.data?.items))throw new Error('No candle series returned.');
 // Scaled UI tokens can use units inconsistent with the report's market-cap basis.
 if(raw.data.is_scaled_ui_token===true&&num(raw.data.multiplier)!==1)throw new Error('Chart token units could not be verified.');
 const seen=new Map<number,Candle>();
 for(const row of raw.data.items){
  if(!sameAddress(row.address||'',address,network)||row.currency&&row.currency!=='usd')throw new Error('Chart token orientation could not be verified.');
  const values=[row.unix_time,row.o,row.h,row.l,row.c,row.v_usd].map(num);if(values.some(v=>v===null))continue;
  const [time,open,high,low,close,volume]=values as number[];
  if(!Number.isInteger(time)||time<=0||time>Date.now()/1000+60||Math.min(open,high,low,close)<=0||volume<0||high<Math.max(open,close,low)||low>Math.min(open,close,high))continue;
  seen.set(time,{time,open,high,low,close,volume});
 }
 const candles=[...seen.values()].sort((a,b)=>a.time-b.time).slice(-240);if(!candles.length)throw new Error('No usable candles were returned for this interval.');return candles;
}
export function supportsBirdeyeChart(report:LensReport,requestedPool?:string){return !requestedPool&&!!env.BIRDEYE_API_KEY&&['solana','ethereum','bsc'].includes(report.network)}
const cacheKey=(r:LensReport,i:Interval)=>`birdeye:ohlcv:${r.network}:${r.address}:${i}:usd:v1`;
export async function cachedBirdeyeChart(r:LensReport,i:Interval,maxAge=300000){return (await readCache<ChartResult>(cacheKey(r,i),maxAge))?.data||null}
export async function birdeyeChart(r:LensReport,i:Interval):Promise<ChartResult>{
 const key=cacheKey(r,i);try{
  const [type,seconds]=intervals[i],end=Math.floor(Date.now()/1000),start=end-seconds*240;
  const raw=await birdeyeRequest(`/defi/v3/ohlcv?address=${encodeURIComponent(r.address)}&type=${type}&currency=usd&time_from=${start}&time_to=${end}&mode=range&padding=false`,{cost:40,chain:r.network});
  const result:ChartResult={state:'ok',detail:'Token-level USD candles from Birdeye. Not a single-pool execution price. Gaps are preserved; the last candle may still be open.',candles:normalizeBirdeyeCandles(raw,r.network,r.address),pools:[],pool:null,interval:i,fetchedAt:new Date().toISOString(),provider:'Birdeye',scope:'token',network:r.network,address:r.address};
  await writeCache(key,result);return result;
 }catch(e){const old=await readCache<ChartResult>(key,86400000);if(old)return {...old.data,state:'stale',...(e instanceof AllowanceError?{resetsAt:e.resetsAt,code:e.code}:{}),detail:'Showing an earlier saved chart. '+(e instanceof Error?e.message:'Provider unavailable.')};throw e}
}
