import {birdeyeCached} from './birdeye-client';
import {readCache,writeCache} from './cache';
import {db} from './storage';
import {normalizePerformance} from './performance';
import {REVIEW_MAX_AGE} from './wallet-assessment';
import {num,validAddress} from './types';
import type {WalletPerformance} from './wallet-types';
import type {WalletLeader,WalletLeaderboard} from './wallet-leader-types';
const WEEK=7*86400000;
export function normalizeLeaders(raw:any):Omit<WalletLeader,'rank'|'performance'>[]{
 if(raw?.success!==true||!Array.isArray(raw.data?.items))throw new Error('Wallet ranking was not returned.');const seen=new Set<string>();
 const rows= raw.data.items.slice(0,100).flatMap((r:any)=>{if(!validAddress(r.address||'','solana')||r.network!=='solana'||seen.has(r.address))return [];const realized=num(r.realized_pnl);if(realized===null||realized<1000)return [];seen.add(r.address);const count=num(r.trade_count),volume=num(r.volume);return [{address:r.address,network:'solana' as const,realized,unrealized:num(r.unrealized_pnl),total:num(r.pnl),volume:volume!==null&&volume>=0?volume:null,trades:count!==null&&Number.isSafeInteger(count)&&count>=0?count:null}]})
 .sort((a:any,b:any)=>b.realized-a.realized||a.address.localeCompare(b.address));if(raw.data.items.length&&!rows.length)throw new Error('Wallet ranking could not be verified.');return rows;
}
const perfKey=(wallet:string)=>`leader-performance-v1:solana:${wallet}:30d`;
export async function walletLeaders():Promise<WalletLeaderboard>{
 const base={state:'unavailable' as const,rows:[],at:null,detail:'',period:'30d' as const,minimumRealized:1000 as const,scope:'indexed-solana-wallets' as const};
 try{const result=await birdeyeCached('wallet-leaders-v1:solana:30d',12*3600000,'/trader/gainers-losers?type=30d&sort_by=realized_pnl&min_realized_pnl=1000&offset=0&limit=100',{cost:25,chain:'solana'},normalizeLeaders);
 const cached=await db().prepare('SELECT key,payload FROM lens_provider_cache WHERE key LIKE ? AND fetched_at>?').bind('leader-performance-v1:solana:%',Date.now()-WEEK).all<{key:string;payload:string}>();const map=new Map(cached.results.map(x=>[x.key,JSON.parse(x.payload) as WalletPerformance]));
 return {...base,state:'ok',at:result.at,rows:result.data.map((r,index)=>({...r,rank:index+1,performance:map.get(perfKey(r.address))||null}))};
 }catch(e){return {...base,detail:e instanceof Error?e.message:'Wallet ranking is unavailable.'}}
}
export async function acquireWalletLease(key:string,ms=90000){const now=Date.now(),token=crypto.getRandomValues(new Uint32Array(1))[0];const row=await db().prepare('INSERT INTO lens_rate_limits (key,window,count) VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET window=excluded.window,count=excluded.count WHERE window<? RETURNING count').bind(key,now+ms,token,now).first<{count:number}>();return row?.count===token?token:null}
export async function releaseWalletLease(key:string,token:number){await db().prepare('UPDATE lens_rate_limits SET window=0 WHERE key=? AND count=?').bind(key,token).run()}
export async function enrichWalletLeaders(){const key='wallet-leaders-enrichment',lease=await acquireWalletLease(key,180000);if(lease===null)return {state:'busy',detail:'Another results check is in progress.',board:await walletLeaders()};
 try{let board=await walletLeaders();if(board.state!=='ok')return {state:'unavailable',detail:board.detail,board};const missing=board.rows.filter(x=>!x.performance||Date.now()-Date.parse(x.performance.fetchedAt)>REVIEW_MAX_AGE);let count=0,attempted=0;const failures:string[]=[];
 for(const row of missing){
 if(attempted>=5)break;if(await readCache('leader-pnl-failure:'+row.address,3600000))continue;attempted++;try{
 const result=await birdeyeCached('leader-pnl-request:'+row.address, REVIEW_MAX_AGE,`/wallet/v2/pnl/summary?wallet=${row.address}&duration=30d&position_scope=duration_only&pnl_method=wac`,{cost:20,chain:'solana'},normalizePerformance);
 const p:WalletPerformance={...result.data,state:'ok',detail:'Thirty-day WAC results at the displayed check time. Fully realized token outcomes, not individual trade wins.',network:'solana',wallet:row.address,window:'30d',method:'wac',scope:'duration_only',source:'Birdeye',fetchedAt:result.at};await writeCache(perfKey(row.address),p);count++;}catch(e){const detail=e instanceof Error?e.message:'Wallet results are unavailable.';await writeCache('leader-pnl-failure:'+row.address,{detail});failures.push(detail)}
 }
 board=await walletLeaders();const remaining=board.rows.filter(x=>!x.performance||Date.now()-Date.parse(x.performance.fetchedAt)>REVIEW_MAX_AGE).length;return {state:attempted===0&&remaining?'unavailable':'ok',detail:attempted===0&&remaining?'Some wallet results are unavailable. Retry in one hour.':failures[0]||'',checked:count,remaining,board};
 }catch(e){return {state:'unavailable',detail:e instanceof Error?e.message:'Wallet results are unavailable.',board:await walletLeaders()}}finally{await releaseWalletLease(key,lease)}
}
