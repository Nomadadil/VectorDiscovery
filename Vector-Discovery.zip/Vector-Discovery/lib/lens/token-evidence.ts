import type {LensReport} from './types';
// Empty promotion orders and generic contract/explorer responses cannot identify a token.
export function hasTokenEvidence(r:LensReport){return r.mode==='demo'||r.market.pools.length>0||r.token.name!=='Token'||r.token.symbol!=='TOKEN'||r.token.decimals!==null||r.sources.some(s=>['goplus','rugcheck'].includes(s.id)&&s.state==='ok');}
