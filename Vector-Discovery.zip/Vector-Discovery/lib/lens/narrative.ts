import type {LensReport} from './types';
export type NarrativeTheme='meme'|'ai'|'gaming'|'rwa'|'defi'|'infrastructure';
const themes:[NarrativeTheme,RegExp][]=[['meme',/\b(meme(?:coin)?s?|dogecoin|pepe)\b|мем(?:коин)?/i],['ai',/\b(artificial intelligence|AI agents?|machine learning)\b|искусственн(?:ый|ого) интеллект/i],['gaming',/\b(gaming|video games?|gamefi|metaverse)\b|игров|метавселен/i],['rwa',/\b(real.world assets?|tokenized (assets?|stocks?|treasur(?:y|ies)))\b|токенизир|реальн.{0,8}актив/i],['defi',/\b(defi|decentralized finance|lending|decentralized exchange|liquid staking)\b|децентрализованн.{0,12}финанс/i],['infrastructure',/\b(layer.?[12]|rollup|blockchain infrastructure|oracle|interoperability)\b|инфраструктур|оракул/i]];
export function tokenNarrative(r:LensReport){
 const description=r.context?.description||'',categories=r.context?.categories||[];const source=[...categories,description].join(' ');
 // Project text and categories only. Never infer identity or topic from a ticker/address.
 const tags=themes.filter(([key,pattern])=>key==='meme'&&r.context?.category==='meme'||pattern.test(source)).map(([key])=>key);
 const p=r.advanced?.periods?.h24;const buys=p?.buys??null,sells=p?.sells??null,total=buys!==null&&sells!==null?buys+sells:null;
 return {tags,hasDescription:!!description,hasLinks:!!r.context?.links.length,change:p?.change??null,volume:p?.volume??r.market.volume24h??null,buys,sells,buyShare:total!==null&&total>0?100*buys!/total:null,at:r.context?.fetchedAt||r.generatedAt};
}
