import {guestBudget} from '@/lib/lens/guest-budget';
import {withResearchContext,featureFor,reserveFreshScan,AllowanceError,allowanceStatus,actorAllowanceStatus,meter,researchContext} from '@/lib/lens/economy';
import {sharedResearch} from '@/lib/lens/shared-research';
import {backgroundAuthorized,backgroundEnabled} from '@/lib/lens/background-access';
import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '@/app/chatgpt-auth';
import {parseInput,NETWORKS,validAddress,type Network} from '@/lib/lens/types';
import {dashboard,rememberReport} from '@/lib/lens/dashboard';
import {socialFeed} from '@/lib/lens/social';
import {scan,retrySection,RETRY_SECTIONS} from '@/lib/lens/scanner';
import {hasTokenEvidence,exactPair,resolveMissing} from '@/lib/lens/lookup';
import {chart,type Interval} from '@/lib/lens/chart';
import {swaps,listWallets,followWallet,unfollowWallet} from '@/lib/lens/wallets';
import {walletTokenTrades} from '@/lib/lens/wallet-token-trades';
import {discover,discoveryChecks} from '@/lib/lens/discovery';
import {getSignals} from '@/lib/lens/signals';
import {signalFeed,subscribeSignals,markSignalsRead} from '@/lib/lens/signals-storage';
import {signalChart} from '@/lib/lens/signals-chart';
import {walletHistory} from '@/lib/lens/wallet-history';
import {walletPortfolio} from '@/lib/lens/portfolio';
import {performance} from '@/lib/lens/performance';
import {walletLeaders,enrichWalletLeaders} from '@/lib/lens/wallet-leaders';
import {walletFeed,setWalletMonitor,markWalletAlertsRead,refreshWalletAlerts,runWalletMonitoring,backgroundStatus} from '@/lib/lens/wallet-alerts';
import {quote} from '@/lib/lens/quote';
import {fetchJson} from '@/lib/lens/http';
import {getReport,storeReport,cachedReport,throttle,listWatch,addWatch,updateWatch,compareReports,recordWatch,digest} from '@/lib/lens/storage';
export const dynamic='force-dynamic';
const json=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
function error(e:unknown,status=400){return e instanceof AllowanceError?json({error:e.message,code:e.code,resetsAt:e.resetsAt},429):json({error:e instanceof Error?e.message:'The request could not be completed.'},status)}
async function body(req:Request){if(Number(req.headers.get('content-length')||0)>4096)throw new Error('Request is too large.');const s=await req.text();if(s.length>4096)throw new Error('Request is too large.');return JSON.parse(s)}
function origin(req:Request){const o=req.headers.get('origin');if(o&&o!==new URL(req.url).origin)throw new Error('Cross-origin writes are not allowed.');if(req.headers.get('sec-fetch-site')==='cross-site')throw new Error('Cross-site request rejected.');}
async function identity(){const u=await getChatGPTUser();if(!u)throw new Error('Sign in to save and monitor your Watch list.');return u.userId;}
async function handleGET(req:Request){try{
 const u=new URL(req.url),p=u.pathname.split('/').pop();
 if(p==='allowance')return json(await actorAllowanceStatus(researchContext()!.actor));
 if(p==='usage'){const user=await getChatGPTUser();if(!user)return json({error:'Sign in to view research allowances.'},401);await throttle('usage-'+await digest(user.userId),12);return json(await allowanceStatus(user.userId));}
 if(p==='background-status')return json(await backgroundStatus());
 if(p==='config'){const account=await getChatGPTUser();return json({providers:{goplus:true,honeypot:true,dexscreener:true,rugcheck:true,bubblemaps:!!env.BUBBLEMAPS_API_KEY,bitquery:!!env.BITQUERY_ACCESS_TOKEN,tokensniffer:!!env.TOKENSNIFFER_API_KEY,jupiter:true,kyberswap:true,birdeye:!!env.BIRDEYE_API_KEY},watch:{mode:'while_open',intervalSeconds:120,background:false},signedIn:!!account,account:account?{name:account.displayName||account.fullName||'',email:account.email}:null});}
 if(p==='dashboard'){const user=await getChatGPTUser();if(!user)return json({error:'Sign in to see your dashboard.'},401);return json(await dashboard(user.userId));}
 if(p==='wallet-leaders'){await throttle('wallet-leaders-read',30);return json(await walletLeaders());}
 if(p==='wallet-alerts'){const user=await getChatGPTUser();if(!user)return json({error:'Sign in to follow wallets.'},401);return json(await walletFeed(user.userId));}
 if(p==='signals-feed'){const user=await getChatGPTUser();if(!user)return json({error:'Sign in to save signal notifications.'},401);return json(await signalFeed(user.userId));}
 if(p==='report'){const r=await getReport(u.searchParams.get('id')||'');return r?json(r):json({error:'This report could not be found.'},404);}
 if(p==='wallets'){const user=await getChatGPTUser();if(!user)return json({error:'Sign in to follow wallets.'},401);return json({items:await listWallets(user.userId)});}
 if(p==='watch'){const user=await getChatGPTUser();if(!user)return json({error:'Sign in to save and monitor your Watch list.',signIn:'/signin-with-chatgpt?return_to=/'},401);return json(await listWatch(user.userId));}
 return json({error:'Not found'},404);
 }catch(e){return error(e,503)}}
async function handlePOST(req:Request){try{
 origin(req);const p=new URL(req.url).pathname.split('/').pop();const b=await body(req);
 if(b&&Object.hasOwn(b,'network')&&!Object.hasOwn(NETWORKS,b.network))throw new Error('Vector Discovery supports Ethereum, BNB Chain and Solana.');
 // Dedicated service authorization remains required if the Site becomes public.
 // Visitor identity and Sites' outer access token do not authorize this writer.
 if(p==='background-run'){
  if(!backgroundEnabled())return json({error:'Background monitoring is paused.',code:'BACKGROUND_PAUSED'},503);
  if(!await backgroundAuthorized(req))return json({error:'Service authorization required.'},401);
  if(!b||Array.isArray(b)||typeof b!=='object'||Object.keys(b).length)throw new Error('An empty request is required.');
  return json(await runWalletMonitoring());
 }
 if(p==='wallet-leaders-enrich'){await identity();await throttle('wallet-leaders-enrich',12);return json(await enrichWalletLeaders());}
 if(p==='scan'){
  const parsed=parseInput(String(b.input||''),b.network as Network);let {network,address}=parsed;
  await throttle('scans-global',45);const user=await getChatGPTUser();if(user)await throttle('scan-'+await digest(user.userId),15);
  if(parsed.pair){const j=await fetchJson(`https://api.dexscreener.com/latest/dex/pairs/${NETWORKS[network].dex}/${address}`);const pair=exactPair(j,network,address);if(!pair||!validAddress(pair.baseToken?.address,network))throw new Error('This pair could not be resolved to a token on the selected network.');address=network==='solana'?pair.baseToken.address:pair.baseToken.address.toLowerCase();}
  const existing=b.deep?null:await cachedReport(network,address);if(existing?.sources.some(s=>s.id==='token-context')&&existing.market.pools.length){await meter('cache');if(user)await rememberReport(user.userId,existing);return json({report:existing,cached:true});}
  const execute=async(onProgress?:NonNullable<Parameters<typeof scan>[2]>['onProgress'])=>{
   try{
    const result=await sharedResearch('scan:'+network+':'+address+':'+(b.deep===true),b.deep===true?600000:180000,async()=>{
     await reserveFreshScan();
     const report=existing?.sources.some(s=>s.id==='token-context')&&hasTokenEvidence(existing)?existing:await scan(network,address,{deep:b.deep===true,onProgress});
     if(!report.market.pools.length){
      if(researchContext()?.blocked&&!hasTokenEvidence(report))throw researchContext()?.allowance||new AllowanceError('RESEARCH_LIMIT',new Date(Date.now()+60000).toISOString(),'Data refresh is limited. Saved results remain available.');
      const lookup=await resolveMissing(report);if(!hasTokenEvidence(report)||lookup.state==='choose_pool_token')return {error:lookup.detail,lookup};
     }
     if(report===existing)return {report,cached:true};
     const hash=await storeReport(report);return {report,digest:hash,cached:false};
    },v=>!!v.report&&!researchContext()?.blocked);
    if(user&&result.report)await rememberReport(user.userId,result.report);
    return result;
   }catch(e){
    if(e instanceof AllowanceError){const saved=await cachedReport(network,address,86400000);if(saved&&hasTokenEvidence(saved)){if(user)await rememberReport(user.userId,saved);return {report:saved,cached:true,note:'Showing a saved snapshot. '+e.message,code:e.code,resetsAt:e.resetsAt};}}
    throw e;
   }
  };
  if(b.stream===true){
   let cancelled=false;const encoder=new TextEncoder();
   const stream=new ReadableStream({async start(controller){
    const send=(value:unknown)=>{if(!cancelled)controller.enqueue(encoder.encode(JSON.stringify(value)+'\n'));};
    try{send({type:'progress',stage:'identity'});const result=await execute(async(stage,report)=>{send({type:'progress',stage,report})});send({...result,type:'error' in result?'error':'complete'});}
    catch(e){send({type:'error',error:e instanceof Error?e.message:'Token check failed.',...(e instanceof AllowanceError?{code:e.code,resetsAt:e.resetsAt}:{})});}
    finally{if(!cancelled)controller.close();}
   },cancel(){cancelled=true;}});
   return new Response(stream,{headers:{'Content-Type':'application/x-ndjson','Cache-Control':'no-store, no-transform','X-Content-Type-Options':'nosniff'}});
  }
  const result=await execute();return json(result,'error' in result?422:200);
 }
 if(p==='retry-check'){
  await throttle('section-retry-global',30);const user=await getChatGPTUser();if(user)await throttle('section-retry-'+await digest(user.userId),10);
  const stored=await getReport(String(b.reportId||''));if(!stored)throw new Error('Inspect the token first.');
  if(!RETRY_SECTIONS.includes(b.section))throw new Error('Choose a supported report section.');
  let result;try{result=await sharedResearch('retry:'+stored.report.id+':'+b.section,b.section==='research'?600000:180000,async()=>{await reserveFreshScan();const report=await retrySection(stored.report,b.section),limit=researchContext()?.allowance;if(limit&&(b.section!=='research'||stored.report.intelligence||stored.report.recentHolders||stored.report.holders.links.length))throw limit;return {report,digest:await storeReport(report),...(limit?{note:'Some checks reached the refresh limit. '+limit.message,code:limit.code,resetsAt:limit.resetsAt}:{})}},()=>!researchContext()?.blocked);}catch(e){if(e instanceof AllowanceError)return json({report:stored.report,cached:true,note:'Showing a saved snapshot. '+e.message,code:e.code,resetsAt:e.resetsAt});throw e;}if(user)await rememberReport(user.userId,result.report);
  return json(result);
 }
 if(p==='discovery'){await throttle('discovery-read',30);return json(await discover(b.network,b.page===undefined?1:Number(b.page)));}
 if(p==='signals'){
  const age=b.maxAgeMinutes===undefined?120:Number(b.maxAgeMinutes);if(age!==60&&age!==120)throw new Error('Choose a 1-hour or 2-hour pool window.');
  await throttle('signals-read',45);return json(await getSignals(b.network,age));
 }
 if(p==='signals-chart'){
  await throttle('signals-chart-read',30);
  return json(await signalChart(b.network,String(b.address||''),String(b.pool||''),b.interval||'5m'));
 }
 if(p==='discovery-checks'){await throttle('discovery-check-requests',10);return json(await discoveryChecks(b.network,b.addresses));}
 if(p==='wallet-history'){const user=await identity();await throttle('history-user-'+await digest(user),6);await throttle('history-global',15);return json(await walletHistory(b.network,String(b.address||''),b.duration||'30d',b.offset===undefined?0:Number(b.offset)));}
 if(p==='social'){await identity();await throttle('social-requests',12);const stored=await getReport(String(b.reportId||''));if(!stored)throw new Error('Inspect the token first.');if(!['contract','project'].includes(b.scope))throw new Error('Choose a supported feed.');return json(await socialFeed(stored.report,b.scope));}
 if(p==='chart'){await throttle('chart-requests',60);const stored=await getReport(String(b.reportId||''));if(!stored)throw new Error('Inspect the token first.');return json(await sharedResearch('chart:'+stored.report.network+':'+stored.report.address+':'+String(b.interval)+':'+String(b.pool||'')+':'+(b.extended===true),60000,()=>chart(stored.report,b.interval as Interval,typeof b.pool==='string'?b.pool:undefined,b.extended===true),r=>r.state==='ok'));}
 if(p==='swaps'){await throttle('swap-requests',45);const stored=await getReport(String(b.reportId||''));if(!stored)throw new Error('Inspect the token first.');return json(await swaps(stored.report,typeof b.pool==='string'?b.pool:undefined));}
 if(p==='wallet-token-trades'){const user=await identity();await throttle('wallet-chart-user-'+await digest(user),12);await throttle('wallet-chart-global',30);const stored=await getReport(String(b.reportId||''));if(!stored)throw new Error('Inspect the token first.');return json(await walletTokenTrades(stored.report,String(b.wallet||''),b.offset===undefined?0:Number(b.offset),b.before===undefined?undefined:Number(b.before)));}
 if(p==='wallet-portfolio'){const user=await identity();await throttle('portfolio-user-'+await digest(user),8);await throttle('portfolio-global',20);return json(await walletPortfolio(b.network,String(b.address||''),b.offset===undefined?0:Number(b.offset)));}
 if(p==='wallet-performance'){const user=await identity();await throttle('pnl-user-'+await digest(user),3);await throttle('pnl-requests',20);return json(await performance(b.network,String(b.address||'')));}
 if(p==='quote'){await throttle('quotes-global',30);const stored=await getReport(String(b.reportId||''));if(!stored)throw new Error('Inspect the token first.');if(Date.now()-Date.parse(stored.report.generatedAt)>10*60*1000)throw new Error('Refresh this report before requesting a position-size quote.');return json(await quote(stored.report,String(b.amount||'')));}
 const user=await identity();await throttle('watch-'+await digest(user),20);
 if(p==='signals-subscribe')return json(await subscribeSignals(user,b.networks,b.enabled));
 if(p==='signals-read')return json(await markSignalsRead(user));
 if(p==='wallet-monitor')return json(await setWalletMonitor(user,String(b.id||''),b.enabled,Number(b.minUsd)));
 if(p==='wallet-alerts-read')return json(await markWalletAlertsRead(user,Array.isArray(b.ids)?b.ids:[],b.all===true));
 if(p==='wallet-alerts-refresh')return json(await refreshWalletAlerts(user));
 if(p==='wallet-follow')return json({items:await followWallet(user,b.network,String(b.address||''),String(b.label||''))});
 if(p==='wallet-unfollow')return json({items:await unfollowWallet(user,String(b.id||''))});
 if(p==='watch-add'){const stored=await getReport(String(b.reportId||''));if(!stored)throw new Error('Inspect a token first.');await addWatch(user,stored.report);return json(await listWatch(user));}
 if(p==='watch-update'){const threshold=Number(b.threshold);if(!Number.isFinite(threshold)||threshold<1||threshold>100)throw new Error('Choose a liquidity threshold between 1% and 100%.');if(typeof b.paused!=='boolean')throw new Error('Pause state is invalid.');await updateWatch(user,String(b.id||''),b.paused,threshold);return json(await listWatch(user));}
 if(p==='watch-refresh'){
  const {items}=await listWatch(user);let list=items.filter(i=>!i.paused&&Date.now()-Date.parse(i.checkedAt)>60000);if(b.id)list=list.filter(i=>i.id===b.id);list=list.sort((a,b)=>Date.parse(a.checkedAt)-Date.parse(b.checkedAt)).slice(0,3);
  let checked=0;await Promise.all(list.map(async item=>{await throttle('scans-global',45);const old=await getReport(item.reportId);if(!old)return;let next=await cachedReport(item.network,item.address);if(!next){const result=await sharedResearch('scan:'+item.network+':'+item.address+':false',180000,async()=>{await reserveFreshScan();const report=await scan(item.network,item.address);return {report,digest:await storeReport(report),cached:false};});next=result.report;}await recordWatch(user,item,next,compareReports(old.report,next,item.threshold));checked++;}));
  return json({...await listWatch(user),checked,note:checked?'Watch checks completed.':'No check is due yet. Active items refresh after one minute.'});
 }
 return json({error:'Not found'},404);
 }catch(e){const message=e instanceof Error?e.message:'';return error(e,message.startsWith('Sign in')?401:message.includes('Too many')?429:400)}}

async function inContext(req:Request,handler:(r:Request)=>Promise<Response>){
 try{if(req.method==='POST')origin(req);
 const account=await getChatGPTUser(),guest=account?null:await guestBudget(req),actor=account?await digest(account.userId):guest!.actor;
 const response=await withResearchContext(actor,featureFor(new URL(req.url).pathname.split('/').pop()||''),()=>handler(req));
 if(!guest?.cookie)return response;
 const headers=new Headers(response.headers);headers.append('Set-Cookie',guest.cookie);
 return new Response(response.body,{status:response.status,headers});
 }catch(e){return error(e,503)}
}
export const GET=(req:Request)=>inContext(req,handleGET);
export const POST=(req:Request)=>inContext(req,handlePOST);
