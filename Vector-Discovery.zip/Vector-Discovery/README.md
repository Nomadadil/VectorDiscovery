# Vector Discovery

A separate, mobile-first research product for Vector. It helps a visitor discover pools, inspect a token, understand the limits of available data, follow wallets, and then open the Vector terminal.

**Networks:** Ethereum, BNB Smart Chain and Solana only. **Languages:** English and Russian.

**Terminal:** https://t.me/vectordexbot?startapp=5b847c41

The terminal button opens that exact destination. It does not submit an order or automatically preload the currently inspected token. Vector Discovery never asks for a wallet seed phrase and does not execute trades.

## Included

- Contract lookup with explicit network selection and recovery for mismatched networks.
- New-pool discovery: time window, network, liquidity and valuation filters, plus available basic risk checks. The result is a bounded pool sample; pool age is not a token launch date.
- Token overview, conditional risk assessment, price/capitalization chart, selling checks, holders, creator, liquidity, activity, community context and shareable report.
- Wallet research, current positions, trading history and watch/event views where connected data supports them. Historical PnL and wallet ranking depend on optional data access.
- Mobile navigation, account-specific saved items, English/Russian labels, responsive desktop layout and reduced-motion support.
- Vector branding and a direct path into the Vector terminal.

## Run locally

Use Node 22.13 or later. Install dependencies with the Sites plugin's dependency installer when available, or the repository's `npm run install:ci` helper. Then:

```sh
npm run dev
```

Local preview uses the supplied Sites/Vinext integration. Development sign-in is for local testing only. Production uses the hosting identity gateway; arbitrary visitor headers must never be accepted as identity.

## Validation and publication

```sh
npm test
npx tsc --noEmit
npm run build
```

Publish through the Sites workflow using this checkout's own `.openai/hosting.json`. It belongs to a new, separate Site. The source product's Site, database, accounts, private history, credentials and runtime caches are not part of this fork. New deployment is private until the owner intentionally changes access.

`HANDOFF.md` records operating boundaries. `PROVIDER-SETUP.txt` explains optional integrations. `.env.example` contains variable names only; credentials belong in the server environment.

## Data limits

Missing checks stay unknown. A low observed risk score is not a guarantee that a token is sellable or that a trade will be profitable. Market capitalization can be an estimate; wallet valuation is not the amount that can necessarily be cashed out. Maps and holdings may cover only a sample. Community links do not establish public sentiment.

No paid subscriptions, provider keys, background monitoring schedule or automatic transaction execution are enabled by copying this project. Public providers have quotas and may be unavailable. Chart fallback and deeper research can require a separately connected account.

## Delivery snapshot · 12 October 2026

This export is based on source commit `fabc9e419126c2d89082b3866873dd75c7b16725`.
The original Git history, runtime database, user records, cache and credentials are not included.
Documentation in this copy has been expanded for handoff; application code is unchanged.

**Signals is included:** a separate Solana fresh-pool shortlist, Ethereum/BNB trending lists,
strict evidence gates, expiry, account subscriptions and an in-app notification feed.
See `HANDOFF.md` and `docs/INTEGRATIONS-AND-METRICS.md` for exact rules and coverage.

**Hosted state is different from a source export.** The existing private Sites deployment
has a separate hourly free-source Signals schedule. That external schedule is not created
by cloning this repository. Its creation and direct endpoint execution were checked;
the first scheduled occurrence was not observed during the handoff audit. Paid wallet
background monitoring remains paused. Optional provider credentials were absent from
the deployed environment at this audit (`keys: []`).

## GitHub and Netlify

The source is ready to store in a **private GitHub repository**. Keep `.env.example` blank;
never commit real API keys, local databases or runtime folders.

**This is not a Netlify Drop package.** It currently depends on a Cloudflare Worker runtime,
D1/SQLite and the Sites verified-identity gateway. Uploading only `dist/client` would omit
the API, authentication, saved items, quotas and notifications. Netlify requires a runtime,
database and authentication migration before a working public deployment can be claimed.
Do not trust visitor-supplied `oai-authenticated-user-*` headers outside the existing gateway.

Delivery documents:

- `docs/INTEGRATIONS-AND-METRICS.md` — integration register, metrics and Signals rules.
- `docs/ENGINEERING-AND-ESTIMATE.md` — scope, engineering effort and cost scenarios.
- `docs/UPLOAD-GUIDE-RU.txt` — GitHub upload and staged Netlify migration instructions.

Third-party notices and font/chart licenses are retained. This export does not assign
ownership of third-party code or grant an open-source license for the entire product.
