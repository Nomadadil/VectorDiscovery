"""Live read-only public asset probes against a running LOCAL preview; never run against production."""
import json, urllib.request, os
origin='http://127.0.0.1:5194'
def post(path,body):
 req=urllib.request.Request(origin+'/api/lens/'+path,data=json.dumps(body).encode(),headers={'Content-Type':'application/json','Origin':origin})
 with urllib.request.urlopen(req,timeout=100) as r:return json.load(r)
cases=[('bsc','0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c','WBNB'),('ethereum','0x6982508145454Ce325dDbE47a25d4ec3d2311933','PEPE'),('solana','JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN','JUP')]
os.makedirs('/private/tmp/tom-lens-v2-live',exist_ok=True)
for network,address,symbol in cases:
 report=post('scan',{'network':network,'input':address})['report']
 assert report['token']['symbol'].upper()==symbol,(symbol,report['token'])
 chart=post('chart',{'reportId':report['id'],'interval':'1h'})
 json.dump({'report':report,'chart':chart},open('/private/tmp/tom-lens-v2-live/'+symbol+'.json','w'))
 assert chart['state']=='ok',(symbol,chart['detail'])
 assert len(chart['candles'])>10
 assert all(a['time']<b['time'] for a,b in zip(chart['candles'],chart['candles'][1:]))
 if symbol=='AERO':
  provenance=report['advanced']['explorer'];assert provenance['createdAt'].startswith('2023-08-28');assert provenance['verification']=='Partially verified'
 if symbol=='JUP':
  assert next(f['signal'] for f in report['facts'] if f['id']=='rug-mintAuthority') is False
  assert any(x['percent'] is None for x in report['advanced']['poolLocks'])
 print('PASS',symbol,report['id'],len(chart['candles']),'candles',len(report['facts']),'facts',len(report['holders']['items']),'holders',flush=True)
