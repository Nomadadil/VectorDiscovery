"""Local-only API smoke: no real trades, synthetic dev identities only."""
import json, urllib.request, urllib.error, sys, http.cookiejar
jar=http.cookiejar.CookieJar()
auth=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
base='http://127.0.0.1:5194'
def req(path,body=None,user=None,origin=None):
 headers={'Content-Type':'application/json'}
 if user: headers.update({'oai-authenticated-user-id':user,'oai-authenticated-user-email':user+'@example.invalid'})
 if origin: headers['Origin']=origin
 request=urllib.request.Request(base+'/api/lens/'+path,headers=headers,data=None if body is None else json.dumps(body).encode())
 try:
  with (auth.open(request,timeout=60) if user=='lens-local-qa-a' else urllib.request.urlopen(request,timeout=60)) as r:return r.status,json.load(r)
 except urllib.error.HTTPError as e:
  raw=e.read().decode()
  try: data=json.loads(raw)
  except ValueError: data={'error':raw[:200]}
  return e.code,data
assert req('watch')[0]==401
assert req('scan',{'input':'https://127.0.0.1/private','network':'ethereum'})[0]==400
assert req('scan',{'input':'0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2','network':'ethereum'},origin='https://other.invalid')[0] in (400,403)
status,j=req('scan',{'input':'0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2','network':'ethereum'})
assert status==200,j
report=j['report'];rid=report['id'];assert report['mode']=='live'
assert report['coverage']['available']>0,report['sources']
status,snapshot=req('report?id='+rid);assert status==200 and snapshot['report']==report and len(snapshot['digest'])==64
auth.open(base+'/signin-with-chatgpt?return_to=/',timeout=30).close()
status,data=req('watch-add',{'reportId':rid},'lens-local-qa-a');assert status==200,data
item=next(x for x in data['items'] if x['reportId']==rid or x['address']==report['address'])
assert req('watch-update',{'id':item['id'],'paused':True,'threshold':25},'lens-local-qa-b')[0]==401
status,data=req('watch-update',{'id':item['id'],'paused':True,'threshold':25},'lens-local-qa-a');assert status==200
assert next(x for x in req('watch',user='lens-local-qa-a')[1]['items'] if x['id']==item['id'])['paused']
assert req('watch',user='lens-local-qa-b')[0]==401
status,q=req('quote',{'reportId':rid,'amount':'1'});assert status==200 and q['state'] in ['not_configured','unavailable']
print(json.dumps({'checks':'auth, input, origin, live scan, immutable snapshot, watch persistence, spoofed identity rejection, quote access','reportId':rid,'coverage':report['coverage'],'sources':[{k:s[k] for k in ['id','state','detail']} for s in report['sources']]},indent=2))
