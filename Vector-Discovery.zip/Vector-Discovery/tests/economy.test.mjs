import {DatabaseSync} from 'node:sqlite';
import {build} from 'esbuild';
import {mkdtemp,readFile,readdir,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const sql=new DatabaseSync(':memory:');
for(const f of (await readdir('drizzle')).filter(f=>f.endsWith('.sql')).sort())sql.exec(await readFile('drizzle/'+f,'utf8'));
const shim={prepare(query){return {bind(...v){return {first:async()=>sql.prepare(query).get(...v)??null,all:async()=>({results:sql.prepare(query).all(...v)}),run:async()=>({meta:{changes:Number(sql.prepare(query).run(...v).changes)}}),runSync:()=>sql.prepare(query).run(...v)}}}},async batch(stmts){sql.exec('BEGIN');try{const out=stmts.map(s=>({meta:{changes:Number(s.runSync().changes)}}));sql.exec('COMMIT');return out}catch(e){sql.exec('ROLLBACK');throw e}}};
globalThis.__economyDb=shim;globalThis.__economyEnv={DB:shim,BIRDEYE_API_KEY:'fixture-only'};globalThis.__economyUser={userId:'alice'};
const dir=await mkdtemp(join(tmpdir(),'lens-economy-'));const originalFetch=globalThis.fetch;let calls=0,response={success:true,data:{value:1}};
globalThis.fetch=async()=>{calls++;return Response.json(response)};
try{
 const out=join(dir,'test.mjs');await build({stdin:{contents:"export * from './lib/lens/economy';export * from './lib/lens/guest-budget';export {scan,retrySection} from './lib/lens/scanner';export * from './lib/lens/shared-research';export * from './lib/lens/birdeye-client';export * from './lib/lens/cache';export * from './lib/lens/storage';export * from './lib/lens/http';export * from './lib/lens/portfolio';export {GET,POST} from './app/api/lens/[...path]/route';",resolveDir:process.cwd()},outfile:out,bundle:true,platform:'node',format:'esm',logLevel:'silent',plugins:[{name:'fixtures',setup(b){b.onResolve({filter:/^cloudflare:workers$/},()=>({path:'env',namespace:'test'}));b.onResolve({filter:/chatgpt-auth$/},()=>({path:'auth',namespace:'test'}));b.onLoad({filter:/.*/,namespace:'test'},a=>({loader:'js',contents:a.path==='env'?"export const env=globalThis.__economyEnv;":"export const getChatGPTUser=async()=>globalThis.__economyUser;"}));}}]});
 const m=await import(pathToFileURL(out).href),day=m.dayWindow(),month=new Date().getUTCFullYear()*12+new Date().getUTCMonth();
 // Public launch boundary: no visitor can invoke the global background writer.
 const background=secret=>m.POST(new Request('https://test.invalid/api/lens/background-run',{method:'POST',headers:{'Content-Type':'application/json',...(secret?{'x-vector-monitor-secret':secret}:{})},body:'{}'}));
 assert.equal((await background()).status,503);
 globalThis.__economyEnv.LENS_BACKGROUND_ENABLED='true';
 assert.equal((await background()).status,503,'missing service secret fails closed');
 globalThis.__economyEnv.LENS_MONITOR_SECRET='test-monitor-secret-with-at-least-32-characters';
 for(const user of [null,{userId:'alice'}]){globalThis.__economyUser=user;assert.equal((await background()).status,401);assert.equal((await background('wrong-secret')).status,401);}
 assert.equal(calls,0);assert.equal(sql.prepare('SELECT COUNT(*) n FROM lens_background_state').get().n,0);
 const allowed=await background(globalThis.__economyEnv.LENS_MONITOR_SECRET);assert.equal(allowed.status,200);assert.equal((await allowed.json()).attempted,0);
 globalThis.__economyEnv.LENS_BACKGROUND_ENABLED='false';
 const paused=await m.GET(new Request('https://test.invalid/api/lens/background-status'));const state=await paused.json();assert.equal(state.enabled,false);assert.equal(state.healthy,false,'old healthy heartbeat cannot override paused configuration');
 delete globalThis.__economyEnv.LENS_MONITOR_SECRET;delete globalThis.__economyEnv.LENS_BACKGROUND_ENABLED;globalThis.__economyUser={userId:'alice'};
 console.log('PASS public background writer fails closed, rejects visitors and signed-in users without service secret, and paused status ignores old heartbeat');
 const count=key=>sql.prepare('SELECT count FROM lens_rate_limits WHERE key=?').get(key)?.count||0;
 const put=(key,n,window=day)=>sql.prepare('INSERT OR REPLACE INTO lens_rate_limits (key,window,count) VALUES (?,?,?)').run(key,window,n);
 const clear=()=>{sql.exec('DELETE FROM lens_rate_limits; DELETE FROM lens_usage; DELETE FROM lens_provider_cache; DELETE FROM lens_research_flights;');calls=0};
 const actor=await m.digest('alice'),run=work=>m.withResearchContext(actor,'scan',work);
 const admitted=await Promise.all(Array.from({length:50},()=>m.reserve('race',day,10,200)));assert.equal(admitted.filter(Boolean).length,20);assert.equal(count('race'),200);assert.equal(await m.reserve('race',day+1,10,200),true);assert.equal(count('race'),10);
 for(const [key,limit,code,fn] of [['economy-cu:'+actor,200,'PERSONAL_RESEARCH_LIMIT',()=>m.reserveDailyCU(1)],['economy-cu:global',800,'DAILY_RESEARCH_LIMIT',()=>m.reserveDailyCU(1)],['economy-scans:'+actor,20,'PERSONAL_SCAN_LIMIT',m.reserveFreshScan],['economy-scans:global',600,'SCAN_LIMIT',m.reserveFreshScan]]){clear();put(key,limit);await assert.rejects(run(fn),e=>e.code===code);assert.equal(count(key),limit);assert.equal(calls,0)}
 clear();put('birdeye-month-budget',5,month);await m.reserveBirdeyeCredits(30);assert.equal(count('birdeye-cu-budget-v1'),530);put('birdeye-cu-budget-v1',23999,month);await assert.rejects(run(()=>m.reserveBirdeyeCredits(2)),e=>e.code==='MONTHLY_RESEARCH_LIMIT');assert.equal(count('birdeye-cu-budget-v1'),23999);put('birdeye-cu-budget-v1',23999,month-1);await m.reserveBirdeyeCredits(10);assert.equal(count('birdeye-cu-budget-v1'),510);
 console.log('PASS atomic concurrent caps, personal/shared daily scan/CU limits, legacy monthly usage and UTC rollover');
 clear();globalThis.__economyUser=null;
 const guestRequest=cookie=>new Request('https://test.invalid/api/lens/allowance',{headers:cookie?{cookie}:{}});
 const first=await m.GET(guestRequest()),firstStatus=await first.clone().json(),firstCookie=first.headers.get('set-cookie');
 const second=await m.GET(guestRequest()),secondCookie=second.headers.get('set-cookie');
 assert.equal(firstStatus.limits.personalScans,5);assert.equal(firstStatus.limits.personalCU,80);
 assert.match(firstCookie,/^__Host-vector-discovery-guest=/);for(const flag of ['HttpOnly','Secure','SameSite=Lax','Path=/'])assert.ok(firstCookie.includes(flag));
 const ga=await m.guestBudget(guestRequest(firstCookie)),gb=await m.guestBudget(guestRequest(secondCookie));assert.notEqual(ga.actor,gb.actor);assert.equal(ga.cookie,undefined);
 const madeUp=await m.guestBudget(guestRequest('__Host-vector-discovery-guest='+'a'.repeat(64)));assert.ok(madeUp.cookie);assert.notEqual(madeUp.actor,'guest:'+await m.digest('a'.repeat(64)));
 for(let n=0;n<5;n++)await m.withResearchContext(ga.actor,'scan',m.reserveFreshScan);
 await assert.rejects(m.withResearchContext(ga.actor,'scan',m.reserveFreshScan),e=>e.code==='PERSONAL_SCAN_LIMIT');
 await m.withResearchContext(gb.actor,'scan',m.reserveFreshScan);
 assert.equal((await (await m.GET(guestRequest(firstCookie))).json()).used.personalScans,5);
 assert.equal((await (await m.GET(guestRequest(secondCookie))).json()).used.personalScans,1);
 assert.equal((await m.GET(new Request('https://test.invalid/api/lens/watch',{headers:{cookie:firstCookie}}))).status,401,'quota cookie is not account authorization');
 globalThis.__economyUser={userId:'alice'};put('economy-scans:'+actor,7);
 for(const cookie of [firstCookie,secondCookie]){const status=await (await m.GET(guestRequest(cookie))).json();assert.equal(status.audience,'account');assert.equal(status.used.personalScans,7);assert.equal(status.limits.personalScans,20);assert.ok(!JSON.stringify(status).includes(actor));}
 sql.prepare('UPDATE lens_rate_limits SET window=? WHERE key=?').run(Date.now()-1,'guest-session:'+ga.actor.slice(6));assert.ok((await m.guestBudget(guestRequest(firstCookie))).cookie);
 console.log('PASS independent browser quotas, registered cookie validation/expiry, private-data boundary and one account quota across devices');
 clear();const contenders=await Promise.allSettled(Array.from({length:20},(_,i)=>m.withResearchContext('account'+i,'chart',()=>m.reserveDailyCU(40))));
 assert.equal(contenders.filter(r=>r.status==='fulfilled').length,8);assert.equal(count('economy-bucket:charts'),320);assert.equal(count('economy-cu:global'),320);assert.equal(count('birdeye-cu-budget-v1'),320);
 await run(()=>m.reserveDailyCU(30));await m.withResearchContext('wallet-account','portfolio',()=>m.reserveDailyCU(50));
 assert.equal(count('economy-bucket:analysis'),30);assert.equal(count('economy-bucket:wallets'),50);assert.equal(count('economy-cu:global'),400);
 clear();put('birdeye-cu-budget-v1',24000,month);await assert.rejects(run(()=>m.reserveDailyCU(40)),e=>e.code==='MONTHLY_RESEARCH_LIMIT');assert.equal(count('economy-cu:'+actor),0);assert.equal(count('economy-cu:global'),0);assert.equal(count('economy-bucket:analysis'),0);
 clear();put('economy-cu:global',800);await assert.rejects(run(()=>m.reserveDailyCU(40)),e=>e.code==='DAILY_RESEARCH_LIMIT');assert.equal(count('economy-cu:'+actor),0);
 clear();await m.withResearchContext('old-chart','chart',()=>m.meter('cu',300));await assert.rejects(m.withResearchContext(actor,'chart',()=>m.reserveDailyCU(40)),e=>e.code==='FEATURE_RESEARCH_LIMIT');assert.equal(count('economy-cu:'+actor),0,'earlier feature usage survives upgrade');
 clear();for(let n=0;n<3;n++)await m.withResearchContext('guest:browser'+n,'chart',()=>m.reserveDailyCU(80));
 await assert.rejects(m.withResearchContext('guest:new-cookie','chart',()=>m.reserveDailyCU(40)),e=>e.code==='GUEST_RESEARCH_LIMIT');assert.equal(count('economy-cu:guest:new-cookie'),0);
 console.log('PASS atomic feature/monthly reservations, separate chart/wallet/analysis pools, preserved usage and bounded aggregate guest spend');
 clear();globalThis.__economyEnv.BITQUERY_ACCESS_TOKEN='fixture-only';globalThis.__economyEnv.TOKENSNIFFER_API_KEY='fixture-only';globalThis.__economyEnv.BUBBLEMAPS_API_KEY='fixture-only';
 const urls=[];globalThis.fetch=async url=>{urls.push(String(url));return Response.json({success:true,data:{}})};
 const basic=await m.scan('solana','So11111111111111111111111111111111111111112');
 assert.equal(urls.filter(u=>/birdeye|bitquery|tokensniffer|bubblemaps/.test(u)).length,0);assert.equal(basic.intelligence,undefined);
 const extended=await m.withResearchContext(actor,'research',()=>m.retrySection(basic,'research'));
 assert.ok(urls.some(u=>u.includes('public-api.birdeye.so')));assert.ok(extended.intelligence);
 delete globalThis.__economyEnv.BITQUERY_ACCESS_TOKEN;delete globalThis.__economyEnv.TOKENSNIFFER_API_KEY;delete globalThis.__economyEnv.BUBBLEMAPS_API_KEY;
 globalThis.fetch=async()=>{calls++;return Response.json(response)};
 console.log('PASS real scanner skips paid research by default; explicit research requests it');

 clear();let work=0;const publicWork=async()=>{work++;await new Promise(r=>setTimeout(r,25));return {id:'shared-report',at:'2026-10-01T12:00:00Z'}};
 const results=await Promise.all(Array.from({length:12},(_,i)=>m.withResearchContext('actor'+i,'scan',()=>m.sharedResearch('same-token',120000,publicWork))));assert.equal(work,1);assert.ok(results.every(r=>r.id==='shared-report'));assert.equal(sql.prepare('SELECT COUNT(*) AS n FROM lens_research_flights').get().n,0);
 put('economy-cu:'+actor,200);put('economy-cu:global',800);put('birdeye-cu-budget-v1',24000,month);const cached=await run(()=>m.sharedResearch('same-token',120000,()=>{throw new Error('must not refresh')}));assert.equal(cached.at,results[0].at);
 const oldKey=await m.digest('expired');sql.prepare('INSERT INTO lens_research_flights VALUES (?,?,?)').run(oldKey,'crashed-owner',Date.now()-1000);assert.equal(await run(()=>m.singleFlight('expired',async()=>null,async()=>9)),9);
 await assert.rejects(run(()=>m.singleFlight('failed',async()=>null,async()=>{throw new Error('upstream failed')})),/upstream failed/);assert.equal(sql.prepare('SELECT COUNT(*) AS n FROM lens_research_flights').get().n,0);
 // A late old owner must not release a newer owner's lease.
 await run(()=>m.singleFlight('renewed',async()=>null,async()=>{sql.prepare('UPDATE lens_research_flights SET owner=? WHERE key=?').run('new-owner',await m.digest('renewed'));return 1}));assert.equal(sql.prepare('SELECT owner FROM lens_research_flights WHERE key=?').get(await m.digest('renewed')).owner,'new-owner');
 console.log('PASS 12 concurrent readers share one result, exhausted users can read cache, expired/failed lease recovery and ownership-safe release');
 clear();put('economy-upstream:market',10000);await assert.rejects(run(()=>m.fetchJson('https://api.dexscreener.com/latest/dex/tokens/test')),e=>e.code==='SOURCE_DAILY_LIMIT');assert.equal(calls,0);assert.equal(count('economy-upstream:market'),10000);
 clear();put('economy-cu:'+actor,200);await assert.rejects(run(()=>m.birdeyeCached('same-evidence',60000,'/fixture',{cost:20,chain:'solana'},r=>r.data)),e=>e.code==='PERSONAL_RESEARCH_LIMIT');assert.equal(await m.readCache('same-evidence:failure',60000),null);assert.equal(calls,0);
 const b=await m.withResearchContext('bob','portfolio',()=>m.birdeyeCached('same-evidence',60000,'/fixture',{cost:20,chain:'solana'},r=>r.data));assert.equal(b.data.value,1);assert.equal(calls,1);assert.equal(count('economy-cu:bob'),20);
 console.log('PASS daily source cap stops HTTP and one exhausted user cannot poison shared provider cache');
 clear();const raw=JSON.parse(await readFile('tests/fixtures/portfolio/holdings.json','utf8')),positions=JSON.parse(await readFile('tests/fixtures/portfolio/positions.json','utf8')),wallet=raw.data.wallet;
 globalThis.fetch=async url=>{calls++;return Response.json(String(url).includes('current-net-worth')?raw:positions)};
 const fresh=await m.withResearchContext(actor,'portfolio',()=>m.walletPortfolio('solana',wallet));assert.equal(fresh.state,'ok');assert.ok(fresh.items.length>0);assert.equal(calls,2);
 sql.prepare('UPDATE lens_provider_cache SET fetched_at=?').run(Date.now()-600000);put('economy-cu:'+actor,200);const stale=await m.withResearchContext(actor,'portfolio',()=>m.walletPortfolio('solana',wallet));assert.equal(stale.state,'stale');assert.equal(stale.at,fresh.at);assert.deepEqual(stale.items,fresh.items);assert.equal(stale.totalValue,fresh.totalValue);assert.equal(calls,2);assert.match(stale.detail,/saved portfolio/);
 console.log('PASS actual portfolio aggregation falls back at quota with original timestamp, balances and PnL, without new HTTP');
 clear();put('economy-cu:'+actor,70);put('economy-scans:'+actor,3);put('economy-cu:'+await m.digest('bob'),100);await run(()=>m.meter('cu',70));
 const status=await m.allowanceStatus('alice');assert.equal(status.used.personalCU,70);assert.equal(status.used.personalScans,3);assert.equal(status.usage[0].count,70);assert.ok(!JSON.stringify(status).includes(actor));
 const req=()=>new Request('https://test.invalid/api/lens/usage');let r=await m.GET(req());assert.equal(r.status,200);assert.equal((await r.json()).used.personalCU,70);globalThis.__economyUser=null;r=await m.GET(req());assert.equal(r.status,401);
 globalThis.__economyUser={userId:'alice'};put('economy-upstream:market',10000);const pair='https://dexscreener.com/ethereum/0x'+'1'.repeat(40);r=await m.POST(new Request('https://test.invalid/api/lens/scan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({input:pair,network:'ethereum'})}));assert.equal(r.status,429);assert.equal((await r.json()).code,'SOURCE_DAILY_LIMIT');assert.equal(calls,0);
 console.log('PASS usage is authenticated/account-scoped and real route context enforces HTTP limits before a pair lookup');
 clear();for(const network of ['base','robinhood','polygon','constructor','__proto__']){for(const action of ['scan','discovery','wallet-portfolio','wallet-history','wallet-follow']){const response=await m.POST(new Request('https://test.invalid/api/lens/'+action,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({network,input:'0x'+'a'.repeat(40),address:'0x'+'a'.repeat(40)})}));assert.equal(response.status,400);assert.match((await response.json()).error,/Ethereum, BNB Chain and Solana/);}}assert.equal(calls,0);for(const action of ['rh-catalog','rh-saved'])assert.equal((await m.GET(new Request('https://test.invalid/api/lens/'+action))).status,404);console.log('PASS every network-bearing route rejects removed chains before provider work; Robinhood reads are absent');
 clear();const report={id:'economy-saved-report',mode:'live',network:'ethereum',address:'0x'+'a'.repeat(40),generatedAt:new Date(Date.now()-600000).toISOString(),market:{pools:[]},token:{name:'Existing token',symbol:'TOKEN',decimals:18},sources:[]};await m.storeReport(report);put('economy-scans:'+actor,20);
 const request=stream=>new Request('https://test.invalid/api/lens/scan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({input:report.address,network:'ethereum',stream})});
 for(const streaming of [false,true]){const res=await m.POST(request(streaming));assert.equal(res.status,200);const text=await res.text(),body=streaming?JSON.parse(text.trim().split('\n').at(-1)):JSON.parse(text);assert.equal(body.report.generatedAt,report.generatedAt);assert.equal(body.report.id,report.id);assert.equal(body.cached,true);assert.match(body.note,/saved snapshot/);assert.equal(body.code,'PERSONAL_SCAN_LIMIT');assert.equal(body.resetsAt,m.nextDay());if(streaming)assert.equal(body.type,'complete')}
 const section=await m.POST(new Request('https://test.invalid/api/lens/retry-check',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({reportId:report.id,section:'research'})}));const sectionBody=await section.json();assert.equal(sectionBody.report.generatedAt,report.generatedAt);assert.equal(sectionBody.report.id,report.id);assert.equal(sectionBody.resetsAt,m.nextDay());assert.equal(sectionBody.cached,true);
 assert.equal(calls,0);assert.equal(sql.prepare('SELECT COUNT(*) AS n FROM lens_reports').get().n,1);assert.equal(sql.prepare('SELECT user_id FROM lens_recent_reports').get().user_id,'alice');
 console.log('PASS real JSON and streaming scan routes keep saved evidence/date at quota, without new report or upstream work');

}finally{globalThis.fetch=originalFetch;delete globalThis.__economyDb;delete globalThis.__economyEnv;delete globalThis.__economyUser;sql.close();await rm(dir,{recursive:true,force:true})}
