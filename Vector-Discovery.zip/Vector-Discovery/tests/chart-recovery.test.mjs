import {build} from 'esbuild';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';

const dir=await mkdtemp(join(tmpdir(),'tom-chart-recovery-'));
const token='F4635H9HFAzYjpyM3coGMtW8pMmEYRtwrgz5mgfHpump';
const pool='8DcTcUgENxjLiUr2YkR2BJHcpWj1epd16dtsWm2wJNkg';
const key=`gt:pools:solana:${token}`;
const memory=new Map();let requests=[],replies=[];
globalThis.__chartRecovery={memory,request:async url=>{requests.push(url);const next=replies.shift();if(next instanceof Error)throw next;assert.ok(next,'Unexpected provider request');return next;}};
const plugin={name:'chart-fixtures',setup(b){
 b.onResolve({filter:/^\.\/birdeye-chart$/},()=>({path:'birdeye',namespace:'fallback'}));
 b.onLoad({filter:/.*/,namespace:'fallback'},()=>({loader:'js',contents:'export const supportsBirdeyeChart=()=>false; export const cachedBirdeyeChart=()=>null; export const birdeyeChart=()=>null;'}));
 b.onResolve({filter:/^\.\/(cache|http|storage)$/},a=>({path:a.path,namespace:'fixture'}));
 b.onLoad({filter:/.*/,namespace:'fixture'},a=>({loader:'js',contents:a.path==='./cache'?`export async function readCache(key,maxAge){const row=globalThis.__chartRecovery.memory.get(key);return row&&Date.now()-row.at<maxAge?row:null} export async function writeCache(key,data){globalThis.__chartRecovery.memory.set(key,{data,at:Date.now()})}`:a.path==='./http'?`export async function fetchJson(url){return globalThis.__chartRecovery.request(url)}`:`export async function throttle(){}`}));
}};
const discovery={data:[{attributes:{address:pool,name:'WHIPCAT / SOL',reserve_in_usd:'10000'},relationships:{base_token:{data:{id:'solana_'+token}},dex:{data:{id:'pumpswap'}}}}]};
const candles={meta:{base:{address:token}},data:{attributes:{ohlcv_list:[[1600000000,1,2,.5,1.2,100]]}}};
const report={network:'solana',address:token,market:{pools:[],priceUsd:null}};
try{
 const output=join(dir,'chart.mjs');await build({entryPoints:['lib/lens/chart.ts'],outfile:output,bundle:true,platform:'node',format:'esm',plugins:[plugin],logLevel:'silent'});
 const {chart}=await import(pathToFileURL(output).href);
 memory.set(key,{data:[],at:Date.now()});replies=[discovery,candles];
 const recovered=await chart(report,'1h');assert.equal(recovered.state,'ok');assert.equal(recovered.pool.address,pool);assert.equal(recovered.candles.length,1);assert.equal(requests.length,2);assert.ok(requests[1].includes('token='+token));
 console.log('PASS legacy empty discovery is retried; exact Solana mint and pool are retained');
 const count=requests.length;await chart(report,'1h');assert.equal(requests.length,count);
 console.log('PASS usable pool and candle caches still avoid redundant requests');
 memory.clear();requests=[];replies=[{data:[]}];const empty=await chart(report,'1h');assert.equal(empty.state,'unavailable');assert.equal(memory.has(key),false);
 replies=[discovery,candles];assert.equal((await chart(report,'1h')).state,'ok');
 console.log('PASS transient empty discovery does not block the next successful retry');
 memory.clear();memory.set(key,{data:[],at:Date.now()});replies=[new Error('Provider rate limit reached.')];
 const failed=await chart(report,'1h');assert.equal(failed.state,'unavailable');assert.match(failed.detail,/rate limit/);
 console.log('PASS legacy empty cache does not disguise a provider failure as a missing pool');
}finally{delete globalThis.__chartRecovery;await rm(dir,{recursive:true,force:true})}
