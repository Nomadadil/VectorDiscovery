import {DatabaseSync} from 'node:sqlite';
import {build} from 'esbuild';
import {mkdtemp,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const sql=new DatabaseSync(':memory:');
for(const f of ['0000_easy_shatterstar','0001_lovely_bucky','0002_petite_echo','0003_mute_sharon_carter','0004_goofy_daimon_hellstrom','0005_kind_shaman'])sql.exec(await readFile('drizzle/'+f+'.sql','utf8'));
const shim={
 prepare(query){
  return {bind(...values){
   return {
    first:async()=>sql.prepare(query).get(...values)??null,
    all:async()=>({results:sql.prepare(query).all(...values)}),
    run:async()=>({meta:{changes:Number(sql.prepare(query).run(...values).changes)}})
   };
  }};
 },
 async batch(statements){
  sql.exec('BEGIN');
  try{const out=[];for(const s of statements)out.push(await s.run());sql.exec('COMMIT');return out}
  catch(e){sql.exec('ROLLBACK');throw e}
 }
};
globalThis.__lensDb=shim;
const dir=await mkdtemp(join(tmpdir(),'tom-lens-db-'));
try{
 const out=join(dir,'store.mjs');await build({stdin:{contents:"export * from './lib/lens/storage';export * from './lib/lens/wallets';export * from './lib/lens/dashboard';",resolveDir:process.cwd(),loader:'ts'},outfile:out,bundle:true,platform:'node',format:'esm',plugins:[{name:'local-d1',setup(b){b.onResolve({filter:/^cloudflare:workers$/},()=>({path:'env',namespace:'stub'}));b.onLoad({filter:/.*/,namespace:'stub'},()=>({contents:'export const env={DB:globalThis.__lensDb};',loader:'js'}));}}],logLevel:'silent'});
 const w=await import(pathToFileURL(out).href);
 const report={id:'test-snapshot-01',mode:'live',network:'ethereum',address:'0x'+'a'.repeat(40),generatedAt:new Date().toISOString(),token:{symbol:'TEST'},sources:[{id:'goplus',state:'ok'}]};
 const hash=await w.storeReport(report);assert.equal((await w.getReport(report.id)).digest,hash);await assert.rejects(w.storeReport({...report,token:{symbol:'CHANGED'}}));assert.equal((await w.getReport(report.id)).report.token.symbol,'TEST');
 await w.addWatch('user-a',report);const item=(await w.listWatch('user-a')).items[0];assert.equal((await w.listWatch('user-b')).items.length,0);await assert.rejects(w.updateWatch('user-b',item.id,true,25));await w.updateWatch('user-a',item.id,true,25);assert.equal((await w.listWatch('user-a')).items[0].paused,true);
 const next={...report,id:'test-snapshot-02'},loser={...report,id:'test-snapshot-03'};await w.storeReport(next);await w.storeReport(loser);const changes=[{title:'Test change',detail:'Synthetic assertion',tone:'warn'}];
 await w.recordWatch('user-a',item,next,changes);assert.equal((await w.listWatch('user-a')).items[0].reportId,report.id);assert.equal((await w.listWatch('user-a')).events.length,0);await w.updateWatch('user-a',item.id,false,25);await w.recordWatch('user-a',item,next,changes);await w.recordWatch('user-a',item,loser,changes);const result=await w.listWatch('user-a');assert.equal(result.items[0].reportId,next.id);assert.equal(result.events.length,1);assert.equal(result.events[0].reportId,next.id);

 const publicWallet='0x'+'1'.repeat(40);
 await w.followWallet('user-a','ethereum',publicWallet,'A label');await w.followWallet('user-b','ethereum',publicWallet,'B label');const wa=(await w.listWallets('user-a'))[0];await w.unfollowWallet('user-b',wa.id);assert.equal((await w.listWallets('user-a'))[0].label,'A label');assert.equal((await w.listWallets('user-b'))[0].label,'B label');
 for(let i=2;i<=50;i++)await w.followWallet('user-a','ethereum','0x'+i.toString(16).padStart(40,'0'),'');await assert.rejects(w.followWallet('user-a','ethereum','0x'+'f'.repeat(40),''));await w.followWallet('user-a','ethereum',publicWallet,'Renamed');assert.equal((await w.listWallets('user-a')).find(x=>x.address===publicWallet).label,'Renamed');assert.equal((await w.listWallets('user-a')).length,50);await w.unfollowWallet('user-a',wa.id);assert.equal((await w.listWallets('user-a')).length,49);
 // Recent research is personal, capped, deduplicated, and never includes demo records.
 await w.rememberReport('user-a',report);await w.rememberReport('user-b',next);
 assert.equal((await w.dashboard('user-a')).recent[0].id,report.id);
 assert.equal((await w.dashboard('user-b')).recent[0].id,next.id);
 await w.rememberReport('user-a',next);assert.equal((await w.dashboard('user-a')).recent.length,1);assert.equal((await w.dashboard('user-a')).recent[0].id,next.id);
 await w.rememberReport('user-a',{...report,mode:'demo',address:'demo'});assert.equal((await w.dashboard('user-a')).recent.length,1);
 for(let i=0;i<15;i++){const rr={...report,id:'recent-'+String(i).padStart(6,'0'),address:'0x'+(100+i).toString(16).padStart(40,'0')};await w.storeReport(rr);await w.rememberReport('user-a',rr)}
 const home=await w.dashboard('user-a');assert.equal(home.recent.length,12);assert.equal(home.walletCount,49);assert.equal(home.watched.length,1);assert.equal(home.watched[0].id,next.id);assert.equal((await w.dashboard('user-b')).recent.length,1);assert.equal((await w.dashboard('user-b')).watched.length,0);
 console.log('PASS personal recent reports, demo exclusion, deduplication, 12-asset cap, watch snapshots and account isolation');
 console.log('PASS wallet ownership, cross-account delete isolation, persistence, 50-wallet cap and relabeling at cap');
 console.log('PASS immutable snapshots, per-user storage, pause persistence, concurrent Watch baseline and event isolation');
}finally{sql.close();delete globalThis.__lensDb;await rm(dir,{recursive:true,force:true})}
