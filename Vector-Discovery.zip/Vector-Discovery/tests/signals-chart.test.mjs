import {build} from 'esbuild';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';import {join} from 'node:path';import {pathToFileURL} from 'node:url';import assert from 'node:assert/strict';
const dir=await mkdtemp(join(tmpdir(),'vector-signals-chart-'));
const token='So11111111111111111111111111111111111111112',pool='58oQChx4yWmvKdwLLZzBi4ChoCc2fqCUWBkwMihLYQo2';
const poolData={data:{type:'pool',id:'solana_'+pool,attributes:{address:pool,name:'SOL / USDC',reserve_in_usd:'40000'},relationships:{base_token:{data:{id:'solana_'+token}},dex:{data:{id:'raydium'}}}}};
const replies=[],requests=[];globalThis.__signalChart=async url=>{requests.push(url);const r=replies.shift();if(r instanceof Error)throw r;assert.ok(r,'Unexpected request');return r;};
try{
 const file=join(dir,'signals.mjs');await build({entryPoints:['lib/lens/signals-chart.ts'],outfile:file,bundle:true,format:'esm',platform:'node',logLevel:'silent',plugins:[{name:'isolated-public-upstreams',setup(b){
  b.onResolve({filter:/^\.\/(http|storage|shared-research|birdeye-chart|cache)$/},a=>({path:a.path,namespace:'fixture'}));
  b.onLoad({filter:/.*/,namespace:'fixture'},a=>({loader:'js',contents:a.path==='./http'?'export const fetchJson=url=>globalThis.__signalChart(url);':a.path==='./shared-research'?'export const sharedResearch=(key,ttl,work)=>work();':a.path==='./storage'?'export const throttle=async()=>{};':a.path==='./cache'?'export const readCache=async()=>null;export const writeCache=async()=>{};':'export const supportsBirdeyeChart=()=>false;export const cachedBirdeyeChart=async()=>null;export const birdeyeChart=async()=>null;'}));
 }}]});
 const {signalChartPool,signalChart}=await import(pathToFileURL(file).href);
 assert.equal(signalChartPool(poolData,'solana',token,pool).address,pool);
 const wrong=structuredClone(poolData);wrong.data.relationships.base_token.data.id='eth_'+token;assert.throws(()=>signalChartPool(wrong,'solana',token,pool),/contain/);
 const wrongPool=structuredClone(poolData);wrongPool.data.attributes.address=token;assert.throws(()=>signalChartPool(wrongPool,'solana',token,pool),/verified/);
 replies.push(poolData,{meta:{base:{address:token}},data:{attributes:{ohlcv_list:[[Math.floor(Date.now()/1000)-600,1,2,.5,1.5,40]]}}});
 const result=await signalChart('solana',token,pool,'5m');assert.equal(result.state,'ok');assert.equal(result.candles.length,1);assert.ok(requests[1].includes('token='+token));assert.ok(requests[1].includes('aggregate=5'));
 replies.push(poolData,{meta:{base:{address:pool}},data:{attributes:{ohlcv_list:[[1600000000,1,2,.5,1.5,40]]}}});assert.equal((await signalChart('solana',token,pool,'5m')).state,'unavailable');
 const count=requests.length;await assert.rejects(()=>signalChart('base',token,pool,'5m'));await assert.rejects(()=>signalChart('solana',token,pool,'1d'));assert.equal(requests.length,count);
 replies.push(new Error('Provider rate limit reached.'));assert.match((await signalChart('solana',token,pool,'1m')).detail,/rate limit/);
 console.log('PASS Signals chart exact network/token/pool matching, candle orientation, free on-demand request, unsupported inputs and failure state');
}finally{delete globalThis.__signalChart;await rm(dir,{recursive:true,force:true});}
