import {build} from 'esbuild';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const dir=await mkdtemp(join(tmpdir(),'tom-birdeye-')),memory=new Map();let calls=[],budget=0,response;
const mint='F4635H9HFAzYjpyM3coGMtW8pMmEYRtwrgz5mgfHpump';
globalThis.__be={memory,request:async url=>{calls.push(url);if(url.includes('geckoterminal'))throw new Error('Provider rate limit reached. Try again later.');if(response instanceof Error)throw response;return response},budget:()=>budget};
const plugin={name:'fixtures',setup(b){
 b.onResolve({filter:/^cloudflare:workers$/},()=>({path:'env',namespace:'fixture'}));
 b.onResolve({filter:/^\.\/(http|cache|storage)$/},a=>({path:a.path,namespace:'fixture'}));
 b.onLoad({filter:/.*/,namespace:'fixture'},a=>({loader:'js',contents:a.path==='env'?`export const env={BIRDEYE_API_KEY:'fixture-only'}`:a.path==='./http'?`export const fetchJson=(url)=>globalThis.__be.request(url)`:a.path==='./cache'?`export async function readCache(k,age){const r=globalThis.__be.memory.get(k);return r&&Date.now()-r.at<age?r:null}export async function writeCache(k,data){globalThis.__be.memory.set(k,{data,at:Date.now()})}`:`export async function throttle(){};export const digest=async value=>value;export const db=()=>({prepare:()=>({bind:()=>({first:async()=>({count:globalThis.__be.budget(),window:Date.now()})})})});`}));
}};
try{
 const output=join(dir,'test.mjs');await build({stdin:{contents:"export * from './lib/lens/chart';export * from './lib/lens/birdeye-chart';",resolveDir:process.cwd()},outfile:output,bundle:true,platform:'node',format:'esm',plugins:[plugin],logLevel:'silent'});
 const {chart,normalizeBirdeyeCandles}=await import(pathToFileURL(output).href);
 const row={address:mint,unix_time:1600000000,o:1,h:2,l:.5,c:1.5,v:999999,v_usd:30,currency:'usd'};
 const raw=()=>({success:true,data:{items:[{...row}]}});
 assert.equal(normalizeBirdeyeCandles(raw(),'solana',mint)[0].volume,30);
 assert.throws(()=>normalizeBirdeyeCandles({...raw(),data:{items:[{...row,address:mint.toLowerCase()}]}},'solana',mint));
 assert.throws(()=>normalizeBirdeyeCandles({...raw(),data:{items:[{...row,v_usd:null}]}},'solana',mint));
 assert.throws(()=>normalizeBirdeyeCandles({...raw(),data:{is_scaled_ui_token:true,multiplier:2,items:[row]}},'solana',mint));
 assert.throws(()=>normalizeBirdeyeCandles({...raw(),data:{items:[{...row,currency:'native'}]}},'solana',mint));
 console.log('PASS token identity, USD volume, quote units and scaled token checks');
 const report={network:'solana',address:mint,market:{pools:[],priceUsd:null}};
 response=raw();let result=await chart(report,'1h');assert.equal(result.needsExtended,true);assert.ok(!calls.some(x=>x.includes('birdeye')),'auto chart never spends paid credits');result=await chart(report,'1h',undefined,true);assert.equal(result.provider,'Birdeye');assert.equal(result.scope,'token');assert.equal(result.pool,null);assert.equal(result.state,'ok');
 const count=calls.length;assert.equal((await chart(report,'1h')).state,'ok');assert.equal(calls.length,count);
 console.log('PASS paid fallback requires explicit request, loads real-shaped token candles and reuses cache');
 calls=[];result=await chart(report,'1h','some-pool');assert.equal(result.state,'unavailable');assert.ok(!calls.some(x=>x.includes('birdeye')));
 console.log('PASS explicit pool charts never substitute token-wide candles or cached fallback');
 for(const v of memory.values())v.at=Date.now()-360000;response=new Error('Provider timed out.');result=await chart(report,'1h',undefined,true);assert.equal(result.state,'stale');assert.equal(result.provider,'Birdeye');assert.match(result.detail,/earlier saved/);
 console.log('PASS stale fallback is labelled, never silently current');
 memory.clear();calls=[];budget=24001;result=await chart(report,'1h',undefined,true);assert.equal(result.state,'unavailable');assert.ok(!calls.some(x=>x.includes('birdeye')));
 console.log('PASS monthly allowance blocks additional paid-source requests');
 await assert.rejects(()=>chart(report,'bad'));console.log('PASS invalid interval fails before provider access');
}finally{delete globalThis.__be;await rm(dir,{recursive:true,force:true})}
