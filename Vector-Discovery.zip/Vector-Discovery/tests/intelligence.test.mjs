import {build} from 'esbuild';
import {mkdtemp,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {DatabaseSync} from 'node:sqlite';
import assert from 'node:assert/strict';
const dir=await mkdtemp(join(tmpdir(),'lens-intel-'));
const fixture={};for(const n of ['holders','transfers','traders','launch'])fixture[n]=JSON.parse(await readFile(`tests/fixtures/birdeye-intel/${n}.json`,'utf8'));
const mint=fixture.launch.data.address,owner=fixture.holders.data.items[0].owner;
// Anchor the 24-hour query to the captured fixture; it must not expire with wall-clock time.
const realNow=Date.now;Date.now=()=>Math.max(...fixture.transfers.data.map(x=>x.unix_time))*1000+1000;
const fakeEnv={BIRDEYE_API_KEY:'fixture-only'};
globalThis.__intel={env:fakeEnv,read:async(key,normalize)=>{const kind=key.split(':').at(-1);if(kind==='distribution')throw new Error('Provider access is unavailable.');return {data:normalize(fixture[kind]),at:new Date().toISOString()}}};
const plugin={name:'intel-fixtures',setup(b){
 b.onResolve({filter:/^cloudflare:workers$/},()=>({path:'env',namespace:'fake'}));
 b.onResolve({filter:/^\.\/birdeye-client$/},()=>({path:'client',namespace:'fake'}));
 b.onLoad({filter:/.*/,namespace:'fake'},a=>({loader:'js',contents:a.path==='env'?'export const env=globalThis.__intel.env':`export const birdeyeCached=(key,ttl,path,options,normalize)=>globalThis.__intel.read(key,normalize);`}));
}};
try{
 const out=join(dir,'intel.mjs');await build({stdin:{contents:"export * from './lib/lens/intelligence';export * from './lib/lens/scanner';export * from './lib/lens/risk';export * from './lib/lens/token-context';export * from './lib/lens/solana-security';",resolveDir:process.cwd()},outfile:out,bundle:true,platform:'node',format:'esm',plugins:[plugin],logLevel:'silent'});
 const m=await import(pathToFileURL(out).href);
 const h=m.normalizeIntelHolders(fixture.holders,mint);assert.equal(h.items[0].balance,'147847867.412336');assert.equal(h.top10,29.686930864331334);assert.equal(h.items[0].share,null);assert.equal(h.count,1454);
 assert.throws(()=>m.normalizeIntelHolders(fixture.holders,mint.toLowerCase()));
 const invalid=structuredClone(fixture.holders);invalid.data.items[0].amount='147847867412336';invalid.data.items=invalid.data.items.slice(0,1);assert.throws(()=>m.normalizeIntelHolders(invalid,mint));
 const scaled=structuredClone(fixture.holders);scaled.data.items=scaled.data.items.slice(0,1);scaled.data.items[0].is_scaled_ui_token=true;scaled.data.items[0].multiplier=2;assert.throws(()=>m.normalizeIntelHolders(scaled,mint));
 console.log('PASS live wallet-mode decimal units, snake-case totals, exact identity, ambiguous/scaled units rejected');
 const row=fixture.transfers.data[0],from=row.unix_time-86400,to=row.unix_time+1;const transfers=m.normalizeTransfers(fixture.transfers,mint,from,to);assert.ok(transfers.items.length);assert.equal(transfers.items[0].amount,'427468.373265');assert.equal(m.normalizeTransfers({success:true,data:[{...row,action:'burn'},{...row,from_address:row.to_address}]},mint,from,to).items.length,0);assert.equal(m.normalizeTransfers({success:true,data:[row,row]},mint,from,to).items.length,1);assert.throws(()=>m.normalizeTransfers({success:true,data:[{...row,token_address:'wrong'}]},mint,from,to));
 const links=m.transferLinks(transfers.items,[{address:row.from_address},{address:row.to_address}]);assert.ok(links.length);assert.ok(links[0].txHash);assert.equal(m.transferLinks(transfers.items,[]).length,0);
 console.log('PASS token-scoped transfers, duplicate exclusion, self/burn filtering and evidence-backed edges');
 const traders=m.normalizeTraders(fixture.traders,mint);assert.equal(traders.items[0].buyVolume,1687.774403471998);assert.equal(traders.items[0].sells,4);assert.ok(!('profit' in traders.items[0]));
 const launch=m.normalizeLaunch(fixture.launch,mint);assert.equal(launch.platform,'pump.fun');assert.equal(launch.graduated,true);assert.equal(launch.progress,100);
 const report=m.emptyReport('solana',mint);report.holders.items=[{address:owner,balance:'1',share:55,label:'Existing holder',kind:'unclassified',source:'RugCheck'}];await m.enrichIntelligence(report,false);assert.equal(report.holders.items[0].share,55);assert.equal(report.holders.items[0].shareSource,'RugCheck');assert.ok(m.assessRisk(report).reasons.some(r=>r.id==='large-holder'&&r.severity===8));
 await m.enrichIntelligence(report,true);assert.equal(report.intelligence.distribution.state.state,'unavailable');assert.equal(report.holders.items[0].share,55);assert.ok(report.activity.transfers.length);
 delete fakeEnv.BIRDEYE_API_KEY;const noKey=m.emptyReport('solana',mint);await m.enrichIntelligence(noKey,true);assert.equal(noKey.intelligence.holders.state.state,'unavailable');
 console.log('PASS failed optional calls preserve known holder risks, other successful data and missing-connection states');
 const mixed=m.emptyReport('solana',mint);mixed.holders.items=[{address:owner,balance:'1',share:60,label:'Earlier record',kind:'unclassified',source:'RugCheck'},{address:fixture.holders.data.items[1].owner,balance:'2',share:70,label:'New record',kind:'unclassified',source:'Birdeye',shareSource:'Birdeye distribution'}];m.finalize(mixed);assert.equal(mixed.holders.topShare,null);assert.equal(mixed.holders.adjustedShare,null);mixed.holders.items[1].share=30;m.finalize(mixed);assert.equal(mixed.holders.topShare,null);mixed.holders.items[1].shareSource='RugCheck';m.finalize(mixed);assert.equal(mixed.holders.topShare,90);console.log('PASS conflicting holder snapshots are never summed, including totals below 100%');
 const security=m.normalizeSolanaSecurity({code:1,result:{[mint]:{mintable:{status:'1'},freezable:{status:'0'},non_transferable:'1'}}},mint);assert.equal(security.facts.find(f=>f.id==='sol-mintable').signal,true);assert.equal(security.facts.find(f=>f.id==='sol-transfer_hook_upgradable').signal,null);assert.throws(()=>m.normalizeSolanaSecurity({code:1,result:{}},mint));const risky=m.emptyReport('solana',mint);risky.facts=security.facts;assert.equal(m.assessRisk(risky).score,9);
 const context=m.normalizeTokenContext({data:{id:'solana_'+mint,attributes:{address:mint,holders:{count:1282,distribution_percentage:{top_10:'25.7647','11_20':'12.0046','21_40':'17.0073',rest:'45.2234'}},developer_address:owner,developer_holding_percentage:'1.28'}}},report);assert.equal(context.holders.buckets.length,4);assert.equal(context.developer.share,1.28);
 console.log('PASS independent Solana permissions affect risk; chain-specific holder buckets and developer percent units');
 // Exercise the actual SQLite reservation, including a legacy-usage migration.
 const sql=new DatabaseSync(':memory:');sql.exec('CREATE TABLE lens_rate_limits (key TEXT PRIMARY KEY,window INTEGER,count INTEGER)');const month=new Date().getUTCFullYear()*12+new Date().getUTCMonth();sql.prepare('INSERT INTO lens_rate_limits VALUES (?,?,?)').run('birdeye-month-budget',month,5);
 globalThis.__intelDb={prepare:q=>({bind:(...v)=>({first:async()=>sql.prepare(q).get(...v)??null})})};
 const budgetOut=join(dir,'budget.mjs');await build({entryPoints:['lib/lens/birdeye-client.ts'],outfile:budgetOut,bundle:true,platform:'node',format:'esm',plugins:[{name:'sqlite',setup(b){b.onResolve({filter:/^cloudflare:workers$/},()=>({path:'env',namespace:'db'}));b.onResolve({filter:/^\.\/storage$/},()=>({path:'store',namespace:'db'}));b.onLoad({filter:/.*/,namespace:'db'},a=>({loader:'js',contents:a.path==='env'?'export const env={}':'export const digest=async value=>value;export const db=()=>globalThis.__intelDb'}));}}],logLevel:'silent'});const budget=await import(pathToFileURL(budgetOut).href);await budget.reserveBirdeyeCredits(30);assert.equal(sql.prepare("SELECT count FROM lens_rate_limits WHERE key='birdeye-cu-budget-v1'").get().count,530);await Promise.all([budget.reserveBirdeyeCredits(40),budget.reserveBirdeyeCredits(20)]);assert.equal(sql.prepare("SELECT count FROM lens_rate_limits WHERE key='birdeye-cu-budget-v1'").get().count,590);sql.prepare("UPDATE lens_rate_limits SET count=23999 WHERE key='birdeye-cu-budget-v1'").run();await assert.rejects(()=>budget.reserveBirdeyeCredits(8));sql.prepare("UPDATE lens_rate_limits SET window=? WHERE key='birdeye-cu-budget-v1'").run(month-1);await budget.reserveBirdeyeCredits(20);assert.equal(sql.prepare("SELECT count FROM lens_rate_limits WHERE key='birdeye-cu-budget-v1'").get().count,520);sql.close();console.log('PASS shared credit reservations, legacy migration, concurrent accumulation, cap and month rollover');
}finally{Date.now=realNow;delete globalThis.__intel;delete globalThis.__intelDb;await rm(dir,{recursive:true,force:true})}
