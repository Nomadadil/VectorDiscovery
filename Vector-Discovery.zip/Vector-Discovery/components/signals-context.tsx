'use client';
import {createContext,useCallback,useContext,useEffect,useRef,useState,type ReactNode} from 'react';
import type {Network} from '@/lib/lens/types';
import type {SignalsFeed} from '@/lib/lens/signals-types';
const initial:SignalsFeed={subscription:{enabled:false,networks:['solana'],startedAt:null,lastRead:null},items:[],unread:0,at:'',retentionDays:7};
export async function signalRequest(path:string,body?:unknown,signal?:AbortSignal){const res=await fetch('/api/lens/'+path,{...(body===undefined?{method:'GET'}:{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)}),cache:'no-store',signal});const json:any=await res.json();if(!res.ok)throw new Error(json.error||'Signals are temporarily unavailable.');return json;}
type SignalsState={feed:SignalsFeed;loading:boolean;saving:boolean;error:string;reload:()=>Promise<void>;subscribe:(networks:Network[],enabled:boolean)=>Promise<void>;read:()=>Promise<void>};
const Context=createContext<SignalsState>({feed:initial,loading:false,saving:false,error:'',reload:async()=>{},subscribe:async()=>{},read:async()=>{}});
export const useSignals=()=>useContext(Context);
export function SignalsProvider({signedIn,children}:{signedIn:boolean;children:ReactNode}){const [feed,setFeed]=useState(initial),[loading,setLoading]=useState(false),[saving,setSaving]=useState(false),[error,setError]=useState('');const mounted=useRef(true),request=useRef(0),signed=useRef(signedIn);signed.current=signedIn;
 const reload=useCallback(async()=>{if(!signedIn)return;const id=++request.current;setLoading(true);try{const data=await signalRequest('signals-feed');if(mounted.current&&signed.current&&id===request.current){setFeed(data);setError('')}}catch(e){if(mounted.current&&id===request.current)setError(e instanceof Error?e.message:'Signals are temporarily unavailable.')}finally{if(mounted.current&&id===request.current)setLoading(false)}},[signedIn]);
 const subscribe=useCallback(async(networks:Network[],enabled:boolean)=>{setSaving(true);setError('');try{const data=await signalRequest('signals-subscribe',{networks,enabled});if(mounted.current&&signed.current)setFeed(data)}catch(e){setError(e instanceof Error?e.message:'Could not save your subscription.');throw e}finally{if(mounted.current)setSaving(false)}},[]);
 const read=useCallback(async()=>{try{const data=await signalRequest('signals-read',{});if(mounted.current&&signed.current)setFeed(data)}catch(e){if(mounted.current)setError(e instanceof Error?e.message:'Could not update notifications.')}},[]);
 useEffect(()=>{mounted.current=true;return()=>{mounted.current=false}},[]);
 useEffect(()=>{if(!signedIn){request.current++;setFeed(initial);setLoading(false);return}reload();const poll=()=>{if(document.visibilityState==='visible'&&navigator.onLine)reload()};const timer=window.setInterval(poll,60000);document.addEventListener('visibilitychange',poll);return()=>{window.clearInterval(timer);document.removeEventListener('visibilitychange',poll)}},[signedIn,reload]);
 return <Context.Provider value={{feed,loading,saving,error,reload,subscribe,read}}>{children}</Context.Provider>;
}
