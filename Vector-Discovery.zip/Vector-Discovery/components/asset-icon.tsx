'use client';
import {useState} from 'react';
export function AssetIcon({asset}:{asset:{logo:string|null;symbol:string}}){const [failed,setFailed]=useState(false);return <span className="position-icon">{asset.logo&&!failed?<img src={asset.logo} alt="" loading="lazy" referrerPolicy="no-referrer" onError={()=>setFailed(true)}/>:asset.symbol.slice(0,2)}</span>}
