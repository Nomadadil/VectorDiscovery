'use client';
import {useLocale} from '@/lib/lens/i18n';
import {NETWORKS,shortAddress,type LensReport} from '@/lib/lens/types';
import {assessRisk} from '@/lib/lens/risk';
import type {ScanProgress} from '@/lib/lens/scan-stream';
import {TomLoader} from './tom-loader';
import {Check,ArrowRight,RefreshCw,Info} from 'lucide-react';
export function ProgressiveScan({progress,failed,retry}:{progress:ScanProgress;failed:boolean;retry:()=>void}){
 const {locale,money}=useLocale(),ru=locale==='ru',r=progress.report;
 const stages=ru?['Актив и рынок','Основные проверки','Расширенные данные']:['Asset & market','Core checks','Extended evidence'];
 const step=progress.stage==='identity'?0:progress.stage==='market'?1:2;
 return <section className="progressive-scan" aria-label={ru?'Ход проверки':'Analysis progress'}>
 <div className="scan-steps" aria-label={ru?'Этапы проверки':'Analysis stages'}>{stages.map((s,i)=><div key={s} className={i<step?'is-done':i===step&&!failed?'is-current':''}><span>{i<step?<Check size={13}/>:i+1}</span><small>{s}</small></div>)}</div>
 {!failed&&<TomLoader label={stages[step]} detail={ru?'Показываем полученное сразу. Итог появится после завершения проверок.':'Evidence appears as it arrives. The assessment follows when checks finish.'}/>}
 {r&&r.market.pools.length>0&&<div className="scan-preview"><div className="scan-preview-heading"><div><span className="eyebrow">{NETWORKS[r.network].name} · {ru?'ПРЕДВАРИТЕЛЬНЫЕ ДАННЫЕ':'PRELIMINARY DATA'}</span><h2>{r.token.name}</h2><small>{r.token.symbol} · {shortAddress(r.address)}</small></div><ArrowRight size={22}/></div><div className="scan-preview-metrics"><div><span>{ru?'Цена':'Price'}</span><strong>{money(r.market.priceUsd)}</strong></div><div><span>{ru?'Капитализация':'Market cap'}</span><strong>{money(r.market.marketCap,true)}</strong></div><div><span>{ru?'Ликвидность пулов':'Pool liquidity'}</span><strong>{money(r.market.liquidityUsd,true)}</strong></div></div>{progress.stage!=='market'&&<div className="scan-early-signals">{assessRisk(r).reasons.slice(0,3).map(reason=><p key={reason.id}><Info size={16}/>{reason.title[locale]}</p>)}<small>{ru?'Проверка продолжается. Отсутствие сигнала пока не означает отсутствие риска.':'Checks are still incomplete. Missing signals do not mean missing risks.'}</small></div>}</div>}
 {failed&&<div className="scan-incomplete"><p>{ru?'Полный разбор не завершён. Эти данные нельзя считать итоговой оценкой.':'The full analysis did not finish. These preliminary readings are not a final assessment.'}</p><button className="secondary-button" onClick={retry}><RefreshCw size={16}/>{ru?'Повторить проверку':'Retry analysis'}</button></div>}
 </section>
}
export function SectionRefresh({report,busy,onRetry}:{report:LensReport;busy:string|null;onRetry:(section:'market'|'sale'|'context'|'research')=>void}){
 const {locale}=useLocale(),ru=locale==='ru';if(report.mode==='demo')return null;
 const sections=[['market',ru?'Рынок':'Market'],...(['bsc','ethereum'].includes(report.network)?[['sale',ru?'Продажа':'Sale check']]:[]),['context',ru?'Описание':'Context'],['research',ru?'Держатели и связи':'Holders & links']] as const;
 return <div className="section-refresh wide-panel"><div><strong>{ru?'Обновить отдельный раздел':'Refresh a section'}</strong><p>{ru?'Остальные данные сохраняют время своей проверки. Действуют лимиты доступных подключений.':'Other evidence keeps its original observation time. Connection limits still apply.'}</p></div><div className="section-refresh-actions">{sections.map(([id,label])=><button className="secondary-button" key={id} disabled={!!busy} onClick={()=>onRetry(id as any)}><RefreshCw size={14} className={busy===id?'spin':''}/>{label}</button>)}</div></div>
}
