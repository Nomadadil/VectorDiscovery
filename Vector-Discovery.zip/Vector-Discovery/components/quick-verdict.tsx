'use client';
import {ArrowUpRight,Info} from 'lucide-react';
import {useLocale} from '@/lib/lens/i18n';
import {assessRisk} from '@/lib/lens/risk';
import type {LensReport} from '@/lib/lens/types';
export function QuickVerdict({report,onOpen}:{report:LensReport;onOpen:(v:string)=>void}){
 const {locale}=useLocale(),c=(en:string,ru:string)=>locale==='ru'?ru:en,r=assessRisk(report);
 const first=r.reasons[0];
 return <section className="quick-verdict wide-panel"><div><p className="eyebrow">{c('THE SHORT VERSION','КОРОТКО ОБ АКТИВЕ')}</p><h2>{first?first.title[locale]:c('More evidence is needed.','Нужно больше данных.')}</h2><p>{first?first.detail[locale]:c('There is no supported all-clear in this snapshot. Open the missing checks before deciding.','Этот снимок не подтверждает отсутствие риска. Перед решением откройте недостающие проверки.')}</p></div><div className="quick-verdict-bottom"><span><Info size={15}/>{c(`${r.covered} of 5 areas have evidence`,`${r.covered} из 5 областей с данными`)}{report.mode==='demo'?' · '+c('Example','Пример'):''}</span><button className="text-button" onClick={()=>onOpen(first?.tab||'Research')}>{c('See what matters','Посмотреть детали')}<ArrowUpRight size={16}/></button></div></section>;
}
