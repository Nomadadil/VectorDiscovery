'use client';

import { useEffect, useRef, useState } from 'react';
import { ArrowUpRight, Compass, ScanLine, Wallet, ChevronRight, Radio } from 'lucide-react';
import { useLocale } from '@/lib/lens/i18n';

export const VECTOR_TERMINAL_URL = 'https://t.me/vectordexbot?startapp=5b847c41';

function SignalField() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => setVisible(entry.isIntersecting), { threshold: .1 });
    if (ref.current) observer.observe(ref.current);
    const visibility = () => { if (document.hidden) setVisible(false); else if (ref.current) setVisible(ref.current.getBoundingClientRect().bottom > 0); };
    document.addEventListener('visibilitychange', visibility);
    return () => { observer.disconnect(); document.removeEventListener('visibilitychange', visibility); };
  }, []);
  return <div className="vd-signal-field" ref={ref} data-motion={visible ? 'running' : 'paused'} aria-hidden="true">
    <div className="vd-signal-grid" />
    <svg className="vd-signal-lines" viewBox="0 0 600 500" fill="none">
      {Array.from({ length: 13 }, (_, i) => <path key={i} d={`M -90 ${410+i*11} C 50 ${440+i*4}, 110 ${70+i*7}, 275 ${185+i*11} S 430 ${450-i*8}, 690 ${110+i*10}`} />)}
      <path className="vd-signal-trace" d="M -90 454 C 50 456, 110 98, 275 229 S 430 418, 690 150" />
    </svg>
    <span className="vd-coordinate vd-coordinate-one">+</span><span className="vd-coordinate vd-coordinate-two">+</span>
    <div className="vd-orbit vd-orbit-one"/><div className="vd-orbit vd-orbit-two"/>
    <div className="vd-logo-core"><img src="/brand/symbol.svg" alt=""/><span className="vd-core-shine"/></div>
    <span className="vd-network-node vd-node-eth"><i/>ETH</span>
    <span className="vd-network-node vd-node-bsc"><i/>BSC</span>
    <span className="vd-network-node vd-node-sol"><i/>SOL</span>
    <div className="vd-art-caption"><span>VECTOR / DISCOVERY</span><span>01 — 03</span></div>
  </div>;
}

export function VectorHome({ onInspect, onWallets, onSignals }: { onInspect: (mode: 'inspect' | 'discover') => void; onWallets: () => void; onSignals: () => void }) {
  const { locale } = useLocale(), c = (en: string, ru: string) => locale === 'ru' ? ru : en;
  return <>
    <section className="vd-hero">
      <div className="vd-hero-copy">
        <div className="vd-overline"><span className="vd-tiny-mark"/><span>{c('TOKEN INTELLIGENCE','ИССЛЕДОВАНИЕ АКТИВОВ')}</span></div>
        <h1>{c('Less noise.','Меньше шума.')}<br/><span>{c('More discovery.','Больше ясности.')}</span></h1>
        <p>{c('Understand a token before your next move. Markets, risk signals and wallet activity — brought into one clear view.','Разберитесь в токене до следующего шага. Рынок, сигналы риска и активность кошельков — в одном понятном окне.')}</p>
        <div className="vd-hero-actions"><button className="primary-button" onClick={() => onInspect('inspect')}><ScanLine size={18}/>{c('Inspect a token','Проверить токен')}<ArrowUpRight size={17}/></button><button className="vd-secondary-link" onClick={() => onInspect('discover')}>{c('Explore new assets','Найти новые активы')}<ChevronRight size={17}/></button></div>
        <div className="vd-networks" aria-label={c('Supported networks','Поддерживаемые сети')}><span><i className="vd-chain-eth"/>Ethereum</span><span><i className="vd-chain-bsc"/>BNB Chain</span><span><i className="vd-chain-sol"/>Solana</span></div>
      </div>
      <SignalField/>
    </section>
    <button className="vs-home-banner" onClick={onSignals}><span className="vs-home-icon"><Radio size={24}/></span><span><small>VECTOR DISCOVERY / SIGNALS</small><b>{c("Fresh pools. A stricter shortlist.","Свежие пулы. Строгий отбор.")}</b><p>{c("New Solana assets, liquidity evidence and risk checks. Trending assets on Ethereum and BNB Chain.","Новые активы Solana, ликвидность и проверки риска. Тренды Ethereum и BNB Chain.")}</p></span><ChevronRight size={23}/></button>
    <div className="vd-desk-heading"><h2>{c('Your discovery desk.','Ваш центр исследований.')}</h2><span>{c('A clearer way in','Начните с того, что важно')}</span></div>
    <div className="vd-tool-grid">
      <button onClick={() => onInspect('inspect')}><span className="vd-tool-top"><ScanLine size={23}/><ArrowUpRight size={19}/></span><b>{c('Token research','Разбор токена')}</b><p>{c('Price, liquidity, holders and risk evidence. Start with a contract.','Цена, ликвидность, держатели и риски. Начните с контракта.')}</p><small>01 / {c('UNDERSTAND','ИЗУЧАЙТЕ')}</small></button>
      <button onClick={() => onInspect('discover')}><span className="vd-tool-top"><Compass size={23}/><ArrowUpRight size={19}/></span><b>{c('New opportunities','Новые активы')}</b><p>{c('Explore new pools by age, network, liquidity and available risk checks.','Ищите новые пулы по возрасту, сети, ликвидности и проверкам риска.')}</p><small>02 / {c('EXPLORE','НАХОДИТЕ')}</small></button>
      <button onClick={onWallets}><span className="vd-tool-top"><Wallet size={23}/><ArrowUpRight size={19}/></span><b>{c('Wallet intelligence','Радар кошельков')}</b><p>{c('Read available positions, trading history and wallet activity.','Изучайте доступные позиции, историю сделок и действия кошельков.')}</p><small>03 / {c('OBSERVE','НАБЛЮДАЙТЕ')}</small></button>
    </div>
    <a href={VECTOR_TERMINAL_URL} target="_blank" rel="noopener noreferrer" className="vd-terminal-banner"><span className="vd-terminal-brand"><img src="/brand/symbol.svg" alt=""/></span><span><small>{c('YOUR NEXT STEP','СЛЕДУЮЩИЙ ШАГ')}</small><b>{c('From discovery to Vector.','От исследования — к Vector.')}</b><p>{c('Open the trading terminal in Telegram.','Откройте торговый терминал в Telegram.')}</p></span><span className="vd-terminal-action">{c('Open Vector','Открыть Vector')}<ArrowUpRight size={20}/></span></a>
  </>;
}
