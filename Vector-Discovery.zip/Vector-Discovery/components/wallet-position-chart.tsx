'use client';
import {useCallback,useEffect,useRef,useState} from 'react';
import {ExternalLink,RefreshCw} from 'lucide-react';
import {LensChart} from './lens-chart';
import {TomLoader} from './tom-loader';
import {walletRequest as api} from './wallet-alerts-context';
import {useLocale} from '@/lib/lens/i18n';
import {NETWORKS,shortAddress,type LensReport,type Network} from '@/lib/lens/types';
import type {WalletAsset} from '@/lib/lens/portfolio-types';
import type {ObservedSwap} from '@/lib/lens/wallet-types';
import type {WalletTokenTrades} from '@/lib/lens/wallet-token-trades';
export function WalletPositionChart({asset,wallet,network,onBack}:{asset:Pick<WalletAsset,'address'|'symbol'>;wallet:string;network:Network;onBack:()=>void}){
 const {locale,money,number,date,t}=useLocale(),c=(en:string,ru:string)=>locale==='ru'?ru:en;
 const [report,setReport]=useState<LensReport|null>(null),[history,setHistory]=useState<WalletTokenTrades|null>(null),[busy,setBusy]=useState(true),[error,setError]=useState(''),[selected,setSelected]=useState<ObservedSwap|null>(null),[coverage,setCoverage]=useState({shown:0,total:0});
 const quantity=(amount:string)=>{const value=Number(amount);return value>0&&value<1e-8?value.toExponential(3):new Intl.NumberFormat(locale==='ru'?'ru-RU':'en-US',{maximumSignificantDigits:8}).format(value)};
 const seq=useRef(0);
 const showCoverage=useCallback((shown:number,total:number)=>setCoverage({shown,total}),[]);
 async function load(offset=0){const id=++seq.current;setBusy(true);setError('');try{
  const current=report||(await api('scan',{network,input:asset.address})).report as LensReport;
  if(seq.current!==id)return;setReport(current);
  const j:WalletTokenTrades=await api('wallet-token-trades',{reportId:current.id,wallet,offset,...(offset&&history?{before:history.to}:{})});
  if(seq.current!==id)return;if(j.state!=='ok')throw new Error(j.detail);
  setHistory(previous=>offset&&previous?{...j,scanned:previous.scanned+j.scanned,trades:[...new Map([...previous.trades,...j.trades].map(x=>[x.id,x])).values()].sort((a,b)=>a.time-b.time||a.id.localeCompare(b.id))}:j);
  if(!offset)setSelected(null);
 }catch(e){if(seq.current===id)setError(e instanceof Error?e.message:'Wallet activity is unavailable.')}finally{if(seq.current===id)setBusy(false)}}
 useEffect(()=>{load();return()=>{seq.current++}},[asset.address,wallet,network]);
 return <section className="position-workbench"><div className="position-workbench-heading"><button className="text-button" onClick={onBack}>{c('Back to positions','Вернуться к позициям')}</button><button className="icon-button" disabled={busy} onClick={()=>load()} aria-label={c('Refresh wallet chart','Обновить график кошелька')}><RefreshCw size={17}/></button></div><p className="eyebrow">{asset.symbol} / {c('WALLET ACTIVITY','ДЕЙСТВИЯ КОШЕЛЬКА')}</p><h3>{c('Buys and sells, in context.','Покупки и продажи на графике.')}</h3><p className="caption mono" title={wallet}>{shortAddress(wallet)} · {NETWORKS[network].name}</p>
 {busy&&<TomLoader label={report?c('Reading recorded swaps…','Загружаем записанные обмены…'):c('Opening this token’s market…','Открываем рынок токена…')}/>}
 {error&&<div className="portfolio-error" role="alert"><p>{t(error)}</p><button className="secondary-button" disabled={busy} onClick={()=>load(history?.nextOffset||0)}>{c('Retry','Повторить')}</button></div>}
 {report&&<LensChart report={report} initialInterval="4h" trades={history?.trades} onTradeSelect={setSelected} focusTime={selected?.time} onMarkerCoverage={showCoverage}/>}
 {history&&<><div className="position-chart-legend"><span><i className="buy-dot"/> B · {c('Buy','Покупка')}</span><span><i className="sell-dot"/> S · {c('Sell','Продажа')}</span><span>{coverage.shown}/{coverage.total} {c('on loaded candles','на загруженных свечах')}</span></div><p className="portfolio-note">{history.scope==='wallet-30d'?c('30-day search window. Read ','Окно поиска — 30 дней. Прочитано '):c('Recent activity in the selected pool only. Read ','Только свежие операции выбранного пула. Прочитано ')}{number(history.scanned)} {c('wallet / pool records; matching this token: ','записей кошелька / пула; по этому токену: ')}{history.trades.length}. {history.hasMore?c('History is incomplete.','История пока неполная.'):c('The returned window has been read.','Доступное окно прочитано.')}<br/>{date(new Date(history.from*1000).toISOString())} — {date(new Date(history.to*1000).toISOString())}</p>
 {coverage.shown<coverage.total&&<p className="notice">{c('Some swaps are outside the loaded candles or fall in a market-data gap. Choose a wider interval; the transaction list remains available.','Часть обменов вне загруженных свечей или попала в пробел рыночных данных. Выберите более широкий интервал; все найденные операции доступны ниже.')}</p>}
 {!history.trades.length&&<p className="empty-line">{history.hasMore?c('No matching swaps in the records read so far. Load more history.','В прочитанных записях обменов по токену пока нет. Загрузите ещё историю.'):c('No matching swaps were returned for this window. The position may predate it or come from transfers.','За это окно обменов по токену не найдено. Позиция могла появиться раньше или через переводы.')}</p>}
 {selected&&<div className="selected-position-trade"><span className={selected.side==='buy'?'good-text':'bad-text'}>{selected.side==='buy'?c('Buy','Покупка'):c('Sell','Продажа')}</span><strong>{quantity(selected.amount)} {asset.symbol}</strong><p>{c('Reported token price: ','Цена токена в записи: ')}{money(selected.price)} · {date(selected.at)}</p><a className="text-button" href={`${NETWORKS[network].explorer}/tx/${selected.hash}`} target="_blank" rel="noopener noreferrer">{c('View transaction','Открыть транзакцию')} <ExternalLink size={14}/></a></div>}
 <div className="position-swap-list">{[...history.trades].reverse().map(s=><button key={s.id} className={selected?.id===s.id?'is-selected':''} aria-pressed={selected?.id===s.id} onClick={()=>setSelected(s)}><span className={s.side==='buy'?'good-text':'bad-text'}>{s.side==='buy'?c('Buy','Покупка'):c('Sell','Продажа')}</span><span><b>{money(s.usd,true)}</b><small>{quantity(s.amount)} {asset.symbol}</small></span><time>{date(s.at)}</time></button>)}</div>
 {history.nextOffset!==null&&<button className="secondary-button portfolio-more" disabled={busy} onClick={()=>load(history.nextOffset!)}>{c('Read next 100 records','Прочитать ещё 100 записей')}</button>}
 {history.hasMore&&history.nextOffset===null&&<p className="notice">{c('The 1,000-record limit was reached. Earlier history has not been checked.','Достигнут лимит в 1 000 записей. Более ранняя история не проверена.')}</p>}
 <p className="portfolio-note">{c('Markers show observed swap legs, not necessarily a net position change: routed transactions can buy and sell the same token. The chart is a market reference, not the wallet’s exact fill price. Transfers are not purchases.','Отметки показывают части обменов, а не обязательно изменение позиции: маршрут может купить и продать один токен. График — рыночный ориентир, не точная цена исполнения кошелька. Переводы не считаются покупками.')} {c('Checked: ','Проверено: ')}{date(history.at)}</p></>}
 </section>;
}
