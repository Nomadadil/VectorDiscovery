'use client';
import {createContext,useCallback,useContext,useEffect,useRef,useState,type ReactNode} from 'react';
import {Wallet} from 'lucide-react';
import {useLocale} from '@/lib/lens/i18n';
import type {WalletFeed} from '@/lib/lens/wallet-leader-types';
export async function walletRequest(path:string,body?:unknown){const r=await fetch('/api/lens/'+path,body===undefined?{cache:'no-store'}:{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});const j:any=await r.json();if(!r.ok)throw new Error(j.error||'Request failed.');return j}
const initial:WalletFeed={items:[],monitors:[],unread:0};
const Context=createContext<{feed:WalletFeed;busy:boolean;error:string;reload:()=>Promise<void>;check:()=>Promise<void>;setFeed:(v:WalletFeed)=>void}>({feed:initial,busy:false,error:'',reload:async()=>{},check:async()=>{},setFeed:()=>{}});
export const useWalletAlerts=()=>useContext(Context);
export function WalletAlertsShortcut({onOpen}:{onOpen:()=>void}){const {feed}=useWalletAlerts();const {locale}=useLocale();return <button className="icon-button wallet-header-button" aria-label={locale==='ru'?'Рейтинг и уведомления кошельков':'Wallet ranking and notifications'} onClick={onOpen}><Wallet size={19}/>{feed.unread>0&&<span className="count-dot">{feed.unread>99?'99+':feed.unread}</span>}</button>}
export function WalletAlertsProvider({signedIn,children}:{signedIn:boolean;children:ReactNode}){const [feed,setFeed]=useState(initial),[busy,setBusy]=useState(false),[error,setError]=useState('');const active=useRef(false),signed=useRef(signedIn);signed.current=signedIn;
 const reload=useCallback(async()=>{if(!signedIn)return;try{const next=await walletRequest('wallet-alerts');if(signed.current){setFeed(next);setError('')}}catch(e){setError(e instanceof Error?e.message:'Notifications unavailable.')}},[signedIn]);
 const check=useCallback(async()=>{if(!signedIn||active.current)return;active.current=true;setBusy(true);try{const next=await walletRequest('wallet-alerts-refresh',{});if(signed.current){setFeed(next);setError('')}}catch(e){setError(e instanceof Error?e.message:'Wallet activity unavailable.')}finally{active.current=false;setBusy(false)}},[signedIn]);
 useEffect(()=>{if(!signedIn){setFeed(initial);return}reload();const poll=()=>{if(document.visibilityState==='visible'&&navigator.onLine)reload()};const timer=setInterval(poll,60000);document.addEventListener('visibilitychange',poll);return()=>{clearInterval(timer);document.removeEventListener('visibilitychange',poll)}},[signedIn,reload,check]);
 return <Context.Provider value={{feed,busy,error,reload,check,setFeed}}>{children}</Context.Provider>;
}
