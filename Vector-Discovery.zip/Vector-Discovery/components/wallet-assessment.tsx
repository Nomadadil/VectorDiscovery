'use client';
import {useLocale} from '@/lib/lens/i18n';
import {assessWallet,MIN_CLOSED_TOKENS} from '@/lib/lens/wallet-assessment';
import type {WalletLeader} from '@/lib/lens/wallet-leader-types';
export function WalletAssessment({row,compact=false}:{row:WalletLeader;compact?:boolean}){
 const {locale,date,money,number}=useLocale(),c=(en:string,ru:string)=>locale==='ru'?ru:en,a=assessWallet(row);
 const notes=[
  a.profitErased?c('Open losses erase realized profit','Открытые убытки перекрывают прибыль'):a.openLoss?c('Open positions are at a loss','Открытые позиции в минусе'):null,
  !a.complete?c('PnL coverage is incomplete','Данные PnL неполные'):a.inconsistent?c('PnL components do not reconcile','Составляющие PnL не сходятся'):null,
  a.signMismatch?c('Independent calculations disagree on profit / loss','Расчёты расходятся в знаке прибыли / убытка'):null,
  !row.performance?c('Closed outcomes not checked','Закрытые результаты не проверены'):!a.sampleReady?c('Small or unknown closed-token sample','Мало закрытых токенов или выборка неизвестна'):null,
  row.performance&&!a.fresh?c('Win-rate check is older than 48h','Проверка винрейта старше 48 ч'):null
 ].filter(Boolean);
 if(compact)return <span className={'wallet-assessment-inline '+(a.profitErased||a.signMismatch||a.inconsistent?'has-concern':'')}>{notes[0]||c('20+ closed tokens · checked within 48h','20+ закрытых токенов · проверено за 48 ч')}{notes.length>1&&<small>{c('More context in wallet details','Подробнее — в карточке кошелька')}</small>}</span>;
 return <section className="wallet-assessment"><p className="eyebrow">{c('READ THE WHOLE RESULT','РЕЗУЛЬТАТ ЦЕЛИКОМ')} / 30 {c('DAYS','ДНЕЙ')}</p><div className="assessment-equation"><div><span>{c('Realized','Зафиксировано')}</span><strong>{money(row.realized,true)}</strong></div><span>+</span><div><span>{c('Unrealized PnL','Нереализованный PnL')}</span><strong className={a.openLoss?'bad-text':''}>{money(row.unrealized,true)}</strong></div><span>{a.inconsistent?'≠':'≈'}</span><div><span>{c('Total PnL','Общий PnL')}</span><strong className={(row.total??0)<0?'bad-text':''}>{money(row.total,true)}</strong></div></div>{notes.length>0&&<ul>{notes.map(n=><li key={n}>{n}</li>)}</ul>}<p>{c('Closed-token sample: ','Закрытых токенов: ')}{number(a.sample)}. {c(`The ${MIN_CLOSED_TOKENS}-token filter is a comparison threshold, not proof of skill.`, `Порог ${MIN_CLOSED_TOKENS} токенов нужен для сравнения, а не для подтверждения навыка.`)}</p>{row.performance&&<p>{c('Separate WAC check: ','Отдельная проверка WAC: ')}{date(row.performance.fetchedAt)} · {c('realized ','зафиксировано ')}{money(row.performance.realized,true)} · {c('total ','всего ')}{money(row.performance.total,true)}</p>}</section>;
}
