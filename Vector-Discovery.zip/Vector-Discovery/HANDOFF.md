# Vector Discovery · handoff

## Product boundary

Vector Discovery is an independent research application derived from the existing research codebase. The original product remains unchanged. The supported networks are **Ethereum / BNB Smart Chain / Solana**; unsupported network values must be rejected by the server as well as omitted from selectors.

The sole terminal destination is:

https://t.me/vectordexbot?startapp=5b847c41

This is a handoff to the existing Vector Telegram application. No contract parameter, trade amount, direction, quote or order is appended to it. Token selection must be completed inside Vector unless its team supplies and approves a documented deep-link contract.

The interface supports EN and RU. Mobile navigation, saved research and wallet research share one application shell. Reduced-motion preferences must retain every feature without ornamental animation.

## Isolation and hosting

- Separate Site identity and D1 database; new deployment is private.
- No source-product user records, watchlists, alert history, cached reports, runtime database or provider credentials were copied.
- Existing `lens_*` table/API/internal names are implementation identifiers, not a connection to the original product's storage.
- The immutable migration history is retained so the new database can be created from scratch. Old unused table definitions do not enable removed network features.
- `.env.example` is a configuration guide, not a credential file. Set secrets only through the server/hosting environment. Never use a public environment-variable prefix for API keys.
- The local identity mock is only for preview. Hosted accounts use the platform's verified identity gateway. A Vector-specific authentication flow has not been implemented or claimed.
- Share links remain subject to the Site's access policy. Private publication does not make report links publicly accessible.

## Useful without new paid services

Public market/pool sources, available contract checks, pool discovery, bounded chart requests, available chain reads, project links and research reports form the baseline. Each upstream can rate-limit, fail or lack coverage. An unavailable result is shown explicitly and is never replaced with a fabricated successful check.

Adapters for optional providers are retained. They are not connected merely because their code exists. In particular, Solana wallet ranking, deeper indexed wallet history and some richer holder/chart data require Birdeye access. Relationship mapping requires its own data access. No complete holder-relationship graph or comprehensive ranking of every wallet is promised.

## Research quotas

Current application limits in `lib/lens/economy.ts`:

| Scope | Fresh token checks/day | Metered research credits/day |
| --- | ---: | ---: |
| Guest browser | 5 | 80 |
| Signed-in account, across devices | 20 | 200 |
| Whole application | 600 | 800 |

Metered monthly ceiling: **24,000 credits**. Daily section budgets: analysis 240, charts 320, wallets 160 and monitoring 80. Guests additionally share 240 daily credits. Unused section budgets do not automatically transfer between sections. Daily resets use UTC.

These are application ceilings, not purchased provider capacity or a forecast of the invoice. Optional endpoints can be inaccessible on a particular plan. Shared caches and explicit refresh controls reduce repeated upstream use; a popular deployment still needs traffic and budget review before broader launch.

## Accounts and monitoring

Personal watchlists, wallet subscriptions and the event feed are saved to the new database under verified account ownership. They can follow the same hosting account across devices. Local browser preferences, such as language, are separate from account data. Guests do not gain durable account ownership by receiving a quota cookie.

Automatic paid wallet monitoring remains paused. Signals has a separate free-source hourly background schedule described below; it does not enable wallet background monitoring. Manual checks and in-app feed reads describe their actual refresh behavior.

## Vector Discovery · Signals

Signals is a separate research screen, not an execution engine. Its full token cards include copied contracts, available avatars/social links, selected-pool candles, check evidence and the existing report handoff. Qualified cards open the exact terminal URL `https://t.me/vectordexbot?startapp=5b847c41`; no token/order parameters are invented. Pending candidates remain research-only and do not generate alerts or a buy action.

**Solana defaults:** observed pool age at most 120 minutes (optional 60-minute view), reported market cap ≥ $25,000, selected-pool liquidity ≥ $15,000, rolling H1 buys ≥ 5, sells ≥ 5 and buys + sells ≥ 25. H24 activity and FDV never substitute for these fields. The sample combines two new-pool pages, one one-hour trending-pool page and up to 80 retained recent candidates. At most four candidates receive deeper checks per refresh; every candidate must receive current selected-pool market metrics before qualification. An older returned pool disqualifies a Solana candidate. Pool age is not proof of token mint/launch time or complete earliest-pool coverage.

**Ethereum / BNB Chain:** one trending-pool page per network, at most three deeper checks each refresh, with the same market-cap/liquidity thresholds and conservative permission, sell-simulation and pool-specific liquidity gates. The Solana age/H1-count requirements do not apply to these trending lists.

All required checks must pass. Material flags exclude a candidate; unavailable evidence stays pending. The additional LP threshold is **≥ 95% confirmed locked/burned share**. Current free adapters can establish full Solana LP burn using matching RugCheck market/mint evidence, or selected EVM pool burn through `token0`, `token1`, `totalSupply` and known burn-address balances. Token-global holder locks, unsupported concentrated-liquidity positions, aggregate lock percentages without scope/expiry and unquantified time locks do not pass. Solana requires transfer/authority checks, the token risk report, observed sells and an indicative exit route; that route is explicitly **not a sell simulation**. Ethereum/BNB require a successful simulation for the selected token and pool. None of these results guarantees future sale or profit.

Public APIs under `/api/lens/`: `POST signals` (`network`, `maxAgeMinutes`) and `POST signals-chart` (`network`, `address`, `pool`, `interval`). Account-scoped APIs: `GET signals-feed`, `POST signals-subscribe` (`networks`, `enabled`) and `POST signals-read`. Public snapshots are shared across viewers and 60/120-minute views. Subscriptions/read state belong to the verified account. Signal alerts are distinct from wallet alerts, deduplicated by network/token, retained for seven days and bounded to 2,000 public records. Failed rechecks revoke active status; expired records cannot remain active. Pausing/resuming retains history without retroactive unread alerts.

Migration **`drizzle/0008_vector_signals.sql`** adds `vector_signals`, `vector_signal_subscriptions` and `vector_signal_runs`; schema, journal and snapshot are included. Apply migrations before enabling the routes.

Shared refresh caches: **SOL 5 minutes; ETH/BNB 15 minutes**. Candidate checks are capped at **1,800/day**, security requests at **4,500/day**, in addition to existing application/provider ceilings; resets use UTC. RugCheck requests are staggered to roughly one per second. Signals use public endpoints and do not activate a paid API plan. Upstream limits and incomplete free-source coverage can leave the qualified list empty; the UI must preserve that result rather than relax checks silently.

**Current refresh behavior:** while the Signals screen is open, online and visible, it requests the shared cache every 5 minutes; SOL cache lasts 5 minutes and ETH/BSC 15 minutes. Native Sites schedule `Automation_466c2647d8948191a03c7a9adc994515` is saved and enabled hourly in Europe/Moscow, starting 12 October 2026 at 18:00. The platform rejected a 15-minute background schedule because its minimum interval is one hour. Fresh unattended service calls to all three deployed endpoints succeeded (HTTP 200) on 12 October 2026; a second request read back each saved snapshot with the same timestamp. Creation confirms the schedule, not execution of its first scheduled run. In-app alerts are not phone push notifications. Strict expiry can leave no active signal between unattended scans; old observations remain history and never retain an active Buy shortcut.

## Interpretation boundaries

- A risk rating summarizes returned evidence and its coverage. It is not a probability of loss, investment recommendation or safety certification.
- A quote is different from a completed sell simulation. Missing route/plan access is neither a honeypot verdict nor a zero-output trade.
- Discovery covers loaded pools only. Missing capitalization cannot satisfy an active capitalization filter.
- Price and estimated-capitalization chart modes must not imply historical circulating supply is known.
- Wallet balances may include illiquid assets. PnL can be incomplete because of transfers, missing history, fees and provider coverage. Realized and unrealized results remain separate.
- A wallet with a profitable history is not assured future success. Rankings are a sample with stated windows, not the complete market.
- Holder maps show returned nodes/links, not proof of common ownership or coordinated fraud.
- Project descriptions are claims made by the project. Links to X do not establish verified sentiment or adoption.

## Delivery checks

Before broad release: run the regression suite and TypeScript/build checks; inspect phone and desktop layouts in both languages; confirm exact terminal URL and that unsupported networks cannot reach research APIs; verify empty/error/partial states with no secrets configured. Recheck owner-scoped storage and sign-out behavior before changing Site access.

Current work does not activate a paid subscription, migrate existing users or provide an execution engine. Keep these distinctions visible when demonstrating the application.

## Implemented visual identity

White/cool-gray research surfaces, Vector navy `#101F54`, cyan `#00E3EB`, Inter with tabular numbers. The supplied mark is preserved as embedded pixels in a bounded SVG viewport; a luminance filter removes its rectangular backdrop. The home screen has a fine network field, a moving trace and gently floating network labels. Effects pause out of view and obey reduced-motion preferences. Hover reflections and branded loading states do not obscure data.

Terminal access is available from the header, home banner and token report. Discovery has no execution permissions and does not send an order into Vector. Existing API and table names remain internal implementation details.

## Validation completed · 12 October 2026

The bullets below describe the original fork validation (13 suites). The final Signals
snapshot expands the suite to 16 and all 16 passed again during the handoff audit.
This is regression coverage, not an external security audit or a production load test.

- TypeScript and all 13 regression suites passed after the fork; unsupported-network rejection is covered at the real API route boundary.
- Live WETH (Ethereum), WBNB (BNB Chain) and wrapped SOL checks returned matching token identities, prices, volume and liquidity. No paid keys were configured.
- ETH chart returned 240 candles; browser price/capitalization switching worked.
- ETH/BSC sell-simulation evidence and holder samples returned. Public Solana RPC access was unavailable in this run; missing fields remained unknown.
- Real new-pool discovery populated the mobile list. Filters, exact terminal links, 390px layout and the 1440px desktop composition were reviewed in the browser.
- The new Site is separate and private. Public launch, paid data accounts, Telegram/Vector-native sign-in and automatic token deep links remain separate decisions.
